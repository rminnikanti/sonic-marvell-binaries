
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.cli_types import *
from itertools import *
from time import *
from ifcs_cmds.intf import *
from utils.compat_util import *
from verbosity import *
from print_table import PrintTable
import sys
from utils.compat_util import *
ifcs_ctypes = sys.modules['ifcs_ctypes']

def show_pp_drop_reason_extension_usage_detail(arg1, arg2, self):
    usage_p = (ifcs_ctypes.ifcs_usage_t * 2)()
    max_ingress_drop_reason = 256
    max_egress_drop_reason = 32
    current_usage = self.cli.ifcs_ctypes.ifcs_uint32_t()
    max_usage = self.cli.ifcs_ctypes.ifcs_uint32_t()
    rc = ifcs_ctypes.ifcs_pp_drop_reason_usage_detail_get(
            0, 0, None, usage_p)
    log_dbg(1, " Inside extension pp_drop_reason usage show")
    table = PrintTable()
    log("User Created PP DROP REASONS")
    table.add_row(["Direction", "Max", "Used", "Available" ])
    table.add_row(["Ingress", usage_p[0].max, usage_p[0].current, (usage_p[0].max - usage_p[0].current)])
    table.add_row(["Egress", usage_p[1].max, usage_p[1].current, (usage_p[1].max - usage_p[1].current)])
    table.print_table(brief=True)
    table.reset_table()
    log("SDK Created PP DROP REASONS")
    table.add_row(["Direction", "Max", "Used", "Available" ])
    max_sdk_ingress_drop_reason = max_ingress_drop_reason - usage_p[0].max
    max_sdk_egress_drop_reason = max_egress_drop_reason - usage_p[1].max
    table.add_row(["Ingress", max_sdk_ingress_drop_reason, usage_p[0].available, (max_sdk_ingress_drop_reason - usage_p[0].available)])
    table.add_row(["Egress", max_sdk_egress_drop_reason, usage_p[1].available, (max_sdk_egress_drop_reason - usage_p[1].available)])
    table.print_table(brief=True)
    table.reset_table()

    return
