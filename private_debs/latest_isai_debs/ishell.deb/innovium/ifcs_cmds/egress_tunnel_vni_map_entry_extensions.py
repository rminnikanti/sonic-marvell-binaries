
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
# *-----------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.cli_types import *
from itertools import *
from time import *
from utils.compat_util import *
from ifcs_ctypes import *
from ifcs_ctypes import *
from ifcs_cmds.egress_tunnel_vni_map_entry import *
from print_table import PrintTable
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']


def show_egress_tunnel_vni_map_entry_extension_brief(
        args, egress_tunnel_vni_map_entry):
    log_dbg(1, " Inside egress_tunnel_vni_map_entry extension brief show")

    try:
        if args:
            rc, all_egress_tunnel_vni_map_entry = egress_tunnel_vni_map_entry.bulk_get_all_egress_tunnel_vni_map_entry_keys(args)
        else:
            rc, all_egress_tunnel_vni_map_entry = egress_tunnel_vni_map_entry.bulk_get_all_egress_tunnel_vni_map_entry_keys()
    except BaseException:
        log_err(" Failed to get all egress_tunnel_vni_map_entry")
        return

    table = PrintTable()
    field_names = []

    field_names.append('key_type')
    field_names.append('key')

    field_names.append('packet_value')
    table.add_row(field_names)

    try:
        if egress_tunnel_vni_map_entry.filter_option['sort'] in egress_tunnel_vni_map_entry.get_methods.keys():
            all_egress_tunnel_vni_map_entry = sorted(all_egress_tunnel_vni_map_entry,
                key=lambda x: egress_tunnel_vni_map_entry.get_methods[egress_tunnel_vni_map_entry.filter_option['sort']](x))
        else:
            log("Cannot sort on {0}".format(egress_tunnel_vni_map_entry.filter_option['sort']))
    except BaseException:
        pass
    all_egress_tunnel_vni_map_entry = sorted(
        all_egress_tunnel_vni_map_entry,
        key=lambda x: x.contents.key_type)

    log("Total egress_tunnel_vni_map_entry count: {0} ".format(len(all_egress_tunnel_vni_map_entry)))
    count = 0

    for map_entry in all_egress_tunnel_vni_map_entry:
        attr_row = []
        key_type_str = ''
        key_type = map_entry.contents.key_type
        if key_type == IFCS_EGRESS_TUNNEL_VNI_MAP_KEY_TYPE_IPV4_GRE:
            key_type_str = 'ipv4_gre'
            key = map_entry.contents.key.ipv4_gre_key.l3vni
        elif key_type == IFCS_EGRESS_TUNNEL_VNI_MAP_KEY_TYPE_IPV6_GRE:
            key_type_str = 'ipv6_gre'
            key = map_entry.contents.key.ipv6_gre_key.l3vni
        elif key_type == IFCS_EGRESS_TUNNEL_VNI_MAP_KEY_TYPE_IPV4_VXLAN:
            key_type_str = 'ipv4_vxlan'
            key = map_entry.contents.key.ipv4_vxlan_key.l2vni
        elif key_type == IFCS_EGRESS_TUNNEL_VNI_MAP_KEY_TYPE_IPV6_VXLAN:
            key_type_str = 'ipv6_vxlan'
            key = map_entry.contents.key.ipv6_vxlan_key.l2vni

        key_str = egress_tunnel_vni_map_entry.handle_to_str(key)

        attr_row.append(key_type_str)
        attr_row.append(key_str)

        try:
            packet_value = egress_tunnel_vni_map_entry.getPacketValue(
                map_entry, True)
        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(
                1,
                "KeyError in show egress_tunnel_vni_map_entry extension brief. egress_tunnel_vni_map_entry: {} (key_type: {}, key: {}), error: {}"
                .format(map_entry, key_type_str, key_str, einfo))
            if egress_tunnel_vni_map_entry.not_found_exc_msg.format(
                    ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                # Skip the instance as the object is not found.
                continue
            # Re-raise other exceptions for handling.
            raise

        attr_row.append(str(packet_value))
        table.add_row(attr_row)
        count += 1

    table.print_table(brief=True)
    log("Total egress_tunnel_vni_map_entry count: {0}".format(count))

    return


def show_egress_tunnel_vni_map_entry_extension_attrs(
        egress_tunnel_vni_map,
        egress_tunnel_vni_map_entry,
        ignore_notfound_err=False,
        display_count=False,
        count_val=0):
    log_dbg(1, " Inside egress_tunnel_vni_map_entry extension attrs show")
    attrCount = None

    if not attrCount:
        attrCount = ifcs_ctypes.IFCS_EGRESS_TUNNEL_VNI_MAP_ENTRY_ATTR_COUNT_GET_ALL

    attr = (ifcs_ctypes.ifcs_attr_t * attrCount)()
    attr_p = compat_pointer(attr, ifcs_ctypes.ifcs_attr_t)

    try:
        actual_count = egress_tunnel_vni_map_entry.getAttr(
            egress_tunnel_vni_map, attr, attr_p, attrCount, ignore_notfound_err)
    except KeyError:
        einfo = "{}".format(sys.exc_info())
        log_dbg(
            1,
            "KeyError in show egress_tunnel_vni_map_entry extension attrs. egress_tunnel_vni_map_entry: {}, error: {}"
            .format(egress_tunnel_vni_map, einfo))
        if ignore_notfound_err and egress_tunnel_vni_map_entry.not_found_exc_msg.format(
                ifcs_ctypes.IFCS_NOTFOUND) in einfo:
            # Don't display error message for expected exception.
            # Re-raise for handling.
            raise
        log_err("Failed to get attributes for egress_tunnel_vni_map_entry ")
        raise
    except:
        log_dbg(
            1,
            "OtherError in show egress_tunnel_vni_map_entry extension attrs. egress_tunnel_vni_map_entry: {}, error: {}"
            .format(egress_tunnel_vni_map, sys.exc_info()))
        log_err("Failed to get attributes for egress_tunnel_vni_map_entry ")
        raise KeyError

    if display_count:
        log("EgressTunnelVniMapEntry count: {0} ".format(count_val))

    table = PrintTable()

    key_type_str = ''
    key_type = egress_tunnel_vni_map.contents.key_type
    if key_type == IFCS_EGRESS_TUNNEL_VNI_MAP_KEY_TYPE_IPV4_GRE:
        key_type_str = 'ipv4_gre'
        key = egress_tunnel_vni_map.contents.key.ipv4_gre_key.l3vni
    elif key_type == IFCS_EGRESS_TUNNEL_VNI_MAP_KEY_TYPE_IPV6_GRE:
        key_type_str = 'ipv6_gre'
        key = egress_tunnel_vni_map.contents.key.ipv6_gre_key.l3vni
    elif key_type == IFCS_EGRESS_TUNNEL_VNI_MAP_KEY_TYPE_IPV4_VXLAN:
        key_type_str = 'ipv4_vxlan'
        key = egress_tunnel_vni_map.contents.key.ipv4_vxlan_key.l2vni
    elif key_type == IFCS_EGRESS_TUNNEL_VNI_MAP_KEY_TYPE_IPV6_VXLAN:
        key_type_str = 'ipv6_vxlan'
        key = egress_tunnel_vni_map.contents.key.ipv6_vxlan_key.l2vni

    key_str = egress_tunnel_vni_map_entry.handle_to_str(key)

    table.add_row(
        ['key_type', key_type_str])
    table.add_row(['key', key_str])
    table.set_header_size(2)

    for j in range(actual_count.value):
        attr_name, attr_type, attr_val, attr_valid = egress_tunnel_vni_map_entry.get_attr_name_value(attr[j])
        if attr_valid:
            table.add_row([attr_name, attr_val])
    table.print_table()
    table.reset_table()

    return
