#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import collections
import copy
import sys

sys.path.append('../../shell')
from cmds.verbosity import *
from utils.compat_util import compat_listkeys

class Type:
    def __init__(self, db, ydata):
        self._db    = db
        self._ydata = ydata

        self.name   = ydata['name']
        self.desc   = ydata['desc']
        self.type   = ydata['type']
        self.values = ydata['values'] if 'values' in ydata else None
        self.objects= ydata['objects'] if 'objects' in ydata else []
        self.size   = ydata['size'] if 'size' in ydata else None
        self.min    = ydata['min'] if 'min' in ydata else None
        self.max    = ydata['max'] if 'max' in ydata else None
        self.bitmask= False if 'bitmask' not  in ydata else False if ydata['bitmask'] == "no" else True
        self.ptr    = False if 'ptr' not in ydata else False if ydata['ptr'] == "no" else True
        self.api    = True if 'api'not in ydata else False if ydata['api'] == "no" else True
        self.pd     = True if 'path' in ydata and 'pd' == ydata['path'][0:2] else False
        self.pd_pkg =  ydata['path'].split('/')[1] + '_' + ydata['path'].split('/')[3][:-5] if self.pd else ""
        self.ctype  = ""
        self.cvalues = {}
        self.is_attr = False if 'is_attr' not in ydata else False if ydata['is_attr'] == "no" else True
        self.devices    = [Devices(db, y) for y in ydata['devices']] if 'devices' in ydata else []
        self.prefix = True if 'prefix' not in ydata else False if ydata['prefix'] == "no" else True

    def validate_type(self):
        if 'members' in self._ydata:
            if self.type != 'struct' and self.type != 'union' and self.type != 'list' :
                assert False, "Type is not of struct or enum or list %s" % self.name
            self.members = [ Type(self._db, t) for t in self._ydata['members']] if 'members' in self._ydata else []
            [m.validate_type() for m in self.members]
        if ":" in self.type:
            m, o = self.type.split(':')
            self.orig_type = o
            self.type = self._db.lookup_type(self.type)
            self.ref = True
        else:
            self.ref = False
        self.enum = True if self.type == 'enum' else False
        self.struct = True if self.type == 'struct' else False
        self.union = True if self.type == 'union' else False
        self.list = True if self.type == 'list' else False
        self.dyn_arr = True if self.size == '-1' else False

    @staticmethod
    def parse_enum_value(enum_value, ordinal_value=None):
        name = enum_value
        desc = None
        deprecated_name = None
        if '(' in name:
            name, desc = name[:-1].split('(', 1)
        if '=' in name:
            name, ordinal_value = name.split('=', 1)
        if '/' in name:
            name, deprecated_name = name.split('/', 1)
        if desc is None:
            desc = name.upper()
        return (name, ordinal_value, desc, deprecated_name)

class Devices:
    def __init__(self, db, ydata):
        self._db    = db
        self._ydata = ydata
        self.name = ydata['name']
        self.supported = True if 'supported' in ydata and ydata['supported'] == 'yes' else False
        self.device = ydata['device'] if 'device' in ydata else None
        self.device_types = [ d for d in ydata['device_types']] if 'device_types' in ydata else []
        self.values = ydata['values'] if 'values' in ydata else None

class Property:
    def __init__(self, db, ydata):
        self._db    = db
        self._ydata = ydata

        self.name      = ydata['name']
        # do the lookup in next phase.
        self.type      = ydata['type'] if 'type' in ydata else 'uint64'
        self.desc      = ydata['desc']
        self.deprecated_name = ydata['deprecated_name'] if 'deprecated_name' in ydata else None
        self.key       = False if 'key' not in ydata else False if ydata['key'] == "no" else True
        self.editable  = True if 'editable' not in ydata else False if ydata['editable'] == "no" else True
        self.readonly  = False if 'readonly' not in ydata else False if ydata['readonly'] == "no" else True
        self.ifcs_readonly  = False if 'readonly' not in ydata else True if ydata['readonly'] == "ifcs" else False
        self.updatable = None if 'updatable' not in ydata else ydata['updatable']
        # if the prop is readonly then it cannot be edited
        self.editable  = False if self.readonly else self.editable
        self.im_editable  = True if self.ifcs_readonly else self.editable
        self.default   = ydata['default'] if 'default' in ydata else None
        self.mandatory = ydata['mandatory'] if 'mandatory' in ydata else []
        self.ref_count = True if 'ref_count' not in ydata else False if ydata['ref_count'] == "no" else True
        self.brief     = True if 'cli_brief' in ydata and ydata['cli_brief'] == 'yes' else False
        self.cli_options = ydata['cli_options'] if 'cli_options' in ydata else []
        self.invalid   = ydata['invalid'] if 'invalid' in ydata else []
        self.objects   = ydata['objects'] if 'objects' in ydata else []
        self.member    = ydata['member']  if 'member' in ydata else False
        self.mobj      = ydata['mobj']  if 'mobj' in ydata else None
        self.cattr_id  = ""
        self.min       = ydata['min'] if 'min' in ydata else None
        self.max       = ydata['max'] if 'max' in ydata else None
        self.layer     = ydata['layer'] if 'layer' in ydata else 'ifcs'
        self.clr        = False if 'clr' not in ydata else False if ydata['clr'] == "no" else True
        self.limit      = False if 'limit' not in ydata else 'limit' in ydata
        self.devices    = [Devices(db, y) for y in ydata['devices']] if 'devices' in ydata else []
        # disable for now.
        #self.optional  = True if (len(self.invalid) > 0 or (self.key is False and self.default is None and len(self.mandatory) == 0 and not self.readonly)) else False
        self.optional  = False
        self.wb_force_save = True if 'wb_force_save' in ydata else False

    def validate_property(self):
        self.type = self._db.lookup_type(self.type)

class Member:
    def __init__(self, db, ydata):
        self._db    = db
        self._ydata = ydata

        self.name = ydata['name']
        self.desc = ydata['desc']
        self.cardinality = True if ydata['cardinality'] == 'n' else False
        self.size = ydata['size'] if 'size' in ydata.keys() else 0xdead
        self.properties = [Property(db, p) for p in ydata['properties']] if 'properties' in ydata else []
        self.chain_len = ydata['chain_len'] if 'chain_len' in ydata.keys() else 8
        # do the lookup later
        self.objects = ydata['objects']
        self.cattr_id= ""
        self.unique = True if 'unique' not in ydata else False if ydata['unique'] == "no" else True
        self.storage = ydata['storage'] if 'storage' in ydata else 'hashtable'
        self.layer   = ydata['layer'] if 'layer' in ydata else 'ifcs'
        self.ref_count = True if 'ref_count' not in ydata else False if ydata['ref_count'] == "no" else True

    def validate_member(self):
        if self.size == 0xdead:
            assert False, "Object store size not specified for member name: {}".format(self.name)
        o = self.objects
        self.objects = [ self._db.lookup_object(o) for o in self.objects ]
        [p.validate_property() for p in self.properties]
        if not self.unique and self.storage == 'hashtable':
            log(self._ydata)
            assert False, "Cannot support duplicate with hashtable"
    def has_editable(self):
        for pobj in self.properties:
            # keys are not editable
            if pobj.key: continue
            if pobj.editable :
                return True
        return False

class Object:
    def __init__(self, db, module, ydata):
        self._db    = db
        self._ydata = ydata
        self.module = module

        self.name       = ydata['name']
        self.desc       = ydata['desc']
        self.storage    = ydata['storage'] if 'storage' in ydata else 'indextable'
        self.id_space   = ydata['id-space'] if 'id-space' in ydata else 'hybrid'
        self.cli_callback = ydata['cli_overrides'] if 'cli_overrides' in ydata else ['no']
        self.exists     = "after-boot" if 'exists' not in ydata else ydata['exists']
        self.updatable  = "after-boot" if 'updatable' not in ydata else ydata['updatable']
        self.key_alias  = ydata['key_alias'] if 'key_alias' in ydata else self.name
        self.key_space  = ydata['key_space'] if 'key_space' in ydata else 'homogeneous'
        self.api_prefix = ydata['api_prefix'] if 'api_prefix' in ydata else None
        # Do not generate CLI code for this Object, True if not exists is
        self.gencli     = True if 'gencli' not in ydata else False if ydata['gencli'] == "no" else True
        self.layer      = ydata['layer'] if 'layer' in ydata else 'ifcs'
        self.api        = True if 'api' not in ydata else False if ydata['api'] == "no" else True
        if 'apis' not in ydata:
            self.apis   = ["create", "delete", "set", "get", "add-mbrs", "get-mbrs", "remove-mbrs", "get-mbr", "set-mbr"]
            if self.module.full_api: self.apis.append('get-all')
            self.api_desc = dict ( (a, 'FIXME' + a) for a in self.apis)
        elif ydata['apis']:
            self.apis   = [a['name'] for a in ydata['apis']]
            self.api_desc = dict ( (a['name'], a['desc']) for a in ydata['apis'])
        else:
            self.apis   = []
            self.api_desc = {}
        self.im_apis    = self.apis if 'im-apis' not in ydata else  [a['name'] for a in ydata['im-apis']]
        self.ii_apis    = copy.deepcopy(self.im_apis) if 'ii-apis' not in ydata else [a['name'] for a in ydata['ii-apis']]
        self.properties = [Property(db, p) for p in ydata['properties']] if 'properties' in ydata else []
        self.properties_dict = dict ((p.name, p) for p in self.properties)
        self.members = [Member(db, r) for r in ydata['members']] if 'members' in ydata else []
        self.stats = [Stats(db, r) for r in ydata['stats']] if 'stats' in ydata else []
        self.errors = [Errors(db, r) for r in ydata['errors']] if 'errors' in ydata else []
        # lookup this in validate
        self.parent     = ydata['parent'] if 'parent' in ydata else None
        self.implements = ydata['implements'] if 'implements' in ydata else None
        self.profile    = ydata['profile'] if 'profile' in ydata else None
        self.devices    = [Devices(db, y) for y in ydata['devices']] if 'devices' in ydata else []
        self.mappedto   = ydata['mappedto'] if 'mappedto' in ydata else None
        self.size = ydata['size'] if 'size' in ydata.keys() else 0xffff
        self.hw_max = ydata['hw_max'] if 'hw_max' in ydata.keys() else 0xdead
        self.hw_max_desc = ydata['hw_max_desc'] if 'hw_max_desc' in ydata.keys() else ''
        self.chain_len = ydata['chain_len'] if 'chain_len' in ydata.keys() else 8
        self.key_struct = ""
        self.pd         = True if 'pd' == ydata['path'][0:2] else False
        self.pd_pkg =  ydata['path'].split('/')[1] + '_' + ydata['path'].split('/')[3][:-5] if self.pd else ""
        self.impl_by    = []
        self.mbr_of     = []
        for p in self.properties:
            if self.pd: break
            assert not (len(p.mandatory) == 0 and not p.default and not p.key and not p.readonly), "Object " + self.name + " needs default for " + p.name
        self.ref_count = True if 'ref_count' not in ydata else False if ydata['ref_count'] == "no" else True

    def validate_object(self):
        mandatory_ref_count_attr = False
        ref_count_attr_count = 0
        if self.pd:
            if self.size == 0xdead:
                assert False, "Object store size not specified in module: {} API class: {}".format(self.module.name, self.name)
            if self.hw_max == 0xdead:
                assert False, "HW max for API class not specified in module: {} API class: {}".format(self.module.name, self.name)
        if self.members:
            mbr_layer = 'im'
            for api in self.apis:
                if 'mbr' in api:
                    mbr_layer = 'ifcs'
                    break
            [r.validate_member() for r in self.members]
            [ [o.mbr_of.append((self, r)) for o in r.objects] for r in self.members]
            for m in self.members:
                mdict = {'name'     : '%s_count'%m.name,
                         'desc'     : 'Count of %s under this %s'%(m.name, self.name),
                         'type'     : 'ifcs:uint32',
                         'readonly' : 'yes',
                         'cli_brief': 'yes',
                         'layer'    : mbr_layer,
                         'member'   : m.name,
                         'mobj'     : m,}
                # Commenting out this - Bug 3144
                #self.properties.append(Property(self._db, mdict))
        if self.properties:
            for p in self.properties:
                p.validate_property()
                if p.name == 'ref_count' and p.type.name == 'ref_count':
                    mandatory_ref_count_attr = True
                    ref_count_attr_count += 1
        if mandatory_ref_count_attr == False:
            if (self.pd == True) or (self.layer == 'im') or (self.storage == 'none') or (self.ref_count == False) or (len(self.apis) == 0):
                mandatory_ref_count_attr = True
                ref_count_attr_count += 1
        assert mandatory_ref_count_attr == True, "Object " + self.name + " needs mandatory ref_count attribute"
        assert ref_count_attr_count == 1, "Object must have only one ref_count attribute/property"
        # lookup the parent if any
        if self.parent:
            self.parent = self._db.lookup_object(self.parent)
        if self.implements:
            self.implements = self._db.lookup_object(self.implements)
            self.implements.impl_by.append(self)
            self.implements.impl_by = sorted(self.implements.impl_by, key=lambda x: x.name)
        if self.layer == 'im':
            for p in self.properties: p.layer = self.layer
        self.ifcs_properties = [ p for p in self.properties if (p.key or p.layer == 'ifcs') ]
        self.im_properties = [ p for p in self.properties if (not p.key and p.layer == 'im') ]
        # list of optional properties where the values are not defined
        self.optional_properties = [ p for p in self.properties if p.optional ]

    def is_key_union(self):
        if not self.key_space == "heterogeneous":
            for pobj in self.ifcs_properties:
                if pobj.key and pobj.type.union:
                    return True
        return False

    def has_key(self):
        for pobj in self.ifcs_properties:
            if pobj.key :
                return True
        return False

    def has_editable(self):
        for pobj in self.ifcs_properties:
            # keys are not editable
            if pobj.key: continue
            if pobj.editable :
                return True
        return False

    def im_has_editable(self):
        for pobj in self.im_properties:
            # keys are not editable
            if pobj.key: continue
            if pobj.im_editable :
                return True
        return False

    def has_invalid(self):
        for pobj in self.ifcs_properties:
            # keys are not editable
            if pobj.key: continue
            if len(pobj.invalid) :
                return True
        return False

    def has_devices(self):
        for pobj in self.ifcs_properties:
            # keys are not editable
            if pobj.key: continue
            if pobj.devices:
                return True
        return False

    def key_count(self, ignore=False):
        count = 0
        for pobj in self.ifcs_properties:
            if pobj.key :
                count+= 1 if (ignore or not pobj.type.struct) else 2
        return count

    def key_name(self):
        count = 0
        kname = "obj.handle"
        k_obj = None
        for pobj in self.ifcs_properties:
            if pobj.key :
                k_obj = pobj
                count+= 1 if not pobj.type.struct else 2
        if count > 1:
            kname = self.key_alias
        elif count == 1:
            kname = "%s"%k_obj.name
        return kname

    def key_type(self):
        count = 0
        kname = "obj.handle"
        k_obj = None
        for pobj in self.ifcs_properties:
            if pobj.key :
                k_obj = pobj
                count+= 1 if not pobj.type.struct else 2
        if count > 1:
            kname = self.key_alias
        elif count == 1:
            kname = "%s"%k_obj.type.name
        return kname

    def key_ptr(self, ptr=True):
        count = 0
        kptr = ""
        for pobj in self.ifcs_properties:
            if pobj.key :
                count+= 1 if not pobj.type.struct else 2
        if count > 1:
            kptr = "*" if ptr else "&"
        return kptr

    def key_suf(self, ptr=True):
        count = 0
        ksuf = ""
        for pobj in self.ifcs_properties:
            if pobj.key :
                count+= 1 if not pobj.type.struct else 2
        if count > 1:
            ksuf = "_p"
        return ksuf

class Stats:
    def __init__(self, db, ydata):
        self._db    = db
        self._ydata = ydata

        self.name       = ydata['name']
        self.desc       = ydata['desc']
        self.apis       = [ "get-stats", "get-stats-detail", "clear-stats"] if 'apis' not in ydata else [a['name'] for a in ydata['apis']]
        self.properties = [Property(db, p) for p in ydata['properties']] if 'properties' in ydata else []
        self.properties_dict = dict ((p.name, p) for p in self.properties)
        self.ifcs_properties = [ p for p in self.properties if (p.layer == 'ifcs') ]
        self.im_properties = [ p for p in self.properties if (p.layer == 'im') ]

    def has_devices(self):
        for pobj in self.properties:
            if pobj.devices:
                return True
        return False

class Events:
    def __init__(self, db, ydata):
        self._db    = db
        self._ydata = ydata

        self.name       = ydata['name']
        self.desc       = ydata['desc']
        self.apis       = [ "register", "unregister"] if 'apis' not in ydata else [a['name'] for a in ydata['apis']]
        self.properties = [Property(db, p) for p in ydata['properties']] if 'properties' in ydata else []
        self.properties_dict = dict ((p.name, p) for p in self.properties)
        self.pd         = True if 'pd' == ydata['path'][0:2] else False
        self.pd_pkg     =  ydata['path'].split('/')[1] + '_' + ydata['path'].split('/')[3][:-5] if self.pd else ""

class Errors:
    def __init__(self, db, ydata):
        self._db    = db
        self._ydata = ydata

        self.name       = ydata['name']
        self.desc       = ydata['desc']

class Module:
    def __init__(self, db, ydata):
        self._db = db
        self._ydata = ydata
        self.name = ydata['module']
        self.alias = ydata['alias'] if 'alias' in ydata else ydata['module']
        self.api   = True if 'api' not in ydata else False if ydata['api'] == "no" else True
        self.full_api   = True if ('api' in ydata and ydata['api'] == "full") else False
        self.ifcs_only = True if ('api' in ydata and ydata['api'] == "ifcs") else False
        if 'dependency' not in ydata:
            log("dependency not given for " + self.name)
        self.sortorder   = 1000     # Default
        self.dependency   = ydata['dependency']
        if 'sortorder' in ydata:
            self.sortorder   = ydata['sortorder']
        self.pd_dependency   = ydata['pd-dependency'] if 'pd-dependency' in ydata else {}
        self._pd_pkgs = {}
        if 'types' in ydata:
            self._types = [ Type(db, t) for t in ydata['types'] ]
            self._pi_types = [ t for t in self._types if not t.pd ]
            self._pd_types = [ t for t in self._types if t.pd ]
            self._types_dict = dict( ( t.name, t) for t in self._types)
            for t in self._pd_types:
                self._pd_pkgs[t.pd_pkg] = 1
        else:
            self._types = []
            self._pi_types = []
            self._pd_types = []
            self._types_dict = {}
        if 'objects' in ydata:
            self._objects = [ Object(db, self, o) for o in ydata['objects'] ]
            self._pi_objects = [ o for o in self._objects if not o.pd ]
            self._pd_objects = [ o for o in self._objects if o.pd ]
            self._objects_dict = dict ((o.name, o) for o in self._objects)
            for t in self._pd_objects:
                self._pd_pkgs[t.pd_pkg] = 1
        else:
            self._objects = []
            self._pi_objects = []
            self._pd_objects = []
            self._objects_dict = []

        if 'stats' in ydata:
            self._stats = [ Stats(db, o) for o in ydata['stats'] ]
            self._pi_stats = [ o for o in self._stats if not o.pd ]
            self._pd_stats = [ o for o in self._stats if o.pd ]
            self._stats_dict = dict ((o.name, o) for o in self._stats)
            for t in self._pd_stats:
                self._pd_pkgs[t.pd_pkg] = 1
        else:
            self._stats = []
            self._pi_stats = []
            self._pd_stats = []
            self._stats_dict = []

        if 'events' in ydata:
            self._events = [ Events(db, o) for o in ydata['events'] ]
            self._pi_events = [ o for o in self._events if not o.pd ]
            self._pd_events = [ o for o in self._events if o.pd ]
            self._events_dict = dict ((o.name, o) for o in self._events)
            for t in self._pd_events:
                self._pd_pkgs[t.pd_pkg] = 1
        else:
            self._events = []
            self._pi_events = []
            self._pd_events = []
            self._events_dict = []

    def validate_module(self):
        if self._types:
            [t.validate_type() for t in self._types]
        if self._objects:
            [o.validate_object() for o in self._objects]

    def lookup_object(self, o):
        assert o in self._objects_dict, "Cannot find the Object " + o
        return self._objects_dict[o]

    def lookup_type(self, t):
        assert t in self._types_dict, "Cannot find the Type " + t
        return self._types_dict[t]

    def objects(self):
        return self._objects

    def pi_objects(self):
        return self._pi_objects

    def pd_objects(self):
        return self._pd_objects

    def types(self):
        return self._types

    def pi_types(self):
        return self._pi_types

    def pd_types(self):
        return self._pd_types

    def stats(self):
        return self._stats

    def pi_stats(self):
        return self._pi_stats

    def pd_stats(self):
        return self._pd_stats

    def events(self):
        return self._events

    def pi_events(self):
        return self._pi_events

    def pd_events(self):
        return self._pd_events

    def pd_pkgs(self):
        return compat_listkeys(self._pd_pkgs)

    def has_custom_types(self):
        for t in self._types:
            if t.struct or t.union or t.list or t.dyn_arr: return True
        return False
    def has_objects(self):
        return True if len(self._objects) > 0 else False

    def has_pi_objects(self):
        return True if len(self._pi_objects) > 0 else False

    def has_pd_objects(self):
        return True if len(self._pd_objects) > 0 else False

    def has_stats(self):
        return True if len(self._stats) > 0 else False

    def has_pi_stats(self):
        return True if len(self._pi_stats) > 0 else False

    def has_pd_stats(self):
        return True if len(self._pd_stats) > 0 else False

    def has_events(self):
        return True if len(self._events) > 0 else False

    def has_pi_events(self):
        return True if len(self._pi_events) > 0 else False

    def has_pd_events(self):
        return True if len(self._pd_events) > 0 else False

    def need_object_lookup(self):
        need_object_lookup = False
        for obj in self._pi_objects:
            if not obj.has_key(): need_object_lookup = True
        return need_object_lookup

    def need_object_lookup_key(self):
        need_object_lookup = False
        for obj in self._pi_objects:
            if obj.has_key(): need_object_lookup = True
        return need_object_lookup

class ObjectDataBase:
    def __init__(self, ydata, pkg):
        self._ydata = ydata
        if 'sai' in pkg:
            self._modules = collections.OrderedDict( ( mname, Module(self, module)) for (mname, module) in sorted(ydata.items()))
        else:
            self._modules = dict( ( mname, Module(self, module)) for (mname, module) in ydata.items()  )

    def validate_modules(self):
        [m.validate_module() for m in self._modules.values()]

    def lookup_object(self, name):
        # name in the format mod:obj
        m, o = name.split(':')
        return self._modules[m].lookup_object(o)

    def lookup_type(self, name):
        # name in the format mod:type
        m, t = name.split(':')
        return self._modules[m].lookup_type(t)

    def modules(self):
        return self._modules
