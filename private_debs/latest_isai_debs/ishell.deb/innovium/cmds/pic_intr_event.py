#-------------------------------------------------------------------------------
# Copyright (c) (2024) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import argparse
import copy
import ifcs_ctypes as ifcs
import distutils.util
from pencmd import penType
from utils.compat_util import *
from prettytable import PrettyTable
import datetime
from verbosity import *

default_isg_list = [0]
pen_fldid   = []
pen_fldname = []
pen_fldid_fldname = {}
pen_fldname_fldid = {}

serdes_group_dict = {'NONE': 0, 'ISG0': 1,
                     'ISG1': 2, 'ISG2': 3,
                     'ISG3': 4, 'ISG4': 5,
                     'ISG5': 6, 'ISG6': 7,
                     'ISG7': 8, 'ISG8': 9,
                     'ISG9': 10, 'ISG10': 11,
                     'ISG11': 12, 'ISG12': 13,
                     'ISG13': 14, 'ISG14': 15,
                     'ISG15': 16, 'ISG16': 17,
                     'ISG17': 18, 'ISG18': 19,
                     'ISG19': 20, 'ISG20': 21,
                     'ISG21': 22, 'ISG22': 23,
                     'ISG23': 24, 'ISG24': 25,
                     'ISG25': 26, 'ISG26': 27,
                     'ISG27': 28, 'ISG28': 29,
                     'ISG29': 30, 'ISG30': 31,
                     'ISG31': 32, 'MSER0': 33,
                     'ISG32': 34, 'ISG33': 35,
                     'ISG34': 36, 'ISG35': 37,
                     'ISG36': 38, 'ISG37': 39,
                     'ISG38': 40, 'ISG39': 41,
                     'ISG40': 42, 'ISG41': 43,
                     'ISG42': 44, 'ISG43': 45,
                     'ISG44': 46, 'ISG45': 47,
                     'ISG46': 48, 'ISG47': 49,
                     'ISG48': 50, 'ISG49': 51,
                     'ISG50': 52, 'ISG51': 53,
                     'ISG52': 54, 'ISG53': 55,
                     'ISG54': 56, 'ISG55': 57,
                     'ISG56': 58, 'ISG57': 59,
                     'ISG58': 60, 'ISG59': 61,
                     'ISG60': 62, 'ISG61': 63,
                     'ISG62': 64, 'ISG63': 65,
                     'ISG64': 66}

serdes_group_enum_to_str_dict = dict([(key, value) for value, key in serdes_group_dict.items()])

def pic_intr_mask_pen_info():
    pentype = penType(None, 0)
    pen_id, pen_name = pentype.get_id_name_from_str('PIC_INTR_PCI_MASK')
    nflds, fldinfo = pentype.get_flds_from_id(pen_id)

    for j in range(nflds.value):
        try:
            fldid, fldname = pentype.get_fld_id_name_from_str(
                fldinfo[j].fname)
            pen_fldid.append(fldid)
            pen_fldname.append(fldname)
            pen_fldid_fldname[fldid]   = fldname
            pen_fldname_fldid[fldname] = fldid
        except Exception as ex:
            log("get_pen_field: ", type(ex).__name__, ex.args)
            return ifcs_ctypes.IFCS_PARAM

    return

def parse_list(s):
    out = []
    if s == 'all':
        return []
    for item in s.split(','):
        if ':' in item:
            itemlist = item.split(':', 2)
        elif '-' in item:
            itemlist = item.split('-', 2)
        else:
            itemlist = [item]
        first = int(itemlist[0], 0)
        if len(itemlist) == 1:
            out.append(int(itemlist[0], 0))
        elif len(itemlist) == 2:
            last = int(itemlist[1], 0)
            if first <= last:
                for x in range(first, last+1):
                    out.append(x)
            else:
                for x in range(first, last-1, -1):
                    out.append(x)
        else:
            raise ValueError("Error parsing list argument")
    return out

def parse_dict(s):
    out = {}
    out = {k.upper():int(v) for k,v in (i.split(':') for i in s.split(','))}
    return out

def get_full_lane_list_pic_intr(args):
    global default_isg_list
    if args.isg_num is not None:
        if len(args.isg_num) == 1:
            if (args.isg_num[0]) > 63:
                raise ValueError("Invalid ISG number, valid choice [0...63]")
        if len(args.isg_num) > 1 and max(args.isg_num) > 63:
            raise ValueError("Invalid ISG number, valid choice [0...63]")
        if args.isg_num == []:   # 'all' was given
            args.isg_num = compat_listrange(64)
        default_isg_list = args.isg_num

    return default_isg_list

def do_for_lane_list_pic_intr(start_func, each_func, args):
    full_isg_list = get_full_lane_list_pic_intr(args)

    if full_isg_list is None:
        return

    if start_func is not None:
        start_func(full_isg_list, args)

    for isg in full_isg_list:
        # let the called function overwrite args without affecting other lanes
        args_subset = copy.deepcopy(args)
        serdes_group = serdes_group_dict['ISG'+ str(isg)]
        each_func(serdes_group, args_subset)

def multi_callback_pic_intr(start_func, each_func):
    """helper func to create a callback func for subcommands to manage default lanes and iterate"""
    return lambda args: do_for_lane_list_pic_intr(start_func, each_func, args)

def pic_intr_event_capture_enable(args):
    if args.enable:
        pic_intr_mask_pen_info()
        rc = ifcs.im_devport_pic_intr_event_init(0);
    else:
        rc = ifcs.im_devport_pic_intr_event_deinit(0);

    if rc != 0:
        log_err("Failed event capture enable/disable\n");
        return rc

def pic_intr_mask_set(isg, args):
    fld_dict = args.fld
    fldcnt = len(fld_dict)
    fldidx = (ifcs.c_uint32 * fldcnt)()
    fldval = (ifcs.c_uint32 * fldcnt)()

    idx = 0
    for fld, val in fld_dict.items():
        if fld not in pen_fldname:
            raise ValueError("Invalid field")
        if val != 0 and val != 1:
            raise ValueError("Invalid value for field")
        try:
            fldidx[idx] = pen_fldname_fldid[fld]
            fldval[idx] = val
            idx = idx + 1
        except Exception as ex:
            log(type(ex).__name__, ex.args)
            return ifcs_ctypes.IFCS_PARAM

    rc = ifcs.im_devport_pic_intr_mask_set(0, isg, compat_pointer(fldidx, ifcs.c_uint32),
                                           compat_pointer(fldval, ifcs.c_uint32), fldcnt);

    if rc != 0:
        log_err("Failed event capture enable/disable\n");
        return rc

def pic_intr_stats_get(isg, args):
    pic_intr_node_stats = ifcs.im_devport_pic_intr_node_stats_t()
    rc = ifcs.im_devport_pic_intr_node_stats_get(0, isg,
                        ifcs.pointer(pic_intr_node_stats));
    if rc != 0:
        log_err("Failed pic_intr_node_stats_get\n");
        return rc

    pic_intr_isg_total_count  = pic_intr_node_stats.pic_intr_isg_total_count

    if (pic_intr_isg_total_count == 0):
        return rc

    pic_intr_pen_stats = (ifcs.im_devport_pic_intr_pen_stats_t * pic_intr_isg_total_count)()
    rc = ifcs.im_devport_pic_intr_event_stats_get(0, isg, pic_intr_isg_total_count,
            compat_pointer(pic_intr_pen_stats, ifcs.im_devport_pic_intr_pen_stats_t));
    if rc != 0:
        log_err("Failed pic_intr_pen_stats_get\n");
        return rc

    if (pic_intr_isg_total_count):
        table = PrettyTable()
        table.align = "r"
        table.title = 'SERDES_GROUP: '+ str((serdes_group_enum_to_str_dict[isg]))
        table.field_names = ['Field', 'Count', 'Last updated']
        for idx in range(0,pic_intr_isg_total_count):
            dt   = datetime.datetime.fromtimestamp(pic_intr_pen_stats[idx].timestamp.tv_sec)
            usec = pic_intr_pen_stats[idx].timestamp.tv_usec
            date_us = dt + datetime.timedelta(microseconds=usec)
            table.add_row([pen_fldid_fldname[pic_intr_pen_stats[idx].pic_intr_cause_fname],
                           pic_intr_pen_stats[idx].cause_intr_total_count,
                           date_us])
        log(table)

    return rc

def pic_intr_stats_clear(isg, args):
    rc = ifcs.im_devport_pic_intr_event_stats_clear(0, isg);

    if rc != 0:
        log_err("Failed pic_intr_event_stats_clear\n");

    return rc

def add_parser(parser):
    subparser_pic_intr = parser.add_subparsers()

    parser_read = subparser_pic_intr.add_parser('capture', help='Enable/Disable PIC_INTR event capture')
    parser_read.add_argument('--enable', type=distutils.util.strtobool, default=False, help='True/False (Default:False)')
    parser_read.set_defaults(func=pic_intr_event_capture_enable)

    parser_read = subparser_pic_intr.add_parser('mask_set', help='Set/clear PIC INTR mask')
    parser_read.add_argument('--isg_num', type=parse_list, default=None, metavar='ISG_NUM_LIST',
                               help="ISG number or list or 'all'\nValid value range 0-63")
    parser_read.add_argument('--fld', type=parse_dict, default=None, required=True,
                help="comma-separated field:value pairs, e.g. PIC_RX_ERR_PROTOCOL_PORT0_F:1,MAC_RX_ERR_CRC_PORT0_F:0")
    parser_read.set_defaults(func=multi_callback_pic_intr(None, pic_intr_mask_set))

    parser_read = subparser_pic_intr.add_parser('stats_get', help='Get PIC INTR stats')
    parser_read.add_argument('--isg_num', type=parse_list, default=None, metavar='ISG_NUM_LIST',
                               help="ISG number or list or 'all'\nValid value range 0-63")
    parser_read.set_defaults(func=multi_callback_pic_intr(None, pic_intr_stats_get))

    parser_read = subparser_pic_intr.add_parser('stats_clear', help='Clear PIC INTR stats')
    parser_read.add_argument('--isg_num', type=parse_list, default=None, metavar='ISG_NUM_LIST',
                               help="ISG number or list or 'all'\nValid value range 0-63")
    parser_read.set_defaults(func=multi_callback_pic_intr(None, pic_intr_stats_clear))

def run_cmd(args):
    try:
        if type(args) == str:
            arglist = args.split()
        else:
            arglist = args
        arglist = ['--help' if a == 'help' else a for a in arglist]  # replace any 'help' arguments with '--help'

        parser = argparse.ArgumentParser(prog='debug device event pic_intr')
        add_parser(parser)
        args = parser.parse_args(arglist)
        rc = args.func(args)
        if rc == None:
            rc = ifcs.IFCS_SUCCESS
        return rc
    except ValueError as ex:
        log("Value Error: %s" % ":".join(ex.args))
    except Exception as ex:
        traceback.print_exc(file=sys.stdout)
        log("exception: %s %s" % (type(ex).__name__, ex.args))
    except:
        log_dbg(1, "Error in pic_intr_event run_cmd: {}".format(sys.exc_info()))
    return ifcs.IFCS_INVAL
