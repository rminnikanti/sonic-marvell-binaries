#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
from cmdmgr import Command
from verbosity import *
import time
from ctypes import *
from print_table import PrintTable
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']


# Class implements L2learn related command
class L2learn(Command):
    def __init__(self, cli):
        self.sub_cmds = {'info'    : self.info,
                         'flush'   : self.flush,
                        }
        self.cli = cli
        self.arg_list = []
        self.active_node = 0

    def set_active_node(self, node_id):
        self.active_node = node_id

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except:
            log_dbg(
                1, "OtherError in l2learn [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        return

    def info(self, args):
        table = PrintTable()
        table.add_row(['Learn mode', 'Learn Count'])

        rc = ifcs_ctypes.ifcs_status_t()
        attr = ifcs_ctypes.ifcs_attr_t()
        actual_count = c_uint32(0)
        learn_count = c_uint32(0)

        ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
        attr.id = ifcs_ctypes.IFCS_NODE_ATTR_L2_ENTRY_NOS_LEARN_AGE_MODE
        rc = ifcs_ctypes.im_node_attr_get(self.active_node, 1, pointer(attr),
                              pointer(actual_count));
        if (attr.value.data == ifcs_ctypes.IFCS_BOOL_TRUE):
            mode = 'NOS'
        else:
            mode = 'SDK'

        rc = ifcs_ctypes.im_l2_learn_count_get(self.active_node, pointer(learn_count))
        table.add_row([mode, str(learn_count.value)])

        table.print_table(brief=True)
        table.reset_table()

        return

    def flush(self, args):
        log("Flush L2 Learn DB")
        ifcs_ctypes.im_l2_learn_flush(self.active_node)
