#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
import argparse
import sys
import re
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from cli import IvmShell
from ctypes import *
ifcs_ctypes = sys.modules['ifcs_ctypes']


# Class implements Service related commands
class Service(Command):

    def __init__(self, cli):
        self.cli = cli
        self.arg_list = []
        super(Service, self).__init__()

        self.sub_cmds = {
            "remote_shell": self.service_remote_shell,
            "help": self.help,
            "?": self.help
        }

        self.sub_remote_shell_cmds = {"start": self.service_remote_shell_start}

    def run_cmd(self, args):
        log_dbg(1, "In service run {}".format(args))
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: {}".format(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except KeyError:
            log_dbg(
                1, "KeyError in service [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except Exception:
            log_dbg(
                1, "OtherError in service [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)
        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]
        elif remline == text:
            if "remote_shell" == cmd.rstrip():
                return [
                    j for j in self.sub_remote_shell_cmds.keys()
                    if j.startswith(text)
                ]
            else:
                return None
        else:
            try:
                return getattr(self, "complete_" + cmd)(cmd, remline, line,
                                                        text)
            except AttributeError:
                return None

    def complete_remote_shell(self, cmd, remline, line, text):
        return None

    def service_remote_shell(self, args):
        log_dbg(1, "In service remote shell")

        sub_cmds = self.sub_remote_shell_cmds
        for idx in range(2, len(self.arg_list)):
            if self.arg_list[idx] not in sub_cmds:
                log_err("Invalid command")
                raise KeyError(
                    "Invalid service remote shell command : {}".format(
                        self.arg_list[idx]))
            else:
                return sub_cmds[self.arg_list[idx]](args)
        log_err("Invalid command")
        raise KeyError("Incomplete service remote shell command")

    def service_remote_shell_start(self, args):
        log_dbg(1, "In service remote shell start")

        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        parser = argparse.ArgumentParser(
            description="Start remote shell server",
            prog="service remote_shell start",
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument("-l",
                            "-logfile",
                            action="store",
                            help="Server log file name",
                            dest="log_file",
                            default="",
                            required=False)
        parser.add_argument(
            "-f",
            "-flushinterval",
            action="store",
            help=
            "Server log file flush interval in seconds. 0 (flush after each command execution)",
            dest="flushinterval",
            default=60,
            required=False,
            type=int)
        parser.add_argument("-t",
                            "-type",
                            action="store",
                            help="Socket type",
                            dest="sock_type",
                            default="tcp",
                            choices=["tcp"],
                            required=False)
        # TCP server arguments
        tcp_args = parser.add_argument_group("TCP server arguments")
        tcp_args.add_argument("-p",
                              "-port",
                              action="store",
                              help="Server port",
                              dest="port",
                              default=7105,
                              required=False,
                              type=int)
        tcp_args.add_argument(
            "-a",
            "-hostaddr",
            action="store",
            help=
            "Server host. Options: localhost (recommended), all (for all interfaces)",
            dest="host",
            default="localhost",
            choices=["localhost", "all"],
            required=False)
        try:
            res = parser.parse_args(self.arg_list)
        except:
            if len(self.arg_list) == 1 and self.arg_list[0] in ["-h", "--help"]:
                return 0
            log("Missing arguments or invalid arguments provided")
            return ifcs_ctypes.IFCS_INVAL
        try:
            log_dbg(1, "In service remote shell start with res: {}".format(res))
            self.rshell = IvmShell()
            self.rshell.start_rshell(res.port, res.host, res.log_file,
                                     res.flushinterval)
        except Exception:
            log_dbg(
                1, "Exception running start_shell {}: {}".format(
                    args, sys.exc_info()))
            log_err("Failed to start remote shell server")
            return ifcs_ctypes.IFCS_INVAL

        return ifcs_ctypes.IFCS_SUCCESS

    #=========================================================
    # Extensive help
    #=========================================================

    remote_shell_help_str = """
usage: service remote_shell start [-h] [-l LOG_FILE] [-f FLUSHINTERVAL]
                                  [-t {tcp}] [-p PORT] [-a {localhost,all}]

Start remote shell server

optional arguments:
  -h, --help            show this help message and exit
  -l LOG_FILE, -logfile LOG_FILE
                        Server log file name (default: )
  -f FLUSHINTERVAL, -flushinterval FLUSHINTERVAL
                        Server log file flush interval in seconds. 0 (flush
                        after each command execution) (default: 60)
  -t {tcp}, -type {tcp}
                        Socket type (default: tcp)

TCP server arguments:
  -p PORT, -port PORT   Server port (default: 7105)
  -a {localhost,all}, -hostaddr {localhost,all}
                        Server host. Options: localhost (recommended), all
                        (for all interfaces) (default: localhost) """

    default_help_str = """
usage:
       service remote_shell start [-h] [-l LOG_FILE] [-f FLUSHINTERVAL]
                                  [-t {tcp}] [-p PORT] [-a {localhost,all}] """

    def help(self, args):
        self.help_menu = {
            "remote_shell": self.remote_shell_help_str,
            "help": self.default_help_str,
            "?": self.default_help_str,
        }
        arg_list = shlex.split(args)

        if len(arg_list) >= 2:
            if arg_list[-1] in {"help", "?"}:
                if arg_list[-2] in self.help_menu:
                    log(self.help_menu[arg_list[-2]])
                    return

        log(self.help_menu["help"])
        return
