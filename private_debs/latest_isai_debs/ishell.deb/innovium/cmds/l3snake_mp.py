#------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#------------------------------------------------------------------------------
#

import os
import shlex
import argparse
import itertools
import time
import random
import json
from verbosity import *
from ctypes import *
from utils.common_util import strToList
from utils.compat_util import *
from cmdmgr import Command
from collections import OrderedDict
from ifcs_cmds.sysport import Sysport as sysport
from ifcs_cmds.devport import Devport as Devport
from ifcs_cmds.node import Node as node
from print_table import PrintTable
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']

MAX_DEV_PORTS = 520

################################################################################
# Synopsis:
# This test case can be used for L3 snake test or for line rate test on SVK.
# Unidir, Bidir cross and Bidir straight configurations are supported
# Multiple snakes, each with its own independent config can be configured on
# disjoint sets of ports
#
# Usage:
# 1. Start CLI with port config file
#    Model: ./inno_cli.sh -c <config.yaml file>
#      SVK: ./boardcli.sh -c <config.yaml file>
# 2. node create 0
# 3. diagtest l3snake config -p <port_range> -lb <loopback_type> [-b|-bs] [-id <id_number>]
#    -p : list of ports is comma-separated or hyphen-separated, e.g. 1-32 or 1,3,5
#    -lb: loopback can be {NONE, PCS, PMA}. Default is NONE
#    -b : Bidir Cross config
#    -bs: Bidir Straight config
#         If neither -b or -bs is set then by default, unidir config is done
#    -id: Snake ID (range: 1-1023).
#         Optional parameter, set only if configuring multi-snake
#    At this stage all devports, sysports, l3vnis, interfaces, nexthops and
#    routes are created and configured.
# 4. diagtest l3snake start_traffic [-id <id_number>]
#    Inject CPU generated packets
# 5. diagtest l3snake stop_traffic [-id <id_number>]
#    Stop traffic
# 6. diagtest l3snake unconfig [-id <id_number>]
#    Negate all the configuration done in step 3.
# 7. All options are as follows:
# IVM:0>diagtest l3snake -h
#
#+----------------------------------------------------------------------+
#| Command       : Description                                          |
#|----------------------------------------------------------------------|
#| config        : Configure l3snake test                               |
#| config_show   : Show l3snake test configuration                      |
#| start_traffic : Start l3snake test traffic                           |
#| stop_traffic  : Stop l3snake test traffic                            |
#| gen_report    : Generate l3snake test report for given sampling time |
#| verify        : Verify if traffic is running on all configured ports |
#| unconfig      : Unconfigure l3snake test                             |
#+----------------------------------------------------------------------+
################################################################################

'''
L3Snake Class - Initialize and Setup the switch for L3Snake.

Configuration:
  IVM:0>diagtest l3snake config -p 1-32 -lb 'PCS' [-b|-bs] -id 2
  -p : list of ports is a comma-separated list or hyphen separated
  -lb: {NONE,PCS,PMA}    Loopback type (default: NONE)
  -id: ID                User defined snake id [1-1023] (default: None)
  -b : Bi-directional cross(2-3, 4-5,...,32-1) traffic from first and
       last ports (default: False)
  -bs: Bi-directional straight(1-2, 3-4,...,31-32) traffic from first
       and last ports (default: False)
  Ixia traffic can ingress on any port
  The other ports must be configured in internal loopback or have external loopback module
  The script does the following forwarding setup
    1. Ports put in internal loopback if specified using -lb option
    2. Sysports configured as L3PORT
    3. VRFs (L3VNIs) created, one per port
    4. L3 Interfaces created one per Sysport
    5. Nexthops created one per L3 interface
    6. Host Route entries (VRF, IP) -> NH (Intf, Dest Sysport) created.
       Packet snakes with below Routes:
       Route entry (VRF1, IP) -> NH1(Intf1, SP2)
       Route entry (VRF2, IP) -> NH2(Intf2, SP3)
       ..
       Route entry (VRF128, IP) -> NH0(Intf0, SP1)

Start traffic:
    IVM:0>diagtest l3snake start_traffic -id 2

Stop traffic:
    IVM:0>diagtest l3snake stop_traffic -id 2

Unconfig:
    IVM:0>diagtest l3snake unconfig -id 2

BIDIR
*****
Ports need to connected by physical wires in appropriate pattern for either bidir_cross or bidir_straight:

For example, for an 8 port switch we can have the following connection pattern:
BIDIR CROSS: 2-3, 4-5, 6-7, 8-1
BIDIR STRAIGHT: 1-2, 3-4, 5-6, 7-8

When we choose a subset of ports for testing bidir then the following rules need to be followed:
Rule A. If two ports are connected by a physical wire, then either BOTH or NONE of them must be in the subset
Rule B. Additionally, for bidir_cross as the first and last ports are connected by a physical wire, they
        BOTH must ALWAYS be in the subset of ports being tested
The ports form a sequence of pairs, with each pair connected by a physcial wire. Hence, the total number
of ports is even in number.


UNIDIR
******
It is assumed that each port has a loopback connection connecting its ingress to its egress.
The loopbacks can be either internal (PCS, PMA) or external (via a loopback module).
Since there are no physical connections between different ports, rules A and B do not apply and
hence we can specify any random subset out of the set of loopback connected ports.

External Traffic Stream Configuration
*************************************
If external traffic generator is used, the streams must be configured as follows:

UNIDIR
-- All ports have internal or external loopback
-- Ingress port will have external connection to traffic generator, so must have internal loopback
-- FWD: Ingress at any port

BIDIR CROSS
-- Ingress can be at any two ports which otherwise would be connected by a physical wire
-- FWD flow will ingress at LOWER numbered port, REV flow will ingress at HIGHER numbered port
For example:
FWD: Ingress at port 1
REV: Ingress at port n

BIDIR STRAIGHT
-- Ingress can be at any two ports which otherwise would be connected by a physical wire
-- FWD flow will ingress at HIGHER numbered port, REV flow will ingress at LOWER numbered port
For example:
FWD: Ingress at port 2
REV: Ingress at port 1

Packet headers are as follows:

L2 Header
=========
For FWD flows (bidir cross, unidir):
    dst_mac     : 00:03:00:00:00:01
    src_mac     : 00:03:00:00:00:02
For FWD flows (bidir straight):
    dst_mac     : 00:05:00:00:00:01
    src_mac     : 00:03:00:00:00:02
For REV flows (bidir cross, unidir):
    dst_mac     : 00:05:00:00:00:01
    src_mac     : 00:03:00:00:00:02
For REV flows (bidir straight):
    dst_mac     : 00:03:00:00:00:01
    src_mac     : 00:03:00:00:00:02

L3 Header
=========
For FWD flows:
    version        : 4
    ttl            : 255
    src            : 13.0.0.1
    dst            : 12.0.0.1
For REV flows:
    version        : 4
    ttl            : 255
    src            : 12.0.0.1
    dst            : 13.0.0.1
'''

def auto_int(x):
    return int(x, 0)

def config_show_sort_key(x):
    return x.id

SNAKE_UNCONFIG = 0
SNAKE_CONFIGD  = 1
SNAKE_RUNNING  = 2
SNAKE_STOPPED  = 3

# Object to store A "run" devport stats.
class DevportStats():
    def __init__(self):
        self.devport_rx_frames = [0] * MAX_DEV_PORTS
        self.devport_rx_bytes = [0] * MAX_DEV_PORTS
        self.devport_rx_gbps = [0] * MAX_DEV_PORTS
        self.devport_tx_frames = [0] * MAX_DEV_PORTS
        self.devport_tx_bytes = [0] * MAX_DEV_PORTS
        self.devport_tx_gbps = [0] * MAX_DEV_PORTS
        self.devport_rx_errors = [0] * MAX_DEV_PORTS
        self.devport_tx_errors = [0] * MAX_DEV_PORTS
        self.timestamp = [0] * MAX_DEV_PORTS
        self.devport_list = []
        self.lb_type = 0
        self.num_pkt = OrderedDict()
        self.node_id = 0
        self.verbose = 0
        self.time = 0
        self.intf_hdls    = OrderedDict()
        self.l3vni_hdls   = OrderedDict()
        self.nh_hdls      = OrderedDict()
        self.sysport_hdls = OrderedDict()
        self.intfmac1 = (0x00, 0x03, 0x00, 0x00, 0x00, 0x01)
        self.intfmac2 = (0x00, 0x05, 0x00, 0x00, 0x00, 0x01)
        self.ip1 = 0x0c000001
        self.ip2 = 0x0d000001
        self.id = 0
        self.type = 'None'
        self.state = SNAKE_UNCONFIG

    def display(self):
        log("\nSnake id           : %d" %(self.id))
        log("Loopback type      : %s" %(self.lb_type))
        log("Snake type         : %s" %(self.type))
        log("Number of packets:")
        for size, num in compat_iteritems(self.num_pkt):
            log("    Size: %4s, Packets: %s" %(size, num))

        header = []
        header.append('Devport')
        header.append('RX(frames)')
        header.append('RX(bytes)')
        header.append('RX(Gbps)')
        header.append('RX(error frames)')
        header.append('TX(frames)')
        header.append('TX(bytes)')
        header.append('TX(Gbps)')
        header.append('TX(error frames)')
        table = PrintTable()
        table.add_row(header)
        for p in range(MAX_DEV_PORTS):
            if p not in self.devport_list:
                continue
            devport_row = []
            devport_row.append(str(p))
            devport_row.append(str(self.devport_rx_frames[p]))
            devport_row.append(str(self.devport_rx_bytes[p]))
            devport_row.append(str('%.2f' %self.devport_rx_gbps[p]))
            devport_row.append(str(self.devport_rx_errors[p]))
            devport_row.append(str(self.devport_tx_frames[p]))
            devport_row.append(str(self.devport_tx_bytes[p]))
            devport_row.append(str('%.2f' %self.devport_tx_gbps[p]))
            devport_row.append(str(self.devport_tx_errors[p]))
            table.add_row(devport_row)
        table.print_table()
        table.reset_table()

    def display_config(self, id):
        for instance in L3snake.devport_stats_runs:
            if instance.id == id:
                devport_stats = instance
                table = PrintTable()
                header = []
                header.append("Devports")
                header.append("Loopback type")
                header.append("Snake id")
                header.append("Snake type")
                table.add_row(header)

                data = []
                data.append(str(devport_stats.devport_list)[1:-1])
                data.append(str(devport_stats.lb_type))
                data.append(str(id))
                data.append(str(devport_stats.type))
                table.add_row(data)
                table.print_table()
                table.reset_table()
                break


class L3snake(Command):
    # All runs' devport stats are saved in below list
    devport_stats_runs = []

    # Incremented for each run config (diagtest l3snake config)
    run = -1

    def __init__(self, cli, quiet="false"):
        self.sub_cmds = {
                         'config'       : self.config,
                         'config_show'  : self.config_show,
                         'start_traffic': self.start_traffic,
                         'stop_traffic' : self.stop_traffic,
                         'gen_report'   : self.gen_report,
                         'verify'       : self.verify,
                         'unconfig'     : self.unconfig,
                         'help'         : self.help,
                         '?'            : self.help
                        }
        self.cli = cli
        self.quiet = quiet
        self.arg_list = []
        self.device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)
        super(L3snake, self).__init__()

    def __del__(self):
        return

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[2]](args)
            return rc
        except (KeyError):
            log_dbg(1, "Invalid cmd")
            self.help(args)
            return ifcs_ctypes.IFCS_PARAM
        except Exception as ex:
            self.cli.error()
            self.help(args)

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['config', 'Configure l3snake test'])
        table.add_row(['config_show', 'Show l3snake test configuration'])
        table.add_row(['start_traffic', 'Start l3snake test traffic'])
        table.add_row(['stop_traffic', 'Stop l3snake test traffic'])
        table.add_row(['gen_report', 'Generate l3snake test report for given sampling time'])
        table.add_row(['verify', 'Verify if traffic is running on all configured ports'])
        table.add_row(['unconfig', 'Unconfigure l3snake test'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        l3snake_help_string = """
Usage::

    Type "diagtest l3snake <command>" followed by -h to see command's sub-options.
"""
        log(l3snake_help_string)

    def insert_run_data(self, run_data):
        # Increment run and insert run data
        L3snake.run += 1
        L3snake.devport_stats_runs.append(run_data)

    def get_run_data(self, run):
        return L3snake.devport_stats_runs[run]

    def get_cur_run_data(self):
        run = L3snake.run
        return L3snake.devport_stats_runs[run]

    def get_max_devport(self, node_id=0):
        # Do get all devport to figure out max devports configured
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            devport = arg
            devport_list.append(devport)

        devport_list = []

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t,
            c_uint32,
            POINTER(ifcs_ctypes.ifcs_attr_t),
            POINTER(None))
        callback = callback_type(myCallback)

        attr = ifcs_ctypes.ifcs_attr_t()
        ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
        ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE)
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH)

        try:
            rc = ifcs_ctypes.ifcs_devport_get_all(node_id, 1, pointer(attr), compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
            if ( rc != ifcs_ctypes.IFCS_SUCCESS):
                log("Failed to get all devport rc: {0}".format(rc))
        except:
            log("In except of devport get_all")
            pass

        return (len(devport_list))

    def configDevportGetSysportHandle(self, devport):
        '''
            Utility function that takes a devport
            and returns the handle to its corresponding
            sysport
        '''
        attr        =  ifcs_ctypes.ifcs_attr_t()
        count       =  c_uint32()
        attr.id     =  ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
        attr_count  =  1
        rc = ifcs_ctypes.ifcs_devport_attr_get(self.cli.node_id, devport, attr_count, pointer(attr),
                                   pointer(count))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Failed to get sysport for devport {0} rc={1}".format(devport, rc))
            return

        return attr.value.handle

    def configDevportSetAdminState(self, devport, admin_state):
        '''
            Utility function to configure devport's admin_state
        '''
        err = 0
        try:
            # Enable devport
            attr_list = (ifcs_ctypes.ifcs_attr_t * 3)()
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t))
            assert rc == ifcs_ctypes.IFCS_SUCCESS

            attr_count = 0
            attr_list[attr_count].id         = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE
            attr_list[attr_count].value.data = admin_state
            attr_count += 1

            if admin_state == ifcs_ctypes.IFCS_BOOL_TRUE and self.device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
                attr_list[attr_count].id        = ifcs_ctypes.IFCS_DEVPORT_ATTR_RX_EQ_FINE_TUNE
                attr_list[attr_count].value.u32 = ifcs_ctypes.IFCS_DEVPORT_SERDES_RX_EQ_FINE_TUNE_CONTINUOUS
                attr_count += 1

            rc = ifcs_ctypes.ifcs_devport_attr_set(self.cli.node_id,
                                       devport,
                                       attr_count,
                                       compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t))
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "ifcs_devport_attr_set ADMIN_STATE failed: rc={0} ".format(rc)
        except:
            log("Set devport admin state failed")
            err = 1

        return err

    def configSysportSetFwdMode(self, devport_stats, mode=ifcs_ctypes.IFCS_SYSPORT_FWD_MODE_L3_ONLY):
        '''
            Utility function to set sysports FWD MODE. Default mode in this API is L3_ONLY
        '''
        err = 0
        try:
            log_dbg(1, "Configure sysports as L3PORT")
            sysport_hdls = devport_stats.sysport_hdls
            # Set sysport's PORT_FWD_MODE to given mode
            for port in devport_stats.devport_list:
                attr = ifcs_ctypes.ifcs_attr_t()
                rc = ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS

                # Get PORT_FWD_MODE
                attr.id        = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_FWD_MODE
                actual_count   = c_uint32()
                actual_count_p = pointer(actual_count)

                rc = ifcs_ctypes.ifcs_sysport_attr_get(self.cli.node_id,
                                           sysport_hdls[port],
                                           1,
                                           pointer(attr),
                                           actual_count_p)
                if attr.value.u32 == mode:
                    continue

                # Set PORT_FWD_MODE
                attr.value.u32 = mode
                attr_count = 1
                rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id,
                                                sysport_hdls[port],
                                                attr_count,
                                                pointer(attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "sysport setAttr failed: port: {0}, rc :{1}".format(
                     port, rc)

                log_dbg(1, "   Configured sysports as L3PORT successfully")
        except:
            log("Error setting devport fwd mode to L3")
            err = 1

        return err

    def configDevportsEnable(self, devport_stats):
        #Set devport admin state back to UP
        err = 0
        try:
            log_dbg(1, "Enabling devports")
            for port in devport_stats.devport_list:
                self.configDevportSetAdminState(port, ifcs_ctypes.IFCS_BOOL_TRUE)
            log_dbg(1, "   Enabled devports successfully")
        except:
            log("Error setting devport admin state to UP")
            err = 1
        return err

    def configDevportsDisable(self, devport_stats):
        #Set devport admin state to DOWN
        err = 0
        try:
            log_dbg(1, "Disabling ports")
            for port in devport_stats.devport_list:
                self.configDevportSetAdminState(port, ifcs_ctypes.IFCS_BOOL_FALSE)
            log_dbg(1, "   Disabled devports successfully")
        except:
            log("Error setting devport admin state to DOWN")
            err = 1
        return err

    def configDevportsLoopback(self, devport_stats, loopback_type='NONE'):
        log_dbg(1, "Setting Loopback type for all ports")
        err = 0
        try:
            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            if (loopback_type == 'PCS'):
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PCS
            elif (loopback_type == 'PMA'):
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PMA
            elif (loopback_type == 'NONE'):
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE
            else:
                log("Invalid loopback type specified: {0}".format(loopback_type))
                lb_config_failed = 1
                return lb_config_failed

            # Set loopback type for all devports
            for port in devport_stats.devport_list:
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
                devport_attr[0].value.u32 = lb
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Devport loopback set to {0} FAILED. port={1} rc=[{2}]".format(loopback_type, port, rc)
            log_dbg(1, "   Set loopback type successfully")

        except:
            log("Hit except (Devport loopback) config")
            err = 1

        return err

    def configL3vniCreate(self, devport_stats):
        '''
            Utility function to create one L3VNI per port
        '''
        err = 0
        try:
            log_dbg(1, "Creating L3VNIs")
            l3vni_hdls = devport_stats.l3vni_hdls
            for port in devport_stats.devport_list:
                attr         = ifcs_ctypes.ifcs_attr_t()
                attr_count   = 0
                handle       = ifcs_ctypes.ifcs_handle_t()
                handle.value = ifcs_ctypes.IFCS_HANDLE_L3VNI(port)
                rc = ifcs_ctypes.ifcs_l3vni_create(self.cli.node_id,
                                       pointer(handle),
                                       attr_count,
                                       pointer(attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create l3vni {0} ret: {1}".format(port, rc)
                l3vni_hdls[port] = handle

            log_dbg(1, "   Created L3VNIs successfully")
        except:
            log("L3vni create failed")
            err = 1

        return err

    def configIntfCreate(self, devport_stats):
        '''
            Utility function to create L3 Interfaces
        '''
        err = 0
        try:
            log_dbg(1, "Creating L3 interfaces")

            flag = True
            l3vni_hdls = devport_stats.l3vni_hdls
            sysport_hdls = devport_stats.sysport_hdls
            intf_hdls = devport_stats.intf_hdls
            for port in devport_stats.devport_list:
                if flag is True:
                    transportMac = devport_stats.intfmac1
                    flag = False
                else:
                    transportMac = devport_stats.intfmac2
                    flag = True

                attr_list  = (ifcs_ctypes.ifcs_attr_t * 10)()
                attr_count = 0
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TYPE
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_INTF_TYPE_L3PORT
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_FORWARDING_INSTANCE
                attr_list[attr_count].value.handle = l3vni_hdls[port]
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TRANSPORT_INSTANCE
                attr_list[attr_count].value.handle = sysport_hdls[port]
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TRANSPORT_MAC
                attr_list[attr_count].value.mac    = transportMac
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_IPV4_UNICAST_ENABLE
                attr_list[attr_count].value.data   = True
                attr_count += 1

                handle = ifcs_ctypes.ifcs_handle_t()
                handle.value = ifcs_ctypes.IFCS_NULL_HANDLE
                rc = ifcs_ctypes.ifcs_intf_create(self.cli.node_id, pointer(handle), attr_count, attr_list)
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create intf " + str(port) + "ret: " + str(rc)
                intf_hdls[port] = handle

            log_dbg(1, "   Created L3 interfaces successfully")
        except:
            log("Error creating L3 interfaces")
            err = 1

        return err

    def configNexthopCreate(self, devport_stats):
        '''
            Utility function to create Nexthops
        '''
        err = 0
        try:
            log_dbg(1, "Creating Nexthops")
            intf_hdls = devport_stats.intf_hdls
            sysport_hdls = devport_stats.sysport_hdls
            nh_hdls = devport_stats.nh_hdls
            flag = True
            for port in devport_stats.devport_list:
                if flag is False:
                    dest_mac = devport_stats.intfmac1
                    flag = True
                else:
                    dest_mac = devport_stats.intfmac2
                    flag = False

                attr_list = (ifcs_ctypes.ifcs_attr_t * 10)()
                attr_count = 0
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_INTF
                attr_list[attr_count].value.handle = intf_hdls[port]
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_DEST_MAC
                attr_list[attr_count].value.mac    = dest_mac
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_LOCAL_DESTINATION
                attr_list[attr_count].value.handle = sysport_hdls[port]
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_NO_DECREMENT_TTL
                attr_list[attr_count].value.u8     = 1
                attr_count += 1

                handle       = ifcs_ctypes.ifcs_handle_t()
                handle.value = ifcs_ctypes.IFCS_NULL_HANDLE
                rc = ifcs_ctypes.ifcs_nexthop_create(self.cli.node_id,
                                         pointer(handle),
                                         attr_count,
                                         attr_list)
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create nexthop {0} ret: {1}".format(port, rc)
                nh_hdls[port] = handle

            log_dbg(1, "   Created Nexthops successfully")
        except:
            log("Error creating nexthops")
            err = 1

        return err

    def configRouteCreateInternal(self, devport_stats, config_fwd=True):
        err = 0
        try:
            l3vni_hdls = devport_stats.l3vni_hdls
            nh_hdls = devport_stats.nh_hdls

            fwd_policy             =  ifcs_ctypes.ifcs_fwd_policy_t()
            fwd_policy.fwd_action  =  ifcs_ctypes.IFCS_FWD_ACTION_FORWARD
            # configure same ip in all VRF aka L3VNI
            ip_addr   = ifcs_ctypes.ifcs_ip_addr_t()
            mask      = ifcs_ctypes.ifcs_ip_addr_t()
            mask.ipv4 =  0xfffffffe

            log_dbg(1, "Creating Route entries")

            if devport_stats.type == 'unidir' and config_fwd == False:
                log_dbg(1, "ERROR: Incorrect Params, can not configure reverse routes for unidir snake")
                return 'FAILED'

            if config_fwd == True:
                # configure FWD routes
                # set FWD ip addr
                ip_addr.ipv4 = devport_stats.ip1
                # set FWD port list
                port_list = devport_stats.devport_list
            else:
                # configure REV routes
                # set REV ip addr
                ip_addr.ipv4 = devport_stats.ip2
                # set REV port list
                port_list = [i for i in reversed(devport_stats.devport_list)]

            '''
            Bidir Cross
            Fwd Flow: (Ixia -> 1 (->2); 2 -> 3(->4), 4 -> Ixia ... )
                > Incoming on Odd ports, Outgoing on Even ports

            Rev Flow: (Ixia -> 4 (->3); 3 -> 2(->1); 1 -> Ixia ... )
                > Incoming on Even ports, Outgoing on Odd ports

            Bidir Straight
            Fwd Flow: (Ixia -> 1; 1<->2(->3); 3<->4; 4 -> Ixia ... )
                > Incoming on Odd ports, Outgoing on Even ports

            Rev Flow: (Ixia -> 4; 4<->3(->2); 2<->1; 1 -> Ixia ... )
                > Incoming on Even ports, Outgoing on Odd ports
            '''
            for i, port in enumerate(port_list):
                # FWD/REV BIDIR_CROSS : ingress is on every other port starting from the 1st port
                #      in the port list
                # So, skip alternate ports starting from the second port
                #
                # FWD/REV BIDIR_STRAIGHT : ingress is on every other port starting from the 2nd port
                #      in the reversed port list
                # So, skip alternate ports starting from the first port
                #
                # FWD UNIDIR : ingress is on each port as all ports are in loopback mode
                # So, do not skip any port
                if (devport_stats.type == 'bidir_cross' and (i % 2)) or (devport_stats.type == 'bidir_straight' and (i % 2 == 0)):
                    continue

                # Last route should map to port1 nh
                if port == port_list[-1]:
                    nh4_1 = nh_hdls[port_list[0]]
                else:
                    nh4_1 = nh_hdls[port_list[i+1]]

                # Create key
                ip_dest = ifcs_ctypes.ifcs_ip_prefix_t()
                ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_dest))
                ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
                ifcs_ctypes.ifcs_ip_prefix_t_addr_set(pointer(ip_dest), pointer(ip_addr))
                ifcs_ctypes.ifcs_ip_prefix_t_mask_set(pointer(ip_dest), pointer(mask))

                route_entry_key = ifcs_ctypes.ifcs_route_entry_key_t()
                ifcs_ctypes.ifcs_route_entry_key_t_init(pointer(route_entry_key))
                ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_entry_key),
                    ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
                ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_entry_key),
                    route_entry_key.key.ip_dest_l3vni)
                ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_l3vni_set(pointer(route_entry_key.key.ip_dest_l3vni),
                    l3vni_hdls[port])
                ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_entry_key.key.ip_dest_l3vni),
                    pointer(ip_dest))

                attr_list                              =   (ifcs_ctypes.ifcs_attr_t * 10)()
                attr_count                             =   0
                attr_list[attr_count].id               =   ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_NEXTHOP
                attr_list[attr_count].value.handle     =   nh4_1
                attr_count += 1

                attr_list[attr_count].id               =   ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY
                attr_list[attr_count].value.fwd_policy =   fwd_policy
                attr_count += 1

                rc =   ifcs_ctypes.ifcs_route_entry_create(self.cli.node_id,
                                               pointer(route_entry_key),
                                               attr_count,
                                               attr_list)
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create route entry for port {0} ret: {1}".format(port, rc)
            log_dbg(1, "   Created {0} route entries successfully".format(devport_stats.type))
        except:
            log("Error creating route entries")
            err = 1

        return err

    def configRouteCreate(self, devport_stats):
        '''
            Utility function to create Route entries
        '''
        # Create FWD route entries
        err = self.configRouteCreateInternal(devport_stats, True)
        if err:
            return err
        # Create REV route entries (needed only for bidir)
        if devport_stats.type == 'bidir_cross' or devport_stats.type == 'bidir_straight':
            err = self.configRouteCreateInternal(devport_stats, False)

        return err

    def configRouteDeleteInternal(self, devport_stats, del_fwd=True):
        err =0
        try:
            def myCallback(node_id, arg, attr_count, attr_list, user_data):
                key_obj = ifcs_ctypes.ifcs_route_entry_key_t()
                memmove(pointer(key_obj), arg, sizeof(key_obj))
                route_entry_list.append(pointer(key_obj))

            route_entry_list = []

            callback_type = CFUNCTYPE(ifcs_ctypes.UNCHECKED(None),
                                      ifcs_ctypes.ifcs_node_id_t,
                                      POINTER(ifcs_ctypes.ifcs_route_entry_key_t),
                                      c_uint32,
                                      POINTER(ifcs_ctypes.ifcs_attr_t),
                                      POINTER(None))
            callback = callback_type(myCallback)

            log_dbg(1, "Deleting Route entries")

            nh_hdls = devport_stats.nh_hdls

            if devport_stats.type == 'unidir' and del_fwd == False:
                log_dbg(1, "ERROR: Incorrect Params, can not delete reverse routes for unidir snake")
                return 'FAILED'

            if del_fwd == True:
                # set FWD port list
                port_list = devport_stats.devport_list
            else:
                # set REV port list
                port_list = [i for i in reversed(devport_stats.devport_list)]

            for i, port in enumerate(port_list):
                # FWD/REV BIDIR_CROSS : ingress is on every other port starting from the 1st port
                #      in the port list
                # So, skip alternate ports starting from the second port
                #
                # FWD/REV BIDIR_STRAIGHT : ingress is on every other port starting from the 2nd port
                #      in the reversed port list
                # So, skip alternate ports starting from the first port
                #
                # FWD UNIDIR : ingress is on each port as all ports are in loopback mode
                # So, do not skip any port
                if (devport_stats.type == 'bidir_cross' and (i % 2)) or (devport_stats.type == 'bidir_straight' and (i % 2 == 0)):
                    continue

                # Last route should map to port1 nh
                if port == port_list[-1]:
                    nh4_1 = nh_hdls[port_list[0]]
                else:
                    nh4_1 = nh_hdls[port_list[i+1]]

                attr_list                              =   (ifcs_ctypes.ifcs_attr_t * 10)()
                attr_count                             =   0
                attr_list[attr_count].id               =   ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_NEXTHOP
                attr_list[attr_count].value.handle     =   nh4_1
                attr_count                            +=   1

                rc = ifcs_ctypes.ifcs_route_entry_get_all(self.cli.node_id,
                                              None,
                                              attr_count,
                                              attr_list,
                                              compat_funcPointer(callback, ifcs_ctypes.ifcs_route_entry_user_cb_t),
                                              None,
                                              None)
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Route entry get failed for port {0}: rc {1}".format(port, rc)

            for route in route_entry_list:
                rc = ifcs_ctypes.ifcs_route_entry_delete(self.cli.node_id,
                                             route)
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Route entry delete failed: rc {0}".format(rc)

            log_dbg(1, "   Deleted {0} route entries successfully".format(devport_stats.type))
        except:
            log("Error deleting route entries")
            err = 1

        return err

    def configRouteDelete(self, devport_stats):
        '''
            Utility function to delete route entries
        '''
        # Delete FWD route entries
        err = self.configRouteDeleteInternal(devport_stats, True)
        if err:
            return err
        # Delete REV route entries (needed only for bidir)
        if devport_stats.type == 'bidir_cross' or devport_stats.type == 'bidir_straight':
            err = self.configRouteDeleteInternal(devport_stats, False)

        return err

    def configNexthopDelete(self, devport_stats):
        err = 0
        try:
            log_dbg(1, "Deleting nexthops")

            for port in devport_stats.nh_hdls:
                handle = devport_stats.nh_hdls[port]
                rc = ifcs_ctypes.ifcs_nexthop_delete(self.cli.node_id,
                                         handle)
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Nexthop: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted nexthops successfully")
        except:
            log("Error deleting nexthops")
            err = 1
        return err

    def configIntfDelete(self, devport_stats):
        err = 0
        try:
            log_dbg(1, "Deleting interfaces")
            for port in devport_stats.intf_hdls:
                handle = devport_stats.intf_hdls[port]
                rc = ifcs_ctypes.ifcs_intf_delete(self.cli.node_id,
                                      handle)
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Intf: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted interfaces successfully")
        except:
            log("Error deleting L3 interfaces")
            err = 1
        return err

    def configL3vniDelete(self, devport_stats):
        err = 0
        try:
            log_dbg(1, "Deleting L3VNIs")
            for port in devport_stats.l3vni_hdls:
                handle = devport_stats.l3vni_hdls[port]
                rc = ifcs_ctypes.ifcs_l3vni_delete(self.cli.node_id,
                                       handle)
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "L3VNI: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted L3VNIs successfully")
        except:
            log("Error deleting L3 vnis")
            err = 1
        return err

    def compute_l3_header_checksum(self, header, header_size):
        num_bytes = header_size
        offset = 0
        checksum = 0
        while num_bytes > 0:
            data_16_bit = 0
            data_16_bit += (header[offset] << 8) & 0xff00
            data_16_bit += header[offset+1] & 0xff

            offset += 2
            num_bytes -= 2

            #log("data %d"%(data_16_bit))
            checksum += data_16_bit
            checksum = (checksum >> 16) + (checksum & 0xffff)

        return (~checksum & 0xffff)

    def build_l3_packet(self, length, payload_type, seed, devport_stats, is_fwd=True, payload_data=0):

        '''
            outer_etherlayer:
                type    : Ether
                pkt_fields :
                For FWD flows (bidir cross, unidir):
                    dst     : 00:03:00:00:00:01
                    src     : 00:03:00:00:00:02
                For FWD flows (bidir straight):
                    dst     : 00:05:00:00:00:01
                    src     : 00:03:00:00:00:02
                For REV flows (bidir cross, unidir):
                    dst     : 00:05:00:00:00:01
                    src     : 00:03:00:00:00:02
                For REV flows (bidir straight):
                    dst     : 00:03:00:00:00:01
                    src     : 00:03:00:00:00:02

            outer_iplayer:
                type    : IP
                pkt_fields:
                For FWD flows:
                    version        : 4
                    ttl            : 255
                    src            : 13.0.0.1
                    dst            : 12.0.0.1
                For REV flows:
                    version        : 4
                    ttl            : 255
                    src            : 12.0.0.1
                    dst            : 13.0.0.1
        '''
        ether_header_size = 14
        data_bytes = compat_chr(0x00)
        if is_fwd == True:
            if devport_stats.type == 'unidir' or devport_stats.type == 'bidir_cross':
                data_bytes += compat_chr(0x03)
            else:
                data_bytes += compat_chr(0x05)
        else: # REV
            if devport_stats.type == 'unidir' or devport_stats.type == 'bidir_cross':
                data_bytes += compat_chr(0x05)
            else:
                data_bytes += compat_chr(0x03)

        data_bytes += compat_chr(0x00)
        data_bytes += compat_chr(0x00)
        data_bytes += compat_chr(0x00)
        data_bytes += compat_chr(0x01)
        data_bytes += compat_chr(0x00)
        data_bytes += compat_chr(0x03)
        data_bytes += compat_chr(0x00)
        data_bytes += compat_chr(0x00)
        data_bytes += compat_chr(0x00)
        data_bytes += compat_chr(0x02)
        data_bytes += compat_chr(0x08)
        data_bytes += compat_chr(0x00)

        ipv4_header_size = 20
        ipv4_header = {}
        ipv4_header[0] = 0x45
        ipv4_header[1] = 0x00

        # total length
        ipv4_total_length = length - ether_header_size
        ipv4_header[2] = (ipv4_total_length >> 8) & 0xff
        ipv4_header[3] = ipv4_total_length & 0xff

        ipv4_header[4] = 0x00
        ipv4_header[5] = 0x01
        ipv4_header[6] = 0x00
        ipv4_header[7] = 0x00
        ipv4_header[8] = 0xff
        ipv4_header[9] = 0x00

        # L3 header checksum to be computed
        ipv4_header[10] = 0x00
        ipv4_header[11] = 0x00
        if is_fwd == True:
            ipv4_header[12] = 0x0d
        else:
            ipv4_header[12] = 0x0c
        ipv4_header[13] = 0x00
        ipv4_header[14] = 0x00
        ipv4_header[15] = 0x01
        if is_fwd == True:
            ipv4_header[16] = 0x0c
        else:
            ipv4_header[16] = 0x0d

        ipv4_header[17] = 0x00
        ipv4_header[18] = 0x00
        ipv4_header[19] = 0x01

        checksum = self.compute_l3_header_checksum(ipv4_header, ipv4_header_size)
        #log("L3_header_checksum: %d"%(checksum))

        # fill in the computed l3 header checksum
        l3_header_checksum_offset = 10
        ipv4_header[l3_header_checksum_offset] = (checksum >> 8) & 0xff
        ipv4_header[l3_header_checksum_offset+1] = checksum & 0xff

        for i in range(ipv4_header_size):
            data_bytes += compat_chr(ipv4_header[i])

        if (seed != 0):
            random.seed(seed)

        curByte = 65
        payload_data_odd_byte = payload_data & 0xff
        payload_data_even_byte = (payload_data >> 8) & 0xff
        if (payload_data_even_byte == 0):
            payload_data_even_byte = payload_data_odd_byte

        for j in range(length - (ether_header_size + ipv4_header_size)):
            if (payload_type == 'stress' or payload_type == 'rrstress'):
                curByte = random.randint(0, 255)
                data_bytes += compat_chr(curByte)
            elif (payload_type == 'incremental'):
                data_bytes += compat_chr(curByte)
                curByte = (curByte + 1) & 0xff
            elif (payload_type == 'custom'):
                if (j%2):
                    #odd byte position
                    data_bytes += compat_chr(payload_data_odd_byte)
                else:
                    #even byte position
                    data_bytes += compat_chr(payload_data_even_byte)
            else:
                data_bytes += compat_chr(0)
        return data_bytes

    def send_l3_packet(self, devport, pdata, length):
        # Set dsp to egress port and tx_type to BYPASS.
        # Packet goes out directly on egress port without forwarding lookup
        # since tx_type is set to BYPASS
        try:
            packet = ifcs_ctypes.ifcs_hostif_packet_info_t()
            ifcs_ctypes.ifcs_hostif_packet_info_t_init(byref(packet))
            packet.tx_type = ifcs_ctypes.IFCS_HOSTIF_TX_TYPE_PIPELINE_BYPASS
            dport = devport
            packet.dsp = self.configDevportGetSysportHandle(dport)
            packet.pkt_buf = pdata
            packet.pkt_buf_len = length
        except Exception as e:
            log("exc", e)

        while (1):
            rc = ifcs_ctypes.ifcs_hostif_send_packet(self.cli.node_id, pointer(packet))
            if (rc == ifcs_ctypes.IFCS_SUCCESS):
               break
            if (rc != ifcs_ctypes.IFCS_BUSY):
                log_err("Packet send to pcie failed")
                log('Packet send to pcie failed, rc %d' %(rc))
                return 'FAILED'
            time.sleep(0.001)

        return 'SUCCESS'

    def start_traffic(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='L3snake test start_traffic', prog='l3snake start_traffic', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=None, help='Snake id. Needed if more than one snake configured')
        parser.add_argument('-n', type=int, default=100, help='Number of packets')
        parser.add_argument('-s', type=int, default=1500, help='Packet size')
        parser.add_argument('-payload', type=str, choices=['zero', 'incremental', 'stress', 'rrstress', 'custom'], default='incremental', help='Packet payload')
        parser.add_argument('-seed', type=int, default=0, help='Seed value. Used if payload is of type stress')
        parser.add_argument('-custom_value', type=auto_int, default=0, help='16-bit Custom payload. Used if payload is of type custom')
        parser.add_argument('-v', help='Verbose', action="store_true")
        try:
            res = parser.parse_args(self.arg_list)
        except:
            return 'FAILED'

        if res.id:
            if res.id == -1:
                devport_stats = self.get_cur_run_data()
            else:
                find = False
                for instance in L3snake.devport_stats_runs:
                    if instance.id == res.id:
                        devport_stats = instance
                        find = True
                        break
                if find == False:
                    log("L3Snake with id ", res.id, " does not exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3snake.devport_stats_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to start traffic on a specific snake")
                return 'FAILED'
            devport_stats = self.get_cur_run_data()

        length = res.s
        num_pkt = res.n
        payload = res.payload
        seed = res.seed
        payload_data = res.custom_value

        if seed and payload != 'stress':
            log("ERROR: seed can be used only with payload of type stress")
            return 'FAILED'

        if payload_data and payload != 'custom':
            log("ERROR: custom_value can be used only with payload of type custom")
            return 'FAILED'

        max_custom_val = 0xffff
        if payload_data and payload_data not in range(max_custom_val):
            log("ERROR: custom_value valid range is 0-{0}".format(max_custom_val))
            return 'FAILED'

        try:
            devport_stats.num_pkt[length] += num_pkt
        except (KeyError):
            devport_stats.num_pkt[length] = num_pkt


        if (length < 64):
            length = 64


        length = length - 4
        port_list = []
        is_fwd = True
        # Start traffic. For first packet injected from CPU:
        # FWD direction - bidir_cross: egress port=2, bidir_straight: egress port=1, unidir: egress port=1
        # REV direction - bidir_cross: egress port=n-1, bidir_straight: egress port=n, unidir: not required
        if devport_stats.type == 'bidir_cross':
            port_list = [devport_stats.devport_list[1], devport_stats.devport_list[-2]]
        elif devport_stats.type == 'bidir_straight':
            port_list = [devport_stats.devport_list[0], devport_stats.devport_list[-1]]
        else:
            port_list = [devport_stats.devport_list[0]]

        for i, devport in enumerate(port_list):
            if (i == 0):
                port = devport_stats.devport_list[0]
                is_fwd = True
            else:
                port = devport_stats.devport_list[-1]
                is_fwd = False

            log("Injecting {0} packets at devport {1}".format(num_pkt, port))
            data = self.build_l3_packet(length, payload, seed, devport_stats, is_fwd, payload_data)
            pdata = cast(data, c_void_p)

            for loop in range(0, num_pkt):
                if (res.v == True):
                    import pprint
                    pprint.pprint("Packet {0}:".format(loop+1))
                    log(":".join("{:02x}".format(compat_ord(c)) for c in data))

                ret_str = self.send_l3_packet(devport, pdata, length)
                if (ret_str != 'SUCCESS'):
                    return ret_str

                if (res.payload == 'rrstress'):
                    # Generate new random content
                    data = self.build_l3_packet(length, payload, 0, devport_stats, is_fwd, payload_data)
                    pdata = cast(data, c_void_p)

        devport_stats.state = SNAKE_RUNNING
        return 'PASS'

    def stop_traffic(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='L3snake test stop_traffic', prog='l3snake stop_traffic', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=None, help='Snake id. Needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except:
            return 'FAILED'

        if res.id:
            if res.id == -1:
                devport_stats = self.get_cur_run_data()
            else:
                find = False
                for instance in L3snake.devport_stats_runs:
                    if instance.id == res.id:
                        devport_stats = instance
                        find = True
                        break
                if find == False:
                    log("L3Snake with id ", res.id, " does not exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3snake.devport_stats_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            devport_stats = self.get_cur_run_data()

        sysport_hdls = devport_stats.sysport_hdls
        devport_obj = Devport(self.cli)

        verbose = devport_stats.verbose
        devport_list = devport_stats.devport_list

        l3vni_hdls = devport_stats.l3vni_hdls

        # Configure same ip in all VRF aka L3VNI
        ipSubnet  = ifcs_ctypes.ifcs_ip_addr_t()
        mask      = ifcs_ctypes.ifcs_ip_addr_t()
        mask.ipv4 =  0xfffffffe
        log_dbg(1, "Creating drop route entries")
        # Bidir: Set one route to drop for FWD flow and one route to drop for REV flow.
        # Unidir: Set one route to drop for the only flow.
        # This will stop traffic since we have a snake traffic pattern
        if devport_stats.type == 'bidir_cross':
            drop_port_list = [devport_list[0], devport_list[-1]]
        elif devport_stats.type == 'bidir_straight':
            drop_port_list = [devport_list[1], devport_list[-2]]
        else: #unidir
            drop_port_list = [devport_list[0]]
        route_entry_key_list = []

        for i, drop_port in enumerate(drop_port_list):
            # Create key
            if i == 0: # FWD flow
                ipSubnet.ipv4 = devport_stats.ip1
            elif i == 1: # REV flow
                ipSubnet.ipv4 = devport_stats.ip2

            ip_dest = ifcs_ctypes.ifcs_ip_prefix_t()
            ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_dest))
            ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
            ifcs_ctypes.ifcs_ip_prefix_t_addr_set(pointer(ip_dest), pointer(ipSubnet))
            ifcs_ctypes.ifcs_ip_prefix_t_mask_set(pointer(ip_dest), pointer(mask))

            route_entry_key = ifcs_ctypes.ifcs_route_entry_key_t()
            route_entry_key_list.insert(i, route_entry_key)
            ifcs_ctypes.ifcs_route_entry_key_t_init(pointer(route_entry_key_list[i]))
            ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_entry_key_list[i]),
                    ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
            ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_entry_key_list[i]),
                    route_entry_key.key.ip_dest_l3vni)
            ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_l3vni_set(pointer(route_entry_key_list[i].key.ip_dest_l3vni),
                    l3vni_hdls[drop_port])
            ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_entry_key_list[i].key.ip_dest_l3vni),
                    pointer(ip_dest))

            attr_list                              = (ifcs_ctypes.ifcs_attr_t * 10)()
            attr_count                             = 0

            fwd_policy = ifcs_ctypes.ifcs_fwd_policy_t()
            fwd_policy.fwd_action                  = ifcs_ctypes.IFCS_FWD_ACTION_DROP
            attr_list[attr_count].id               = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY
            attr_list[attr_count].value.fwd_policy = fwd_policy
            attr_count += 1

            rc = ifcs_ctypes.ifcs_route_entry_attr_set(self.cli.node_id,
                                           pointer(route_entry_key_list[i]),
                                           attr_count,
                                           attr_list)
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to set route entry attr to drop for port {0}, ret:{1}".format(drop_port, rc)

        time.sleep(5)
        for drop_port in drop_port_list:

            port_stats = []
            port_stats = devport_obj.stats_get(drop_port)
            pre_counts = compat_listrange(2)
            pre_counts[0] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            pre_counts[1] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]

            time.sleep(1)

            port_stats = []
            port_stats = devport_obj.stats_get(drop_port)
            post_counts = compat_listrange(2)
            post_counts[0] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            post_counts[1] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]

            if (((post_counts[1] - pre_counts[1]) > 0) or ((post_counts[0] - pre_counts[0]) > 0)):
                log("Traffic NOT stopped. Try again")
                return 'FAILED'

        log_dbg(1, "   Created drop route entries successfully")

        for i, route_entry_key in enumerate(route_entry_key_list):
            # Use previously created route_entry key, change fwd_policy attr action to forward
            attr_list                              =   (ifcs_ctypes.ifcs_attr_t * 10)()
            attr_count                             =   0

            fwd_policy.fwd_action                  =   ifcs_ctypes.IFCS_FWD_ACTION_FORWARD
            attr_list[attr_count].id               =   ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY
            attr_list[attr_count].value.fwd_policy =   fwd_policy
            attr_count += 1

            rc = ifcs_ctypes.ifcs_route_entry_attr_set(self.cli.node_id,
                                           pointer(route_entry_key),
                                           attr_count,
                                           attr_list)
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to set route entry attr to forward for port {0}, ret: {1}".format(drop_port_list[i], rc)

        devport_stats.state = SNAKE_STOPPED
        log("Stopped traffic on L3snake id {0}".format(devport_stats.id))
        return 'PASS'

    def config(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        choices_lb = ['NONE', 'PCS', 'PMA']

        parser = argparse.ArgumentParser(description='L3snake test config', prog='l3snake config', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-p', type=str, default="all", help='Port list')
        parser.add_argument('-lb', type=str, choices=choices_lb, default='NONE', help='Loopback type')
        parser.add_argument('-id', type=int, default=None, help='User defined snake id  [1-1023]')
        parser.add_argument('-v', help='Verbose', action="store_true")
        parser.add_argument('-b',  help='Bi-directional cross(2-3, 4-5,...,32-1)  traffic from first and last ports', action="store_true")
        parser.add_argument('-bs', help='Bi-directional straight(1-2, 3-4,...,31-32) traffic from first and last ports', action="store_true")
        try:
            res = parser.parse_args(self.arg_list)
        except:
            return 'FAILED'

        # user can't config bidirectional and loopback together
        if res.b or res.bs:
            if res.lb != 'NONE':
                log("loopback and bidirectional config can't co-exist")
                return 'FAILED'

        '''
        If -p arg not given, default port range is all ports.
        '''
        max_dev_port = self.get_max_devport()
        max_devport_range = "1-2"
        if max_dev_port:
            max_devport_range = "1-%d"%(max_dev_port)

        if res.p == 'all':
            # Port range not given, default to all ports
            devport_arg = max_devport_range
            devport_arg_list = max_devport_range.split(",")
        else:
            # Use given devport range
            try:
                devport_arg = res.p
                devport_arg_list = res.p.split(",")
            except:
                devport_arg = max_devport_range
                devport_arg_list = max_devport_range.split(",")

        # Allocate run's data object which saves config and stats
        devport_stats = DevportStats()

        find = False
        if res.id != None:
            for instance in L3snake.devport_stats_runs:
                if instance.id == res.id:
                    log('Snake id already in use!\n')
                    return 'FAILED'
            devport_stats.id = res.id
        else:
            for index in range(1, 1024):
                find = False
                for instance in L3snake.devport_stats_runs:
                    if instance.id == index:
                        find = True
                        break
                if find == False:
                    devport_stats.id = index
                    break
                if index == 1023:
                    log("Can not alloc snake id")
                    return 'FAILED'

        for i, dp in enumerate(devport_arg_list):
            if '-' in dp:
                dp_range = devport_arg.split(",")[i].split("-")
                for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                    devport_stats.devport_list.append(j)
            else:
                devport_stats.devport_list.append(int(dp))

        devport_list = devport_stats.devport_list

        # check if devport_list of new snake is overlapping with devport list of existing snake(s), if yes, return FAILED
        new_devport_set = set(devport_list)
        port_overlap = False
        for instance in L3snake.devport_stats_runs:
            if instance:
                existing_devport_set = set(instance.devport_list)
                if (existing_devport_set & new_devport_set):
                    port_overlap = True
                    break;
        if port_overlap:
            log("one or more ports in the devport list is already part of an existing snake. use ports that are not part of any existing snake(s)")
            return 'FAILED'

        lb_type = res.lb
        devport_stats.lb_type = lb_type

        verbose = res.v
        devport_stats.verbose = res.v

        if res.b:
            devport_stats.type = 'bidir_cross'
        elif res.bs:
            devport_stats.type = 'bidir_straight'
        else:
            devport_stats.type = 'unidir'

        # Total number of ports must be even for bidir
        if (devport_stats.type == 'bidir_cross' or devport_stats.type == 'bidir_straight'):
            if (len(devport_list) % 2 != 0):
                log("Number of ports cannot be odd for bidir")
                return 'FAILED'

        # locals
        devport_lb_config_failed = 0
        sysport_hdl_get_failed = 0

        # Configure
        ret = ifcs_ctypes.ifcs_status_t()
        attr = (ifcs_ctypes.ifcs_attr_t * 1)()

        attr[0].id = ifcs_ctypes.IFCS_LINKSCAN_ATTR_ENABLE
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE

        sysport_hdls = devport_stats.sysport_hdls
        sysport_hdls.clear()
        try:
            for port in devport_list:
                sysport_hdls[port] = self.configDevportGetSysportHandle(port)
        except:
            log("Sysport get FAILED")
            sysport_hdl_get_failed = 1
            pass

        # Disable all Devports
        err = self.configDevportsDisable(devport_stats)
        if err:
            log("L3snake test configuration failed")
            return 'FAILED'

        # Set Loopback mode
        if verbose:
            log("Setting devports loopback mode to {0}".format(devport_stats.lb_type))
        err = self.configDevportsLoopback(devport_stats, devport_stats.lb_type)
        if err:
            log("L3snake test configuration failed")
            return 'FAILED'

        # Configure Sysports as L3ONLY
        if verbose:
            log("Setting devports fwd mode to L3_ONLY")
        err = self.configSysportSetFwdMode(devport_stats, ifcs_ctypes.IFCS_SYSPORT_FWD_MODE_L3_ONLY)
        if err:
            log("L3snake test configuration failed")
            return 'FAILED'

        # Enable all Devports
        err = self.configDevportsEnable(devport_stats)
        if err:
            log("L3snake test configuration failed")
            return 'FAILED'

        # Create VRFs (L3VNI)
        if verbose:
            log("Creating L3 vnis")
        err = self.configL3vniCreate(devport_stats)
        if err:
            log("L3snake test configuration failed")
            return 'FAILED'

        # Create L3 Interfaces (One per Sysport)
        if verbose:
            log("Creating L3 intfs")
        err = self.configIntfCreate(devport_stats)
        if err:
            log("L3snake test configuration failed")
            return 'FAILED'

        # Create Nexthops (One per L3 interface)
        if verbose:
            log("Creating nexthops")
        err = self.configNexthopCreate(devport_stats)
        if err:
            log("L3snake test configuration failed")
            return 'FAILED'

        # Create Host Route entries (VRF, IP) -> NH (Intf, Dest Sysport)
        if verbose:
            log("Creating route entries")
        err = self.configRouteCreate(devport_stats)
        if err:
            log("L3snake test configuration failed")
            return 'FAILED'

        # Config success, save the config data useful for report generation
        self.insert_run_data(devport_stats)

        devport_stats.state = SNAKE_CONFIGD

        if (self.quiet == "false"):
            #display config
            devport_stats.display_config(devport_stats.id)

        # Wait for all ports to go link-up for 5 secs
        if verbose:
            log("Waiting for all ports to go link-up")

        if (lb_type != 'NONE'):
            timer_val = 5
        else:
            timer_val = 15
        wait_time = 0
        devport_attr_ct = 1
        devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
        devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_STATUS
        devport_attr[0].value.u32 = 0
        actual_count = c_uint32()
        link_status = True
        try:
            while wait_time < timer_val:
                link_status = True
                for devport in devport_list:
                    rc = ifcs_ctypes.ifcs_devport_attr_get (self.cli.node_id, devport, 1,
                                     compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t), pointer(actual_count))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "ERROR during devport attr get for port {0}: rc={1}({2})".format(
                        devport, rc,
                        compat_bytesToStr(
                            ifcs_ctypes.ifcs_status_to_string(rc)))

                    if (devport_attr[0].value.u32 != 1):
                        link_status=False
                if link_status:
                    break
                else:
                    wait_time+=0.1
                    time.sleep(0.1)

            assert link_status == True, "Not all devports are up"
        except:
            log("Error in config: all devports are not up")
            return 'FAILED'

        if verbose:
            log("Config done")
        return 'PASS'

    def config_show(self, args):
        table = PrintTable()
        header = []
        header.append("Devports")
        header.append("Loopback type")
        header.append("Snake id")
        header.append("Snake type")
        table.add_row(header)
        devport_stats_sorted = sorted(L3snake.devport_stats_runs, key=config_show_sort_key)
        for devport_stats in devport_stats_sorted:
            data = []
            data.append(str(devport_stats.devport_list)[1:-1])
            data.append(str(devport_stats.lb_type))
            data.append(str(devport_stats.id))
            data.append(str(devport_stats.type))
            table.add_row(data)

        table.print_table()
        table.reset_table()
        pass

    def gen_report(self, args, display = True, skipPop = False):
        if not skipPop:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test gen_report', prog='l3snake gen_report', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-t', type=int, default=10, help='Time in seconds to collect stats')
        parser.add_argument('-c', help='Clear the counter for this snake config', action="store_true")
        parser.add_argument('-id', type=int, default=None, help='Snake id. Needed if more than one snake configured')

        pre_timestamp = [0] * MAX_DEV_PORTS
        new_timestamp = [0] * MAX_DEV_PORTS

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return 'FAILED'

        if res.id:
            if 	res.id == -1:
                devport_stats = self.get_cur_run_data()
            else:
                find = False
                for instance in L3snake.devport_stats_runs:
                    if instance.id == res.id:
                        devport_stats = instance
                        find = True
                        break
                if find == False:
                    log("Snake with id ", res.id , " does not exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3snake.devport_stats_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to generate report for a specific snake")
                return 'FAILED'
            devport_stats = self.get_cur_run_data()

        devport_stats.time = res.t

        #Account for Inter-frame/packet-gap(12B) + preamble(8B)
        IPG_LEN = 12
        PREAMBLE_LEN = 8
        misc_delta_bytes = IPG_LEN + PREAMBLE_LEN

        devport_obj = Devport(self.cli)

        for p in devport_stats.devport_list:
            # Get current stats
            port_stats = devport_obj.stats_get(p)
            pre_timestamp[p] = round(time.time(),4)
            devport_stats.devport_rx_frames[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            devport_stats.devport_rx_bytes[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_OK]
            devport_stats.devport_tx_frames[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]
            devport_stats.devport_tx_bytes[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_OK]
            devport_stats.devport_rx_errors[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY]
            devport_stats.devport_tx_errors[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY]

        # Sleep for given time and get stats again to calculate rate
        rx_rate = [0] * MAX_DEV_PORTS
        tx_rate = [0] * MAX_DEV_PORTS

        if display:
            log("Devport stats rate calculation being done, please wait %d secs" %(devport_stats.time))

        #Sleeping
        time.sleep(devport_stats.time)

        for p in devport_stats.devport_list:
            port_stats = devport_obj.stats_get(p)
            new_timestamp[p] = round(time.time(),4)
            new_devport_rx_frames = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            new_devport_rx_bytes = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_OK]
            new_devport_tx_frames = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]
            new_devport_tx_bytes = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_OK]

            #Calculate Delta
            delta_rx_frames = new_devport_rx_frames - devport_stats.devport_rx_frames[p]
            delta_tx_frames = new_devport_tx_frames - devport_stats.devport_tx_frames[p]
            delta_rx_bytes = new_devport_rx_bytes - devport_stats.devport_rx_bytes[p]
            delta_tx_bytes = new_devport_tx_bytes - devport_stats.devport_tx_bytes[p]
            delta_timestamp = float(new_timestamp[p] - pre_timestamp[p])

            delta_tx_bytes += (delta_tx_frames * misc_delta_bytes)
            delta_rx_bytes += (delta_rx_frames * misc_delta_bytes)

            rx_rate[p] = float(float(delta_rx_bytes * 8)/float(1000*1000*1000*delta_timestamp))
            tx_rate[p] = float(float(delta_tx_bytes * 8)/float(1000*1000*1000*delta_timestamp))

            devport_stats.devport_rx_frames[p] = new_devport_rx_frames
            devport_stats.devport_rx_bytes[p] = new_devport_rx_bytes
            devport_stats.devport_tx_frames[p] = new_devport_tx_frames
            devport_stats.devport_tx_bytes[p] = new_devport_tx_bytes
            devport_stats.devport_rx_gbps[p] = rx_rate[p]
            devport_stats.devport_tx_gbps[p] = tx_rate[p]

        if display:
            devport_stats.display()

        # Clear stats if option to clear is set
        if res.c:
            for p in devport_stats.devport_list:
                devport_obj.stats_clear(p)
            if devport_stats.state == SNAKE_STOPPED:
                devport_stats.num_pkt.clear()

        pass

    def verify(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='L3snake test verify_traffic', prog='l3snake verify', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-rate', type=float, default=0, help='rx in gbps')
        parser.add_argument('-display', type=int, nargs='?', const=1, default=0, help='Log verbose')
        parser.add_argument('-ports', nargs='+', type=int, help=argparse.SUPPRESS)#'tx rx port pair to verify for rate'
        parser.add_argument('-id', type=int, default=None, help='Snake id. Needed if more than one snake configured')

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return 'FAILED'
        rate = res.rate

        if res.id:
            if 	res.id == -1:
                devport_stats = self.get_cur_run_data()
            else:
                find = False
                for index, instance in enumerate(L3snake.devport_stats_runs):
                    if instance.id == res.id:
                        devport_stats = instance
                        find = True
                        res.id = index
                        break
                if find == False:
                    log("Snake with id ", res.id, " does not exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3snake.devport_stats_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to verify for a specific snake")
                return 'FAILED'
            devport_stats = self.get_cur_run_data()
            res.id = -1

        # Calculate rate
        self.gen_report(args, display = res.display, skipPop = True)
        ret = 'PASS'

        num_ports = 0
        if res.ports is not None:
            num_ports = len(res.ports)

        # Verify the Tx and Rx rate for a given port pair
        if num_ports != 0:
            if num_ports != 2:
                log("Give exactly two ports in input")
                return 'FAILED'

            tx_port = res.ports[0]
            rx_port = res.ports[1]
            if (devport_stats.devport_tx_gbps[tx_port] == 0) or devport_stats.devport_rx_gbps[rx_port] == 0:
                ret = 'FAILED'
                log(ret)
                return ret

            if rate != 0:
                #if (devport_stats.devport_rx_gbps[p] < (rate - 1)) or (devport_stats.devport_rx_gbps[p] > (rate + 1)):
                #400G and 200G line rate traffic test failing with above validation. Modifying as below to be generic
                if (abs(devport_stats.devport_rx_gbps[rx_port]-rate)/rate > 0.01):
                    ret = 'FAILED'
                    log(ret)
                    return ret
        else:
            for p in devport_stats.devport_list:
                # If any of the configured ports rate is 0, snake test has problem
                if (devport_stats.devport_rx_gbps[p] == 0):
                    ret = 'FAILED'
                    break
                if rate != 0:
                   #if (devport_stats.devport_rx_gbps[p] < (rate - 1)) or (devport_stats.devport_rx_gbps[p] > (rate + 1)):
                   if (abs(devport_stats.devport_rx_gbps[p]-rate)/rate > 0.01):
                       ret = 'FAILED'
                       break
        log(ret)
        return ret

    def unconfig(self, args):
        parser = argparse.ArgumentParser(description='L3snake unconfig', prog='l3snake unconfig', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=None, help='Snake id. Needed if more than one snake configured')

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return 'FAILED'

        if res.id:
            if res.id == -1:
                devport_stats = self.get_cur_run_data()
            else:
                find = False
                for index, instance in enumerate(L3snake.devport_stats_runs):
                    if instance.id == res.id:
                        devport_stats = instance
                        find = True
                        res.id = index
                        break
                if find == False:
                    log("Snake with id ", res.id, " does not exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3snake.devport_stats_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to remove configuration for a specific snake")
                return 'FAILED'
            devport_stats = self.get_cur_run_data()
            res.id = -1

        verbose = devport_stats.verbose

        # Delete route entries
        if verbose:
            log("Deleting route entries")
        err = self.configRouteDelete(devport_stats)
        if err:
            log("L3snake test unconfig failed")
            return 'FAILED'

        # Delete nexthops
        if verbose:
            log("Deleting nexthops")
        err = self.configNexthopDelete(devport_stats)
        if err:
            log("L3snake test unconfig failed")
            return 'FAILED'

        # Delete interfaces
        if verbose:
            log("Deleting L3 intfs")
        err = self.configIntfDelete(devport_stats)
        if err:
            log("L3snake test unconfig failed")
            return 'FAILED'

        # Delete l3vnis
        if verbose:
            log("Deleting l3vnis")
        err = self.configL3vniDelete(devport_stats)
        if err:
            log("L3snake test unconfig failed")
            return 'FAILED'

        # Disable all devports
        err = self.configDevportsDisable(devport_stats)
        if err:
            log("L3snake test unconfig failed")
            return 'FAILED'

        # Set devports loopback to NONE
        if verbose:
            log("Setting devports loopback mode to NONE")
        err = self.configDevportsLoopback(devport_stats, 'NONE')
        if err:
            log("L3snake test unconfig failed")
            return 'FAILED'

        # Set devports Fwd mode to L2_L3
        if verbose:
            log("Setting devports fwd mode to L2_L3")
        err = self.configSysportSetFwdMode(devport_stats, ifcs_ctypes.IFCS_SYSPORT_FWD_MODE_L2_L3)
        if err:
            log("L3snake test unconfig failed")
            return 'FAILED'

        # Enable all devports
        err = self.configDevportsEnable(devport_stats)
        if err:
            log("L3snake test unconfig failed")
            return 'FAILED'

        devport_stats.state = SNAKE_UNCONFIG

        log("Unconfigured snake id {0}".format(devport_stats.id))

        if res.id != -1:
            del L3snake.devport_stats_runs[res.id]
        else:
            L3snake.devport_stats_runs.pop()

        L3snake.run -= 1

        if verbose:
            log("Unconfig done")

        return 'PASS'
