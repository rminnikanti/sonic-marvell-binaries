#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
# *-----------------------------------------------------------------------------

import shlex
import time
import random
import copy
import argparse

from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from ctypes import *
from testutil import pci
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']

class DupCopyDestPort(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'create'           : self.create,
                         'help'             : self.help,
                         '?'                : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []



    def _create_(
            self,
            nodeId,
            sysport=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        attrList = (ifcs_ctypes.ifcs_attr_t * 2)()
        for index in range(2):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_DUP_COPY_DEST_PORT_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if sysport is not None:
            attrList[index].id = ifcs_ctypes.IFCS_DUP_COPY_DEST_PORT_ATTR_SYSPORT
            attrList[index].value.handle = sysport
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_DUP_COPY_DEST_PORT_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_DUP_COPY_DEST_PORT_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_dup_copy_dest_port_create(
                    nodeId, pointer(handle), attrCount, attrList))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("DupCopyDestPort creation failed rc: {0}".format(rc))
            else:
                log("DupCopyDestPort handle= " + hex(handle.value))
            return rc

    def run_cmd(self, args):
        log_dbg(1, "in Dupcopydestport run")
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[2]](args)
        except (KeyError):
            log_dbg(1, "DupcopydestportKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "DupcopydestportValueError")
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None




    def create(self, args):
        log_dbg(1, "in dcdp create")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Dcdp create', prog='dcdp', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-dest_port_handle', action="store", help='Destination sysport handle', required=True)
        try:
            res = parser.parse_args(self.arg_list)
        except:
            log('Create parse_args failed')
            return 1

        # Get dest_port_handle
        dest_port_handle = int(res.dest_port_handle, 0)

        return self._create_(self.cli.node_id, sysport=dest_port_handle)



    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['create', 'Create Dcdp'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        dcdp_help_string = """
Usage::

    Type "config dup_copy_dest_port <command>" followed by -h to see command's sub-options.
"""
        log(dcdp_help_string)
