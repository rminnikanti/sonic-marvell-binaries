
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import random
import json
import math
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
from ifcs_ctypes import *
from ifcs_cmds.sysport import Sysport as sysport
from ifcs_cmds.devport import Devport as Devport
from ifcs_cmds.node import Node as node
from print_table import PrintTable

MAX_DEV_PORTS = 129
cpu_pkt_count = {}
cpu_queue_num = random.randint(0,47)
cpu_max_rate = random.choice([125,512,1000,3000,5000])

def cpu_rx_verify(node_id, user_data, packet):
    global cpu_pkt_count
    buf_len = packet.contents.pkt_buf_len
    buf = ctypes.c_char_p(packet.contents.pkt_buf)
    rx_queue = packet.contents.queue_num
    pass

def create_ctc_trap(node_id,cpu_queue_id):
    ctc_trap_handle = ifcs_handle_t()
    ctc_trap_handle.value = IFCS_NULL_HANDLE

    attr = (ifcs_attr_t * 1 )()

    attr[0].id = IFCS_HOSTIF_TRAP_ATTR_QUEUE_NUM
    attr[0].value.u32 = cpu_queue_id

    rc = ifcs_hostif_trap_create(node_id, pointer(ctc_trap_handle), 1, compat_pointer(attr, ifcs_attr_t))
    assert rc == IFCS_SUCCESS, "COPY to CPU trap creation FAILED"

    return ctc_trap_handle

def delete_ctc_trap(node_id, ctc_trap_handle):
    rc = ifcs_hostif_trap_delete(node_id, ctc_trap_handle);
    assert rc == IFCS_SUCCESS, "COPY to CPU trap deletion FAILED"
    return


def getSysportHandleFromDevPort(node_id, devPort):
    attr = ifcs_attr_t()
    actual_count = ctypes.c_uint32()

    attr.id = IFCS_DEVPORT_ATTR_SYSPORT
    ret = ifcs_devport_attr_get(node_id, devPort, 1, pointer(attr),
                            pointer(actual_count))
    assert ret == IFCS_SUCCESS, "port sysport handle get: ret = [" + str(ret) + "]"

    return attr.value.handle

# Object to store A "run" devport stats.
class DevportStats():
    def __init__(self):
        self.devport_rx_frames = [0] * MAX_DEV_PORTS
        self.devport_rx_bytes = [0] * MAX_DEV_PORTS
        self.devport_rx_gbps = [0] * MAX_DEV_PORTS
        self.devport_tx_frames = [0] * MAX_DEV_PORTS
        self.devport_tx_bytes = [0] * MAX_DEV_PORTS
        self.devport_tx_gbps = [0] * MAX_DEV_PORTS
        self.timestamp = [0] * MAX_DEV_PORTS
        self.devport_list = []
        self.lb_type = 0
        self.num_pkt = OrderedDict()
        self.node_id = 0
        self.verbose = 0
        self.time = 0

    def display(self):
        log("\nLoopback type    : %s" %(self.lb_type))
        log("Number of packets:")
        for size, num in compat_iteritems(self.num_pkt):
            log("    Size: %4s, Packets: %s" %(size, num))

        header = []
        header.append('Devport')
        header.append('RX(frames)')
        header.append('RX(bytes)')
        header.append('RX(Gbps)')
        header.append('TX(frames)')
        header.append('TX(bytes)')
        header.append('TX(Gbps)')
        table = PrintTable()
        table.add_row(header)
        for p in range(MAX_DEV_PORTS):
            if p != 0 and p not in self.devport_list:
                continue
            devport_row = []
            devport_row.append(str(p))
            devport_row.append(str(self.devport_rx_frames[p]))
            devport_row.append(str(self.devport_rx_bytes[p]))
            if p == 0:
                devport_row.append(str('%.2f m' %self.devport_rx_gbps[p]))
            else:
                devport_row.append(str('%.2f' %self.devport_rx_gbps[p]))
            devport_row.append(str(self.devport_tx_frames[p]))
            devport_row.append(str(self.devport_tx_bytes[p]))
            if p == 0:
                devport_row.append(str('%.2f m' %self.devport_tx_gbps[p]))
            else:
                devport_row.append(str('%.2f' %self.devport_tx_gbps[p]))
            table.add_row(devport_row)
        table.print_table()
        table.reset_table()

SNAKE_UNCONFIG = 0
SNAKE_CONFIGD = 1
SNAKE_RUNNING = 2
SNAKE_STOPPED = 3

#Snake: This test injects a packet on a port and the forwarding
#       rules are configured in such a way that the packet loops
#       through all the ports and then back to CPU.
#       This is a work in progress, so we pass it for now
#
class Snake(Command):
    state = SNAKE_UNCONFIG
    #Global across all Snake objects.

    #All run's devport stats are saved in below list
    devport_stats_runs = []

    #Class variables
    dmac_l2_entry_array = []
    smac_l2_entry_array = []
    port_sp_hdl         = OrderedDict()
    cpu_sp_hdl          = ifcs_handle_t()
    stp_hdl             = ifcs_handle_t()


    #Incremented for each run config (diagtest snake config)
    run = -1

    def __init__(self, cli):
        self.sub_cmds = {
                         'config'       : self.config,
                         'config_show'  : self.config_show,
                         'start_traffic': self.start_traffic,
                         'stop_traffic' : self.stop_traffic,
                         'gen_report'   : self.gen_report,
                         'verify'       : self.verify,
                         'verify_cpu'   : self.verify_cpu,
                         #'dump_report'  : self.dump_report,
                         'unconfig'     : self.unconfig,
                         'help'         : self.help,
                         '?'            : self.help
                        }
        self.cli = cli
        self.arg_list = []
        super(Snake, self).__init__()

    def __del__(self):
        return

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[2]](args)
            return rc
        except (KeyError):
            log_dbg(1, "Invalid cmd")
            self.help(args)
            return IFCS_PARAM
        except Exception as ex:
            self.cli.error()
            self.help(args)

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['config', 'Configure snake test'])
        table.add_row(['config_show', 'Show snake test configuration'])
        table.add_row(['start_traffic', 'Start snake test traffic'])
        table.add_row(['stop_traffic', 'Stop snake test traffic'])
        table.add_row(['gen_report', 'Generate snake test report for given sampling time'])
        table.add_row(['verify', 'Verify if traffic is running on all configured ports'])
        table.add_row(['verify_cpu', 'Verify traffic to cpu'])
        #table.add_row(['dump_report', 'Dump snake tests report to file'])
        table.add_row(['unconfig', 'Unconfigure snake test'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        snake_help_string = """
Usage::

    Type "diagtest snake <command>" followed by -h to see command's sub-options.
"""
        log(snake_help_string)

    def insert_run_data(self, run_data):
        # Increment run and insert run data
        Snake.run += 1
        Snake.devport_stats_runs.append(run_data)

    def get_run_data(self, run):
        return Snake.devport_stats_runs[run]

    def get_cur_run_data(self):
        run = Snake.run
        return Snake.devport_stats_runs[run]

    def config(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        global cpu_queue_num
        parser = argparse.ArgumentParser(description='Snake test config', prog='snake', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-p', type=str, default="1-2", help='Port list')
        parser.add_argument('-lb', type=str, choices=['NONE', 'PCS', 'PMA'], default='NONE', help='Loopback type')
        parser.add_argument('-shp', type=str, choices=['NONE', 'CPU_SHP', 'P_SHP', 'Q_SHP', 'CPU_M', 'ALL'], default='NONE', help='Shaping type')
        parser.add_argument('-cq', type=str, default=cpu_queue_num, help='ctc trap queue number')
        parser.add_argument('-v', help='Verbose', action="store_true")
        try:
            res = parser.parse_args(self.arg_list)
        except:
            return

        try:
            devport_arg_list = res.p.split(",")
        except:
            devport_arg_list = "1-2"

        cpu_queue_num = int(res.cq)

        # Allocate run's data object which saves config and stats
        devport_stats = DevportStats()
        devport_list = devport_stats.devport_list

        for i, dp in enumerate(devport_arg_list):
            if '-' in dp:
                dp_range = res.p.split(",")[i].split("-")
                for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                    devport_stats.devport_list.append(j)
            else:
                devport_stats.devport_list.append(int(dp))

        allowed_lb_types = ['none', 'pcs', 'pma']
        if (res.lb.upper() not in map(str.upper, allowed_lb_types)):
            log("Invalid Loopback type specified: ", lb_type)
            return 'FAILED'
        lb_type = res.lb
        devport_stats.lb_type = res.lb
        shp_type = res.shp

        verbose = res.v
        devport_stats.verbose = res.v

        # locals
        sysport_hdl_get_failed = 0
        stp_create_failed = 0
        stp_port_set_failed = 0
        l2vni_create_failed = 0
        l2vni_stp_config_failed = 0
        l2vni_member_config_failed = 0
        src_l2entry_create_failed = 0
        dst_l2entry_create_failed = 0
        sysport_attr_set_failed = 0
        devport_lb_config_failed = 0
        devport_shp_config_failed = 0
        queue_shp_config_failed = 0

        # Configure
        dport = devport_stats.devport_list[0]
        ret = ifcs_status_t()
        vni_hdl = ifcs_handle_t()
        attr = ifcs_attr_t()
        vni_attr = (ifcs_attr_t * 2)()
        mac_addr_t = c_uint8 * 6
        dsp_fldlst = []

        attr.id = IFCS_LINKSCAN_ATTR_ENABLE
        attr.value.u32 = IFCS_BOOL_FALSE

        '''
        rc = ifcs_linkscan_attr_set(0, 1, pointer(attr))
        assert rc == IFCS_SUCCESS, "Linkscan disable FAILED!!. RC " + str(rc)
        if (verbose == 1):
            log("Linkscan disabled")
        '''

        maxPorts = MAX_DEV_PORTS
        cpu_port = 0
        port_sp_hdl = Snake.port_sp_hdl

        dmac_l2_entry_array = Snake.dmac_l2_entry_array
        smac_l2_entry_array = Snake.smac_l2_entry_array
        cpu_sp_hdl = Snake.cpu_sp_hdl
        stp_hdl = Snake.stp_hdl

        try:
            for port in devport_stats.devport_list:
                port_sp_hdl[port] = getSysportHandleFromDevPort(devport_stats.node_id, port)
            cpu_sp_hdl.value = getSysportHandleFromDevPort(devport_stats.node_id, cpu_port)
        except:
            log("Sysport get FAILED!!")
            sysport_hdl_get_failed = 1
            pass

        ####### STEP0 #######
        ###### STP CONFIG #######
        try:
            stp_hdl.value = IFCS_NULL_HANDLE
            ret = ifcs_stp_create(0, pointer(stp_hdl), 0, pointer(attr))
            assert ret == IFCS_SUCCESS, "STP instance creation FAILED!!"
        except:
            log("STP create FAILED!!")
            stp_create_failed = 1
            pass

        try:
            #mbrs=OrderedDict()
            #for mbr in port_sp_hdl:
            #    mbrVal = IFCS_HANDLE_VALUE(mbr)
            #    mbrs[mbr] = IFCS_HANDLE_SYSPORT(mbrVal)

            mbrs = port_sp_hdl
            member_count = len(mbrs)
            member_list = (ifcs_handle_t * member_count)()
            member_attr_count = 0
            member_attr_list = (ifcs_attr_t * member_attr_count)()
            count=0
            for mbr in mbrs:
                member_list[count] = mbrs[mbr]
                count += 1

            stp_attr_count = 1
            stp_attr = ifcs_attr_t()
            stp_attr.id        = IFCS_STP_PORT_ATTR_STP_STATE;
            stp_attr.value.u32 = IFCS_STP_PORT_STATE_FORWARDING;

            ret = ifcs_stp_port_add(0, stp_hdl, count, compat_pointer(member_list, ifcs_handle_t), stp_attr_count, pointer(stp_attr))
            assert ret == IFCS_SUCCESS,\
                   "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                    str(l2vni)
            #for mbr in mbrs:
            #    if mbr == 0:
            #        continue
            #    ret = ifcs_stp_port_attr_set(0, stp_hdl, mbrs[mbr], stp_attr_count, pointer(stp_attr))
            #    assert ret == IFCS_SUCCESS,\
            #           "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
            #            str(l2vni)
        except:
            stp_port_set_failed = 1
            log("STP port set FAILED!!")
            pass

        ###### VNI CONFIG ######
        # Create VNI and add members
        try:
            ###### VNI CONFIG ######
            # Create VNI and add members
            l2vni_hdl = ifcs_handle_t()
            for i in devport_stats.devport_list:
                l2vni_hdl.value = IFCS_HANDLE_L2VNI(i)
                if (i == 0):
                    continue
                ret = ifcs_l2vni_create(0, pointer(l2vni_hdl), 0, pointer(attr))
                assert ret == IFCS_SUCCESS,\
                       "ERR during L2VNI creation " + str(i)
        except:
            log("Hit except L2VNI create config")
            l2vni_create_failed = 1
            pass

        try:
            # Set STP instance for created VNI
            vni_attr[0].id = IFCS_L2VNI_ATTR_STP_INSTANCE
            vni_attr[0].value.handle = stp_hdl
            ret = ifcs_l2vni_attr_set(0, l2vni_hdl, 1, compat_pointer(vni_attr, ifcs_attr_t))
            assert ret == IFCS_SUCCESS, "STP instance vni attr set FAILED!!"
        except:
            l2vni_stp_config_failed = 1
            log("Hit except L2VNI stp config")
            pass

        try:
            for i in devport_stats.devport_list:
                l2vni_hdl.value = IFCS_HANDLE_L2VNI(i)
                if (i == 0):
                    continue
                ret = ifcs_l2vni_member_add(0, l2vni_hdl,
                                             member_count, compat_pointer(member_list, ifcs_handle_t),
                                             member_attr_count, compat_pointer(member_attr_list, ifcs_attr_t))
                assert ret == IFCS_SUCCESS,\
                       "ERR during L2VNI mbr add " + str(l2vni)

                #Add CPU port to VNI membership
                ret = ifcs_l2vni_member_add(0, l2vni_hdl,
                                             1, pointer(cpu_sp_hdl),
                                             member_attr_count, compat_pointer(member_attr_list, ifcs_attr_t))
                assert ret == IFCS_SUCCESS,\
                       "ERR during L2VNI mbr add for CPU port" + str(l2vni)
        except:
            log("Hit except L2VNI member config")
            l2vni_member_config_failed = 1
            pass

        try:
            attr_count = 2
            attr = (ifcs_attr_t * attr_count)()

            # Skip list of devports for pic ports which are not working
            # SRC MAC
            for i, port in enumerate(devport_stats.devport_list):
                count = port
                port_hdl = ifcs_handle_t()
                port_sp = IFCS_HANDLE_VALUE(port_sp_hdl[port])
                mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xBB)
                port_hdl.value = IFCS_HANDLE_SYSPORT(port_sp)
                l2_entry = ifcs_l2_entry_key_t()
                ifcs_l2_entry_key_t_init(pointer(l2_entry))
                l2_entry.key_type = IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI
                l2_entry.key.mac_l2vni.mac_addr = mac_addr
                if port == devport_list[-1]:
                    l2vni_hdl.value = IFCS_HANDLE_L2VNI(devport_list[0])
                else:
                    l2vni_hdl.value = IFCS_HANDLE_L2VNI(devport_list[i + 1])

                l2_entry.key.mac_l2vni.l2vni = l2vni_hdl
                attr[0].id = IFCS_L2_ENTRY_ATTR_ENTRY_DEST
                attr[0].value.handle = port_hdl
                attr[1].id = IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
                attr[1].value.u32 = IFCS_L2_ENTRY_TYPE_STATIC
                rc = ifcs_l2_entry_create(0, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_attr_t))
                assert rc == IFCS_SUCCESS, "Create SMAC entry FAILED!!: rc = [" + str(rc) + "]"
                smac_l2_entry_array.append(l2_entry)
        except:
            src_l2entry_create_failed = 1
            log("Hit except (SMAC) config")
            pass

        try:
            # Dest MAC of packet
            for i, port in enumerate(devport_stats.devport_list):
                count = port
                port_hdl = ifcs_handle_t()
                mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
                port_hdl.value = IFCS_HANDLE_SYSPORT(devport_list[i])
                l2_entry = ifcs_l2_entry_key_t()
                ifcs_l2_entry_key_t_init(pointer(l2_entry))
                l2_entry.key_type = IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI
                l2_entry.key.mac_l2vni.mac_addr = mac_addr
                l2vni_hdl.value = IFCS_HANDLE_L2VNI(port)
                l2_entry.key.mac_l2vni.l2vni = l2vni_hdl
                attr[0].id = IFCS_L2_ENTRY_ATTR_ENTRY_DEST
                attr[0].value.handle = port_hdl
                attr[1].id = IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
                attr[1].value.u32 = IFCS_L2_ENTRY_TYPE_STATIC
                rc = ifcs_l2_entry_create(0, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_attr_t))
                assert rc == IFCS_SUCCESS, "Create DMAC entry FAILED!!: rc = [" + str(rc) + "]"
                dmac_l2_entry_array.append(l2_entry)
        except:
            log("Hit except (DMAC) config")
            dst_l2entry_create_failed = 1
            pass

        if shp_type.upper() == 'CPU_SHP' or 'CPU_M':
            try:
                # Set up the listener
                #cbfn = ifcs_hostif_packet_notify_t(cpu_rx_verify)
                #ifcs_hostif_register_rx_packet_notify(0, None, cbfn)

                #Create ctc trap
                cpu_queue_id = cpu_queue_num
                ctc_trap_handle = create_ctc_trap(0,cpu_queue_id)
                attr_count = 2
                attr = (ifcs_attr_t * attr_count)()

                for l2_entry in dmac_l2_entry_array:
                    attr[0].id = IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY
                    attr[0].value.fwd_policy.fwd_action = IFCS_FWD_ACTION_FORWARD
                    attr[1].id = IFCS_L2_ENTRY_ATTR_ENTRY_CTC_POLICY
                    attr[1].value.ctc_policy.ctc_action = IFCS_COPY_TO_CPU_ENABLE
                    attr[1].value.ctc_policy.trap_handle = ctc_trap_handle
                    rc = ifcs_l2_entry_attr_set(0, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_attr_t))
                    assert rc == IFCS_SUCCESS, "Set CTC POLICY for l2_entry FAILED!!: rc = [" + str(rc) + "]"

            except:
                log("Hit except (CTC TRAP) config")
                dst_l2entry_create_failed = 1
                pass

        if shp_type.upper() == 'CPU_SHP':
            try:
                attr = (ifcs_attr_t * IFCS_CPU_QUEUE_ATTR_MAX_COUNT)()
                for i in range(0,48):
                    cpu_queue_id = i
                    if cpu_queue_id == cpu_queue_num:
                        ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_attr_t, 0))
                        ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_attr_t, 1))
                        ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_attr_t, 2))
                        ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_attr_t, 0), IFCS_CPU_QUEUE_ATTR_MAX_RATE_ENABLE)
                        ifcs_attr_t_value_data_set(compat_pointerAtIndex(attr, ifcs_attr_t, 0), IFCS_BOOL_TRUE)
                        ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_attr_t, 1), IFCS_CPU_QUEUE_ATTR_MAX_RATE)
                        ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_attr_t, 1), cpu_max_rate)
                        ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_attr_t, 2), IFCS_CPU_QUEUE_ATTR_MAX_RATE_BURST_SIZE)
                        ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_attr_t, 2), cpu_max_rate*2)
                        rc = ifcs_cpu_queue_attr_set(0, cpu_queue_id, 3, compat_pointerAtIndex(attr, ifcs_attr_t, 0))
                        assert IFCS_STATUS_REASON(rc) == IFCS_SUCCESS

            except:
                log("Hit except (CPU SHAPING) config")
                dst_l2entry_create_failed = 1
                pass

        if shp_type.upper() == 'CPU_M':
            try:
                attr = (ifcs_attr_t * IFCS_CPU_QUEUE_ATTR_MAX_COUNT)()
                for i in range(0,48):
                    cpu_queue_id = i
                    if cpu_queue_id == cpu_queue_num:
                        ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_attr_t, 0))
                        ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_attr_t, 1))
                        ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_attr_t, 2))
                        ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_attr_t, 0), IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE_ENABLE)
                        ifcs_attr_t_value_data_set(compat_pointerAtIndex(attr, ifcs_attr_t, 0), IFCS_BOOL_TRUE)
                        ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_attr_t, 1), IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE)
                        ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_attr_t, 1), cpu_max_rate)
                        ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_attr_t, 2), IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_BURST_SIZE)
                        ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_attr_t, 2), cpu_max_rate*2)
                        rc = ifcs_cpu_queue_attr_set(0, cpu_queue_id, 3, compat_pointerAtIndex(attr, ifcs_attr_t, 0))
                        assert IFCS_STATUS_REASON(rc) == IFCS_SUCCESS

            except:
                log("Hit except (CPU METERING) config")
                dst_l2entry_create_failed = 1
                pass

        try:
            # SYSPORT attr set
            #Build Sysport attr for Default VID config
            sp_attr_ct = 3
            sp_attr = (ifcs_attr_t * sp_attr_ct)()

            for i, port in enumerate(devport_stats.devport_list):
                if (port == 0):
                    continue
                sp_attr[0].id = IFCS_SYSPORT_ATTR_DEFAULT_CVID
                if port == devport_stats.devport_list[-1]:
                    sp_attr[0].value.u16 = devport_stats.devport_list[0]
                else:
                    sp_attr[0].value.u16 = devport_stats.devport_list[i + 1]
                sp_attr[1].id = IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID
                sp_attr[1].value.u16 = port
                sp_attr[2].id = IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID_ENABLE
                sp_attr[2].value.data = IFCS_BOOL_TRUE

                rc = ifcs_sysport_attr_set(0, port_sp_hdl[port], 3, compat_pointer(sp_attr, ifcs_attr_t))
                assert rc == IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"
        except:
            log("Hit except (Sysport) config")
            sysport_attr_set_failed = 1
            pass

        if (lb_type.upper() != 'NONE'):
            try:
                # Disable all the ports
                devport_attr_ct = 1
                devport_attr = (ifcs_attr_t * devport_attr_ct)()
                devport_attr[0].id = IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = IFCS_BOOL_FALSE;

                for port in devport_stats.devport_list:
                    if (port == 0):
                        continue
                    rc = ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_attr_t))
                    assert rc == IFCS_SUCCESS,\
                        "ERR during port admin disable:" + str(port)

                devport_attr_ct = 1
                devport_attr = (ifcs_attr_t * devport_attr_ct)()
                for port in devport_stats.devport_list:
                    if (port == 0):
                        continue
                    if (lb_type.upper() == 'PCS'):
                        lb = IFCS_DEVPORT_LOOPBACK_PCS
                    elif (lb_type.upper() == 'PMA'):
                        lb = IFCS_DEVPORT_LOOPBACK_PMA
                    else:
                        lb = IFCS_DEVPORT_LOOPBACK_NONE
                    devport_attr[0].id = IFCS_DEVPORT_ATTR_LOOPBACK
                    devport_attr[0].value.u32 = lb
                    rc = ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_attr_t))
                    assert rc == IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"

                # Enable all the ports
                devport_attr_ct = 1
                devport_attr = (ifcs_attr_t * devport_attr_ct)()
                devport_attr[0].id = IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = IFCS_BOOL_TRUE;

                for port in devport_stats.devport_list:
                    rc = ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_attr_t))
                    assert rc == IFCS_SUCCESS,\
                        "ERR during port admin disable:" + str(port)
            except:
                log("Hit except (Devport loopback) config")
                devport_lb_config_failed = 1

        if shp_type.upper() == 'P_SHP' or shp_type.upper() == 'ALL':
            try:
                for devport in devport_stats.devport_list:
                    attrCount = 3
                    attrList = (ifcs_attr_t * attrCount)()
                    #Set the max_rate shaper to 1Gbps
                    attrList[0].id = IFCS_DEVPORT_ATTR_MAX_RATE_ENABLE
                    attrList[0].value.data = 1
                    attrList[1].id = IFCS_DEVPORT_ATTR_MAX_RATE
                    attrList[1].value.u64 = 10 * 1000 * 1000 #max_rate config is in th Kbps units
                    attrList[2].id = IFCS_DEVPORT_ATTR_MAX_BURST_SIZE
                    attrList[2].value.u32 = 160000
                    ret = ifcs_devport_attr_set(0, devport, attrCount, compat_pointer(attrList, ifcs_attr_t))
                    assert ret == IFCS_SUCCESS

            except:
                log("Devport Shaper config FAILED!!")
                devport_shp_config_failed = 1
                pass

        if shp_type.upper() == 'Q_SHP' or shp_type.upper() == 'ALL':
            try:
                attr = (ifcs_attr_t * IFCS_QUEUE_ATTR_MAX_COUNT)()
                queue = ifcs_queue_t()
                attr_val = ifcs_uint32_t()
                ifcs_queue_t_init(pointer(queue))
                for devport in devport_stats.devport_list:
                    for i in range(0,8):
                        ifcs_queue_t_devport_set(pointer(queue), devport)
                        ifcs_queue_t_queue_id_set(pointer(queue), i)
                        ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_attr_t, 0))
                        ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_attr_t, 1))
                        ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_attr_t, 2))
                        ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_attr_t, 0), IFCS_QUEUE_ATTR_MAX_RATE_ENABLE)
                        ifcs_attr_t_value_data_set(compat_pointerAtIndex(attr, ifcs_attr_t, 0), IFCS_BOOL_TRUE)
                        ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_attr_t, 1), IFCS_QUEUE_ATTR_MAX_RATE)
                        ifcs_attr_t_value_u64_set(compat_pointerAtIndex(attr, ifcs_attr_t, 1), 20000000000)
                        ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_attr_t, 2), IFCS_QUEUE_ATTR_MAX_RATE_BURST_SIZE)
                        ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_attr_t, 2), 480000)
                        rc = ifcs_queue_attr_set(0, pointer(queue), 3, compat_pointerAtIndex(attr, ifcs_attr_t, 0))
                        assert IFCS_STATUS_REASON(rc) == IFCS_SUCCESS

            except:
                log("Queue Shaper config FAILED!!")
                queue_shp_config_failed = 1
                pass

        if sysport_hdl_get_failed or stp_create_failed or stp_port_set_failed or \
           l2vni_create_failed or l2vni_stp_config_failed or l2vni_member_config_failed or \
           src_l2entry_create_failed or dst_l2entry_create_failed or sysport_attr_set_failed or \
           devport_lb_config_failed or devport_shp_config_failed or queue_shp_config_failed:
            log("Snake test configuration failed")
        else:
            # Config success, save the config data useful for report generation
            self.insert_run_data(devport_stats)

        Snake.state = SNAKE_CONFIGD

        #show config
        self.config_show(args)

        return

    def config_show(self, args):
        devport_stats = self.get_cur_run_data()
        table = PrintTable()
        header = []
        header.append("Devports")
        header.append("Loopback type")
        table.add_row(header)

        data = []
        data.append(str(devport_stats.devport_list)[1:-1])
        data.append(str(devport_stats.lb_type))
        table.add_row(data)
        table.print_table()
        table.reset_table()
        pass

    def start_traffic(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test start_traffic', prog='snake', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-n', type=int, default=100, help='Number of packets')
        parser.add_argument('-s', type=int, default=1500, help='Packet size')
        parser.add_argument('-pri', type=int, default=100, help='Packet priority')
        try:
            res = parser.parse_args(self.arg_list)
        except:
            return "FAILED"

        devport_stats = self.get_cur_run_data()
        length = res.s
        num_pkt = res.n
        pkt_tos = res.pri

        # Tos array
        tos = {}
        tos[0] = chr(0x00)
        tos[1] = chr(0x20)
        tos[2] = chr(0x40)
        tos[3] = chr(0x60)
        tos[4] = chr(0x80)
        tos[5] = chr(0xa0)
        tos[6] = chr(0xc0)
        tos[7] = chr(0xe0)

        try:
            devport_stats.num_pkt[length] += num_pkt
        except (KeyError):
            devport_stats.num_pkt[length] = num_pkt

        if (length < 64):
            length = 128

        # Start traffic
        data = (c_byte * length)()
        curByte = random.randint(0, 255)
        curByte = 65
        smac_dmac_sz = 12 # 12 bytes
        if (pkt_tos != 100):
            smac_dmac_sz = 18 # dot1q header
        for j in range(smac_dmac_sz):
            if (j == 0):
                bytes = chr(0)
            elif (j == 5):
                bytes += chr(0xaa)
            elif (j == 11):
                bytes += chr(0xbb)
            elif (j == 12) and (pkt_tos != 100):
                bytes += chr(0x81)
            elif (j == 13) and (pkt_tos != 100):
                bytes += chr(0x00)
            elif (j == 14) and (pkt_tos != 100):
                bytes += tos[pkt_tos]
            elif (j == 15) and (pkt_tos != 100):
                bytes += chr(0x00)
            elif (j == 16) and (pkt_tos != 100):
                bytes += chr(0x00)
            elif (j == 17) and (pkt_tos != 100):
                bytes += chr(0x00)
            else:
                bytes += chr(0)
        for j in range(length - smac_dmac_sz):
           bytes += chr(curByte)
           curByte = (curByte + 1) & 0xff

        data = bytes
        pdata = cast(compat_strToBytes(data), c_void_p)
        try:
            packet = ifcs_hostif_packet_info_t()
            ifcs_hostif_packet_info_t_init(byref(packet))
            packet.tx_type = IFCS_HOSTIF_TX_TYPE_PIPELINE_BYPASS
            dport = devport_stats.devport_list[0]
            packet.dsp = getSysportHandleFromDevPort(devport_stats.node_id, dport)
            packet.pkt_buf = pdata
            packet.pkt_buf_len = length
        except Exception as e:
            log("exc", e)
        for loop in range(0, num_pkt):
                rc = ifcs_hostif_send_packet(devport_stats.node_id, pointer(packet))
                if (rc != IFCS_SUCCESS):
                   log_err('Packet send to pcie failed')
                   return

        Snake.state = SNAKE_RUNNING
        return 'PASSED'

    def stop_traffic(self, args):
        dmac_l2_entry_array = Snake.dmac_l2_entry_array
        smac_l2_entry_array = Snake.smac_l2_entry_array
        port_sp_hdl = Snake.port_sp_hdl
        cpu_sp_hdl = Snake.cpu_sp_hdl
        stp_hdl = Snake.stp_hdl
        mac_addr_t = c_uint8 * 6
        devport_obj = Devport(self.cli)

        devport_stats = self.get_cur_run_data()
        verbose = devport_stats.verbose
        devport_list = devport_stats.devport_list

        port = devport_list[0]
        port_hdl = ifcs_handle_t()
        l2vni_hdl = ifcs_handle_t()
        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
        port_hdl.value = IFCS_HANDLE_SYSPORT(port)
        l2_entry = ifcs_l2_entry_key_t()
        ifcs_l2_entry_key_t_init(pointer(l2_entry))
        l2_entry.key_type = IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI
        l2_entry.key.mac_l2vni.mac_addr = mac_addr
        l2vni_hdl.value = IFCS_HANDLE_L2VNI(port)
        l2_entry.key.mac_l2vni.l2vni = l2vni_hdl

        attr_count = 0
        attr = (ifcs_attr_t * 2)()
        fwd_policy = ifcs_fwd_policy_t()
        ifcs_fwd_policy_t_init(pointer(fwd_policy))
        fwd_policy.fwd_action = IFCS_FWD_ACTION_DROP
        ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_attr_t, attr_count), IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY)
        ifcs_attr_t_value_fwd_policy_set(compat_pointerAtIndex(attr, ifcs_attr_t, attr_count), pointer(fwd_policy))
        attr_count += 1

        rc = ifcs_l2_entry_attr_set(0, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_attr_t))
        assert rc == IFCS_SUCCESS, "Attr set to Drop FDB entry FAILED!!: rc = [" + str(rc) + "]"

        time.sleep(2)

        port_stats = []
        port_stats = devport_obj.stats_get(port)
        pre_counts = compat_listrange(2)
        pre_counts[0] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK']]
        pre_counts[1] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK']]

        time.sleep(1)

        port_stats = []
        port_stats = devport_obj.stats_get(port)
        post_counts = compat_listrange(2)
        post_counts[0] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK']]
        post_counts[1] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK']]

        if (((post_counts[1] - pre_counts[1]) > 0) or ((post_counts[0] - pre_counts[0]) > 0)):
            log("Traffic NOT stopped. Try again")
            return 'FAILED'

        attr_count = 0
        fwd_policy = ifcs_fwd_policy_t()
        ifcs_fwd_policy_t_init(pointer(fwd_policy))
        fwd_policy.fwd_action = IFCS_FWD_ACTION_FORWARD
        ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_attr_t, attr_count), IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY)
        ifcs_attr_t_value_fwd_policy_set(compat_pointerAtIndex(attr, ifcs_attr_t, attr_count), pointer(fwd_policy))
        attr_count += 1

        rc = ifcs_l2_entry_attr_set(0, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_attr_t))
        assert rc == IFCS_SUCCESS, "Attr set back to Fwd FDB entry FAILED!!: rc = [" + str(rc) + "]"

        Snake.state = SNAKE_STOPPED
        return 'PASSED'


    def gen_report(self, args, display = True, skipPop = False):
        if not skipPop:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test gen_report', prog='snake', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-t', type=int, default=1, help='Time in seconds to collect stats')
        parser.add_argument('-v', type=int, default=0, help='Verbose [0-Off, 1-On')
        pre_timestamp = [0] * MAX_DEV_PORTS
        new_timestamp = [0] * MAX_DEV_PORTS

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return "FAILED"

        devport_stats = self.get_cur_run_data()
        devport_stats.time = res.t
        verbose = res.v

        #Account for Inter-frame/packet-gap(12B) + preamble(8B)
        IPG_LEN = 12
        PREAMBLE_LEN = 8
        misc_delta_bytes = IPG_LEN + PREAMBLE_LEN

        devport_obj = Devport(self.cli)

        for p in range(MAX_DEV_PORTS):
            # Get current stats
            if p !=0 and p not in devport_stats.devport_list:
                continue

            port_stats = devport_obj.stats_get(p)
            pre_timestamp[p] = round(time.time(),4)
            devport_stats.devport_rx_frames[p] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK']]
            devport_stats.devport_rx_bytes[p] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_BYTES_OK']]
            devport_stats.devport_tx_frames[p] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK']]
            devport_stats.devport_tx_bytes[p] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_BYTES_OK']]

        # Sleep for given time and get stats again to calculate rate
        rx_rate = [0] * MAX_DEV_PORTS
        tx_rate = [0] * MAX_DEV_PORTS

        if display:
            log("Devport stats rate calculation being done, please wait %d secs" %(devport_stats.time))

        if (verbose):
            devport_stats.display()

        #Sleeping
        time.sleep(devport_stats.time)

        for p in range(MAX_DEV_PORTS):
            if p !=0 and p not in devport_stats.devport_list:
                continue
            port_stats = devport_obj.stats_get(p)
            new_timestamp[p] = round(time.time(),4)
            new_devport_rx_frames = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK']]
            new_devport_rx_bytes = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_BYTES_OK']]
            new_devport_tx_frames = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK']]
            new_devport_tx_bytes = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_BYTES_OK']]

            #Calculate Delta
            if p == 0:
                delta_rx_frames = new_devport_rx_frames
                delta_tx_frames = new_devport_tx_frames
                delta_rx_bytes = new_devport_rx_bytes
                delta_tx_bytes = new_devport_tx_bytes
            else:
                delta_rx_frames = new_devport_rx_frames - devport_stats.devport_rx_frames[p]
                delta_tx_frames = new_devport_tx_frames - devport_stats.devport_tx_frames[p]
                delta_rx_bytes = new_devport_rx_bytes - devport_stats.devport_rx_bytes[p]
                delta_tx_bytes = new_devport_tx_bytes - devport_stats.devport_tx_bytes[p]
            delta_timestamp = float(new_timestamp[p] - pre_timestamp[p])

            delta_tx_bytes += (delta_tx_frames * misc_delta_bytes)
            delta_rx_bytes += (delta_rx_frames * misc_delta_bytes)

            if p == 0:
                rx_rate[p] = float(float(delta_rx_bytes * 8)/float(1000*1000*delta_timestamp))
                tx_rate[p] = float(float(delta_tx_bytes * 8)/float(1000*1000*delta_timestamp))
            else:
                rx_rate[p] = float(float(delta_rx_bytes * 8)/float(1000*1000*1000*delta_timestamp))
                tx_rate[p] = float(float(delta_tx_bytes * 8)/float(1000*1000*1000*delta_timestamp))

            devport_stats.devport_rx_frames[p] = new_devport_rx_frames
            devport_stats.devport_rx_bytes[p] = new_devport_rx_bytes
            devport_stats.devport_tx_frames[p] = new_devport_tx_frames
            devport_stats.devport_tx_bytes[p] = new_devport_tx_bytes
            devport_stats.devport_rx_gbps[p] = rx_rate[p]
            devport_stats.devport_tx_gbps[p] = tx_rate[p]

        if display:
            devport_stats.display()


        '''
        for i in range(len(Snake.devport_stats_runs)):
            log("Run %d config and stats:" %(i+1))
            log("-----------------------")
            Snake.devport_stats_runs[i].display()
        '''
        pass

    def verify_cpu(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test verify_traffic', prog='snake', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-rate', type=int, default=cpu_max_rate, help='rx in gbps')
        parser.add_argument('-display', type=int, default=False, help='Log verbose')
        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return "FAILED"
        rate = res.rate
        #rate = 10
        devport_stats = self.get_cur_run_data()
        # Caluculate rate
        #self.gen_report(args, display = False, skipPop = True)
        self.gen_report(args, display = res.display, skipPop = True)
        ret = "PASS"
        port_list = [0]
        for p in port_list:
            # If any of the configured ports rate is 0, snake test has problem
            if devport_stats.devport_rx_frames[p] == 0:
                ret = "FAIL"
                break
            if (rate != 0):
                expect = rate
                actual = devport_stats.devport_rx_frames[p]
                error  = (math.fabs(actual-expect)/expect) * 100
                if error > 20:
                    ret = "FAIL"
                    break
        log(ret)
        return ret


    def verify(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test verify_traffic', prog='snake', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-rate', type=int, default=0, help='rx in gbps')
        parser.add_argument('-display', type=int, default=False, help='Log verbose')
        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return "FAILED"
        rate = res.rate
        #rate = 10
        devport_stats = self.get_cur_run_data()
        # Caluculate rate
        #self.gen_report(args, display = False, skipPop = True)
        self.gen_report(args, display = res.display, skipPop = True)
        ret = "PASS"
        for p in devport_stats.devport_list:
            # If any of the configured ports rate is 0, snake test has problem
            if devport_stats.devport_rx_gbps[p] == 0:
                ret = "FAIL"
                break
            if (rate != 0):
                expect = rate
                actual = devport_stats.devport_rx_gbps[p]
                error  = (math.fabs(actual-expect)/expect) * 100
                if error > 0.25:
                    ret = "FAIL"
                    break
        log(ret)
        return ret

    def dump_report(self, args):
        pass

    def unconfig(self, args):
        devport_stats = self.get_cur_run_data()
        verbose = devport_stats.verbose
        devport_list = devport_stats.devport_list

        dmac_l2_entry_array = Snake.dmac_l2_entry_array
        smac_l2_entry_array = Snake.smac_l2_entry_array
        port_sp_hdl = Snake.port_sp_hdl
        cpu_sp_hdl = Snake.cpu_sp_hdl
        stp_hdl = Snake.stp_hdl

        member_count = len(port_sp_hdl)
        member_list = (ifcs_handle_t * member_count)()

        for count, port in enumerate(port_sp_hdl):
            member_list[count] = port_sp_hdl[port]

        if verbose:
            log("Removing L2 entry")

        try:
            #for l2_entry in smac_l2_entry_array:
            while smac_l2_entry_array:
                l2_entry = smac_l2_entry_array.pop(0)
                rc = ifcs_l2_entry_delete(0, pointer(l2_entry))
                assert rc == IFCS_SUCCESS, "Delete SMAC L2 entry FAILED!!: rc = [" + str(rc) + "]"
        except:
            log("Hit except (SMAC L2entry) delete")
            pass

        try:
            #for l2_entry in dmac_l2_entry_array:
            while dmac_l2_entry_array:
                l2_entry = dmac_l2_entry_array.pop(0)
                rc = ifcs_l2_entry_delete(0, pointer(l2_entry))
                assert rc == IFCS_SUCCESS, "Delete DMAC L2 entry FAILED!!: rc = [" + str(rc) + "]"
        except:
            log("Hit except (DMAC L2entry) delete")
            pass

        if verbose:
            log("Removing L2VNI members")
        try:
            for i in devport_list:
                l2vni_hdl = ifcs_handle_t()
                l2vni_hdl.value = IFCS_HANDLE_L2VNI(i)
                if (i == 0):
                    continue
                ret = ifcs_l2vni_member_remove(0, l2vni_hdl,
                                               member_count, compat_pointer(member_list, ifcs_handle_t))
                assert ret == IFCS_SUCCESS,\
                       "ERR during L2VNI mbr remove " + str(i)

                #Add CPU port to VNI membership
                ret = ifcs_l2vni_member_remove(0, l2vni_hdl,
                                               1, pointer(cpu_sp_hdl))
                assert ret == IFCS_SUCCESS,\
                       "ERR during L2VNI mbr remove for CPU port" + str(i)
        except:
            log("Hit except L2VNI member delete")
            pass

        try:
            for i in devport_list:
                l2vni_hdl.value = IFCS_HANDLE_L2VNI(i)
                if (i == 0):
                    continue
                ret = ifcs_l2vni_delete(0, l2vni_hdl.value)
                assert ret == IFCS_SUCCESS,\
                       "ERR during L2VNI delete " + str(i)
        except:
            log("Hit except L2VNI delete")
            pass


        try:
            ret = ifcs_stp_delete(0, stp_hdl)
            assert ret == IFCS_SUCCESS, "ERR during STP delete"
        except:
            log("Hit except STP delete")
            pass

        # Set Loopback state to NONE
        try:
            # Disable all the ports
            devport_attr_ct = 1
            devport_attr = (ifcs_attr_t * devport_attr_ct)()
            devport_attr[0].id = IFCS_DEVPORT_ATTR_ADMIN_STATE;
            devport_attr[0].value.u32 = IFCS_BOOL_FALSE;

            for port in devport_stats.devport_list:
                if (port == 0):
                    continue
                rc = ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_attr_t))
                assert rc == IFCS_SUCCESS,\
                    "ERR during port admin disable:" + str(port)

            devport_attr_ct = 1
            devport_attr = (ifcs_attr_t * devport_attr_ct)()
            for port in devport_stats.devport_list:
                if (port == 0):
                    continue
                lb = IFCS_DEVPORT_LOOPBACK_NONE
                devport_attr[0].id = IFCS_DEVPORT_ATTR_LOOPBACK
                devport_attr[0].value.u32 = lb
                rc = ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_attr_t))
                assert rc == IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"

        except:
            log("Hit except (Devport loopback) config")

        Snake.state = SNAKE_UNCONFIG
        return 'PASSED'
