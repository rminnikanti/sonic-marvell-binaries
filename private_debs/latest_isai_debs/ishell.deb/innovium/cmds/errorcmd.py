#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
import copy
import datetime
import sys
from operator import itemgetter
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
from pencmd import penType
from ifcs_cmds.cli_types import *
from print_table import PrintTable
ifcs_ctypes = sys.modules['ifcs_ctypes']
if COMPAT_PY3:
    from functools import cmp_to_key

# Import Error command extensions (primarily for ECC injection)
import errorcmd_extensions as ece

# Return the list of modules that corrresponding to this bitmap
def _modulenames(modulebitmap):
    namestr = ""
    for modidx in range(1, ifcs_ctypes.IFCS_MOD_MAX):
        if (modulebitmap & (1 << modidx)):
            if namestr == "":
                namestr = "IFCS_MOD_" + cli_ifcs_mod_map[modidx]
            else:
                namestr += ", IFCS_MOD_" + cli_ifcs_mod_map[modidx]
    return namestr

# Class implements Ifcs related commands
class Errors(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'show'        : self.show,
                         'clear'       : self.clear,
                         'inject'      : self.inject,
                         'help'        : self.help,
                         '?'           : self.help
                        }
        self.error_display_method = {
                            'ecc' : self.display_ecc_errors,
                            'misc' : self.display_misc_errors,
                               }
        self.error_clear_method = {
                            'ecc' : self.clear_ecc_errors,
                            'misc' : self.clear_misc_errors,
                               }
        self.error_inject_method = {
                            'ecc' : self.inject_ecc_errors,
                               }
        self.cli = cli
        self.arg_list = []
        super(Errors, self).__init__()
        self.ifcs_names = ['port','l2vni']
        self.help_str = "ifcs:        IFCS errors cli commands\n"
        buflen = 64
        namebuf = create_string_buffer(buflen)

    def __del__(self):
        return

    def get_pen_name(self, pen_id):
        ''' Return Pen name from Pen num '''

        if pen_id == -1 or  pen_id == int(0xffffffff):
            return "PEN_INVALID"
        pen_str = c_char_p(b" " * 32)
        rc = ifcs_ctypes.node_get_pen_name(0, pen_id, pen_str, 32)
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for Pen:" + str(pen_id)
        return compat_bytesToStr(pen_str.value)

    def get_field_name(self, field_id):
        ''' Return Field name from Field num '''

        if field_id == -1 or  field_id == int(0xffffffff):
            return "PEN_FNAME_INVALID"
        fld_str = c_char_p(b" " * 32)
        rc = ifcs_ctypes.node_get_pen_field_name(0, field_id, fld_str, 32)
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for Field:" + str(field_id)
        return compat_bytesToStr(fld_str.value)

    def run_cmd(self, args):
        log_dbg(1, "In Errors run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except (KeyError):
            log_dbg(
                1, "KeyError in errors [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except (ValueError):
            log_dbg(
                1, "ValueError in errors [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except Exception as e:
            log_dbg(
                1, "OtherError in errors [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            log("Error: {}".format(e))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_show(self, text):
        if text.upper() == text:
            return [i.upper() for i in self.ifcs_names if i.upper().startswith(text)]
        else:
            return [i.lower() for i in self.ifcs_names if i.lower().startswith(text)]

    complete_port = complete_show
    complete_l2vni = complete_show

    def getErrorType(self, args):
        log_dbg(1,"In getErrorType with args: " + str(args))

        error_type = args.split()[2]

        # This if condition needs to be expanded for other error types
        if error_type == 'ecc':
            return error_type
        elif error_type == 'misc':
            return error_type
        else:
            return 'unsupported'

    # ------------
    # show command
    # ------------
    def show(self, args):
        log_dbg(1, "In error show with args: '" + str(args) + "'")
        rc = 0

        try:
            error_type = self.getErrorType(args)
        except IndexError:
            log_err("Error type not specified")

        try:
            rc = self.error_display_method[error_type](args)
        except:
            log_err("Unexpected error:" + str(sys.exc_info()[0]))
            log_err("ifcs cmd args: {}".format(args))

        return rc

    # ------------
    # clear command
    # ------------
    def clear(self, args):
        log_dbg(1, "In error clear with args: " + str(args))
        rc = 0

        try:
            error_type = self.getErrorType(args)
        except IndexError:
            log_err("Error type not specified")

        try:
            rc = self.error_clear_method[error_type]()
        except:
            log_err("Failed to clear errors")

        return rc

    # ------------
    # inject command
    # ------------
    def inject(self, args):
        log_dbg(1, "In error inject with args: " + str(args))
        rc = 0

        try:
            error_type = self.getErrorType(args)
        except IndexError:
            log_err("Error type not specified")

        try:
            rc = self.error_inject_method[error_type](args)
        except Exception as e:
            log_err("Exception '{}'".format(e))
            log_err("Failed to inject errors, rc: " + str(rc) )
            rc = ifcs_ctypes.IFCS_INVAL

        return rc

    # -------------------------------------------
    # ECC clear method
    # -------------------------------------------
    def clear_ecc_errors(self):
        log_dbg(1, "In clear ecc errors ")
        ifcs_ctypes.ifcs_node_ecc_stats_clear(0)
        log("Clear all ECC error stats")

    # -------------------------------------------
    # ECC inject method
    # -------------------------------------------
    def inject_ecc_errors(self, args):
        log_dbg(1, "In inject ecc errors ")
        (isValid, ib, errType, area, data) = ece.ecc_inject_validate_input(self, args)
        if not isValid:
            if ib is None:
                log("Invalid IB value")
            elif errType is None:
                log("Invalid error type value")
            elif area is None:
                log("Invalid area value")
            log("")
            log("Usage: errors inject ecc ib <#> <ce|ue> <l2_entry|route_entry|nexthop> <l2vni|l3vni|handle> <#> <dmac|smac|ipv4|ipv6> <value>")
            log("          Valid Area Parameters Combination:")
            log("               l2_entry    l2vni   <#>  dmac|smac <#>")
            log("               route_entry l3vni   <#>  ipv4|ipv6 <#>")
            log("               nexthop     handle  <#>")
            return ifcs_ctypes.IFCS_INVAL
        else:
            return ece.ecc_inject_area(self, ib, errType, area, data)

    # -------------------------------------------
    # ECC display methods
    # -------------------------------------------
    def display_ecc_errors(self, args):
        cmdsplit = args.split()
        log_dbg(1, "In display_ecc_errors show with args: '" + str(args) + "'")
        log_dbg(1, "In display_ecc_errors show with args: " + str(cmdsplit))
        if len(cmdsplit) > 3 and cmdsplit[3] == 'help':
            log("errors show ecc - display all ECC errors in the node")
            log("errors show ecc [penname] - display ECC errors only for this cause PEN")
            return ifcs_ctypes.IFCS_SUCCESS

        # If we have a pen name, extract the ID and only show detailed data for that PEN
        onlyPen = None
        moduleIndex = None
        pentype = penType(None, 0)
        if len(cmdsplit) > 3:
            pen_or_mod = cmdsplit[3]
            if pen_or_mod.startswith('IFCS_MOD_'):
                try:
                    moduleIndex = eval('ifcs_ctypes.' + pen_or_mod)
                except:
                    log_dbg(0, "Invalid module name specified: %s" % pen_or_mod)
                    return ifcs_ctypes.IFCS_INVAL

            else:
                try:
                    onlyPen = pentype.get_id_name_from_str(pen_or_mod)
                except:
                    log_dbg(0, "Invalid pen index specified: %s" % pen_or_mod)
                    return ifcs_ctypes.IFCS_INVAL

        ecc_node_stat = ifcs_ctypes.ifcs_ecc_node_stats_t()

        ifcs_ctypes.ifcs_node_ecc_stats(0, pointer(ecc_node_stat ))
        log("%12s:%8s, %12s:%8s, %12s:%8s, %12s:%8s, %12s:%8s" % (
            "TOTAL", str(ecc_node_stat.total_count),
            "TYPE_CE", str(ecc_node_stat.type_ce_count),
            "TYPE_UE", str(ecc_node_stat.type_ue_count),
            "TYPE_TREE", str(ecc_node_stat.type_tree_count),
            "TYPE_INV", str(ecc_node_stat.type_invalid_count)))

        log("%12s:%8s, %12s:%8s, %12s:%8s," % (
            "RATELIMIT", str(ecc_node_stat.rate_limit_hit_count),
            "SW Fixed CE", str(ecc_node_stat.sw_fixed_ce_count),
            "SW Fixed UE", str(ecc_node_stat.sw_fixed_ue_count)))

        log("%12s %8s  %12s:%8s, %12s:%8s, %12s:%8s, %12s:%8s" % (
            "", "",
            "CLS_INFO", str(ecc_node_stat.class_info_count),
            "CLS_ALARM", str(ecc_node_stat.class_alarm_count),
            "CLS_FATAL", str(ecc_node_stat.class_fatal_count),
            "CLS_INV", str(ecc_node_stat.class_invalid_count)))

        pen_stats = (ifcs_ctypes.ifcs_ecc_pen_stats_t * ecc_node_stat.pf_count)()
        ifcs_ctypes.ifcs_node_ecc_pen_stats(0, ecc_node_stat.pf_count, compat_pointer(pen_stats, ifcs_ctypes.ifcs_ecc_pen_stats_t))

        allpenlist = []
        for index in range(ecc_node_stat.pf_count):
            allpenlist.append(pen_stats[index])

        def comparator(p1, p2):
            if p1.timestamp.tv_sec != p2.timestamp.tv_sec:
                result = p1.timestamp.tv_sec - p2.timestamp.tv_sec
            else:
                result = p1.timestamp.tv_usec - p2.timestamp.tv_usec
            return int(result)

        if COMPAT_PY3:
            allpenlist = sorted(allpenlist, key=cmp_to_key(comparator), reverse=True)
        else:
            allpenlist = sorted(allpenlist, cmp=comparator, reverse=True)

        for aPen in allpenlist:
            dt = datetime.datetime.fromtimestamp(aPen.timestamp.tv_sec)

            if onlyPen and onlyPen[0] != aPen.ecc_source_pen:
                continue

            if moduleIndex:
                if not (aPen.ecc_source_users & (1 << moduleIndex)):
                    continue

            log('')
            try:
                log("### PEN Stats: IB: %s, Source: %s, Cause: %s, Field: %s" % (
                    (str(aPen.ecc_ib)),
                    (self.get_pen_name(aPen.ecc_source_pen)),
                    (self.get_pen_name(aPen.ecc_cause_pen)),
                    (self.get_field_name(aPen.ecc_cause_field))))
            except:
                log("### PEN Stats: IB: %s, Source: %s, Cause: %s, Field: %s" % (
                    (str(aPen.ecc_ib)),
                    (str(aPen.ecc_source_pen)),
                    (str(aPen.ecc_cause_pen)),
                    (str(aPen.ecc_cause_field))))


            log(" Total: %8d,     TYPE_CE: %4d,      TYPE_UE: %4d, INFO: %4d, ALARM: %4d, RATELIMIT: %4d, Last: %s.%06d" % (
                aPen.total_count, aPen.type_ce_count, aPen.type_ue_count,
                aPen.class_info_count, aPen.class_alarm_count,
                aPen.rate_limit_hit_count,
                dt, aPen.timestamp.tv_usec))

            log("        %8s  SW Fixed CE: %4d,  SW Fixed UE: %4d," % ("", aPen.sw_fixed_ce_count, aPen.sw_fixed_ue_count))
            log("        %8s      Modules: %s" % (" ", _modulenames(aPen.ecc_source_users)))

            for rowidx in range(16):
                aRow = aPen.err_idx_rows[rowidx]
                dt = datetime.datetime.fromtimestamp(aRow.timestamp.tv_sec)
                if aRow.count > 0:
                    if aRow.intr_type == ifcs_ctypes.IFCS_ECC_INTR_TYPE_INVALID:
                        tstr = "INV"
                    elif aRow.intr_type == ifcs_ctypes.IFCS_ECC_INTR_TYPE_CE:
                        tstr = "CE"
                    elif aRow.intr_type == ifcs_ctypes.IFCS_ECC_INTR_TYPE_UE:
                        tstr = "UE"
                    elif aRow.intr_type == ifcs_ctypes.IFCS_ECC_INTR_TYPE_TREE:
                        tstr = "TREE"
                    elif aRow.intr_type == ifcs_ctypes.IFCS_ECC_INTR_TYPE_DEBUG:
                        tstr = "DBG"
                    elif aRow.intr_type == ifcs_ctypes.IFCS_ECC_INTR_TYPE_USER:
                        tstr = "USR"
                    else:
                        tstr = "UNKN"

                    if aRow.intr_class == ifcs_ctypes.IFCS_ECC_INTR_CLASS_INVALID:
                        cstr = "INV"
                    elif aRow.intr_class == ifcs_ctypes.IFCS_ECC_INTR_CLASS_INFO:
                        cstr = "INFO"
                    elif aRow.intr_class == ifcs_ctypes.IFCS_ECC_INTR_CLASS_ALARM:
                        cstr = "ALRM"
                    elif aRow.intr_class == ifcs_ctypes.IFCS_ECC_INTR_CLASS_FATAL:
                        cstr = "FATL"
                    else:
                        cstr = "UNKN"

                    if aRow.syndrome == 0xFFFFFFFF:    # Its invalid
                        log("   --> Err Index: %8d, Count: %4d, SW Fixed: %4d, Type: %4s, Class: %4s, %16s Last: %s.%06d" % (
                            aRow.index, aRow.count, aRow.sw_fixed, tstr, cstr, "", dt, aRow.timestamp.tv_usec))
                    else:
                        log("   --> Err Index: %8d, Count: %4d, SW Fixed: %4d, Type: %4s, Class: %4s, %16s Last: %s.%06d (0x%x)" % (
                            aRow.index, aRow.count, aRow.sw_fixed, tstr, cstr, "", dt, aRow.timestamp.tv_usec, aRow.syndrome))

        return ifcs_ctypes.IFCS_SUCCESS

    # -------------------------------------------
    # MISC clear method
    # -------------------------------------------
    def clear_misc_errors(self):
        log_dbg(1, "In clear misc errors ")
        ifcs_ctypes.ifcs_node_error_stats_clear(0)
        log("Clear all MISC error stats")

    # -------------------------------------------
    # MISC display methods
    # -------------------------------------------
    def display_misc_errors(self, args):
        cmdsplit = args.split()
        log_dbg(1, "In display_misc_errors show with args: '" + str(args) + "'")
        log_dbg(1, "In display_misc_errors show with args: " + str(cmdsplit))
        if len(cmdsplit) > 3 and cmdsplit[3] == 'help':
            log("errors show misc - display all ECC errors in the node")
            log("errors show misc [penname] - display ECC errors only for this cause PEN")
            return ifcs_ctypes.IFCS_SUCCESS

        error_node_stat = ifcs_ctypes.ifcs_error_node_stats_t()

        ifcs_ctypes.ifcs_node_error_stats(0, pointer(error_node_stat ))
        log("%10s:%8s" % ("TOTAL", str(error_node_stat.total_count)))

        # If we have a pen name, extract the ID and only show detailed data for that PEN
        onlyPen = None
        pentype = penType(None, 0)
        if len(cmdsplit) > 3:
            try:
                onlyPen = pentype.get_id_name_from_str(cmdsplit[3])
            except:
                log_dbg(0, "Invalid pen index specified: %s" % onlyPen)
                return ifcs_ctypes.IFCS_INVAL

        pen_stats = (ifcs_ctypes.ifcs_error_pen_stats_t * error_node_stat.pf_count)()
        ifcs_ctypes.ifcs_node_error_pen_stats(0, error_node_stat.pf_count, compat_pointer(pen_stats, ifcs_ctypes.ifcs_error_pen_stats_t))

        allpenlist = []
        for index in range(error_node_stat.pf_count):
            allpenlist.append(pen_stats[index])

        def comparator(p1, p2):
            if p1.timestamp.tv_sec != p2.timestamp.tv_sec:
                result = p1.timestamp.tv_sec - p2.timestamp.tv_sec
            else:
                result = p1.timestamp.tv_usec - p2.timestamp.tv_usec
            return int(result)

        if COMPAT_PY3:
            allpenlist = sorted(allpenlist, key=cmp_to_key(comparator), reverse=True)
        else:
            allpenlist = sorted(allpenlist, cmp=comparator, reverse=True)

        for aPen in allpenlist:
            dt = datetime.datetime.fromtimestamp(aPen.timestamp.tv_sec)

            if onlyPen and onlyPen[0] != aPen.error_source_pen:
                continue

            log('')
            try:
                log("### PEN Stats: IB: %s, Source: %s, Cause: %s, Field: %s" % (
                    (str(aPen.error_ib)),
                    (self.get_pen_name(aPen.error_source_pen)),
                    (self.get_pen_name(aPen.error_cause_pen)),
                    (self.get_field_name(aPen.error_cause_field))))
            except:
                log("### PEN Stats: IB: %s, Source: %s, Cause: %s, Field: %s" % (
                    (str(aPen.error_ib)),
                    (str(aPen.error_source_pen)),
                    (str(aPen.error_cause_pen)),
                    (str(aPen.error_cause_field))))


            log("    Total: %8d, Last: %s.%06d" % (
                aPen.total_count, dt, aPen.timestamp.tv_usec))

        return ifcs_ctypes.IFCS_SUCCESS


    def help(self, args):
        log("Usage: errors show <type> [args] - Shows errors of specific type [ecc/misc]")
        log(" ")
        log("   ex : errors show ecc            - display all ECC errors")
        log("        errors show ecc [penname]  - display ECC errors only for this penname")
        log("        errors show misc           - display all ECC errors")
        log("        errors show misc [penname] - display ECC errors only for this penname")
        log("        errors inject ecc ib <#> <ce|ue> <l2_entry|route_entry> <l2vni|l3vni> <#> <dmac|smac|ipv4|ipv6> <value> - inject ECC errors in this area")
        log("                Valid Area Parameters Combination:")
        log("                     l2_entry    l2vni   dmac|smac")
        log("                     route_entry l3vni   ipv4|ipv6")
        log("                     nexthop     handle")
        return ifcs_ctypes.IFCS_SUCCESS
