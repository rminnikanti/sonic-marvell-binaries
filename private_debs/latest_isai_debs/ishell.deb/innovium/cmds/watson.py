#-------------------------------------------------------------------------------
# Copyright (c) (2023) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you, your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
import argparse
import select
import shlex
import sys
import time
import threading
import traceback

import ctypes

from cmdmgr import Command, CommandError
from print_table import PrintTable
from verbosity import *
from utils.compat_util import *

ifcs_ctypes = sys.modules['ifcs_ctypes']


def _status_to_string(rc):
    return compat_bytesToStr(ifcs_ctypes.ifcs_status_to_string(rc))


class Watson(Command):
    PATTERNS = ('sso', 'sson', 'qh', 'ql', 'aggresive', 'victim', 'increment', 'user')
    OSC_COUNT = 8
    OSC_ENTRIES = 512
    DATA_WIDTH = 8
    VICTIM_PATTERN = '10110010101101001010101101010000010011010110010100000111111'
    AGGRESIVE_PATTERN = '00011101010010101010101001010001110011010110010110110110011'

    @staticmethod
    def _hex_int(x):
        if x[:2] == '0x':
            return int(x, 16)
        return int(x)

    @staticmethod
    def _usleep(usec):
        select.select([], [], [], usec / 1000000)

    @staticmethod
    def _dump_data(data, width, count, columns):
        for addr in range(0, count, columns):
            chunk = data[addr:addr + columns]
            data_str = ''
            for i, val in enumerate(chunk):
                if i > 0:
                    data_str += ' '
                data_str += '{:0{}x}'.format(val, ((width + 7) // 8) * 2)
            log('{:04x}: {}'.format(addr, data_str))
        log('')

    @staticmethod
    def _gen_sso_pattern(width, count):
        bits_str = '10' * (width // 2)
        bits = int(bits_str, 2)
        return [bits] * count

    @staticmethod
    def _gen_sson_pattern(width, count):
        bits_str = '01' * (width // 2)
        bits = int(bits_str, 2)
        return [bits] * count

    @staticmethod
    def _gen_qh_pattern(width, count):
        bits_str = '1' * width
        bits = int(bits_str, 2)
        return [bits] * count

    @staticmethod
    def _gen_ql_pattern(width, count):
        bits_str = '0' * width
        bits = int(bits_str, 2)
        return [bits] * count

    @staticmethod
    def _gen_pattern(pattern, width, count):
        pattern_pos = 0
        bits = []
        while len(bits) < count:
            if pattern_pos + width < len(pattern):
                chunk = pattern[pattern_pos:pattern_pos + width]
                pattern_pos += width
            else:
                next_size = width - (len(pattern) - pattern_pos)
                chunk = pattern[pattern_pos:] + pattern[:next_size]
                pattern_pos = next_size
            value = int(chunk, 2)
            bits.append(value)
        return bits

    @staticmethod
    def _gen_victim_pattern(width, count):
        victim_pattern = Watson.VICTIM_PATTERN
        return Watson._gen_pattern(victim_pattern, width, count)

    @staticmethod
    def _gen_aggresive_pattern(width, count):
        aggresive_pattern = Watson.AGGRESIVE_PATTERN
        return Watson._gen_pattern(aggresive_pattern, width, count)

    @staticmethod
    def _gen_increment_pattern(width, count, base):
        bits = []
        mask = (1 << width) - 1
        if base is None:
            incr = 0
        else:
            incr = base
        for i in range(count):
            bits.append(incr & mask)
            incr += 1
        return bits

    @staticmethod
    def _get_pattern(pattern, c_type, width, count, user_pattern):
        if pattern == 'sso':
            pattern = Watson._gen_sso_pattern(width, count)
        elif pattern == 'sson':
            pattern = Watson._gen_sson_pattern(width, count)
        elif pattern == 'qh':
            pattern = Watson._gen_qh_pattern(width, count)
        elif pattern == 'ql':
            pattern = Watson._gen_ql_pattern(width, count)
        elif pattern == 'aggresive':
            pattern = Watson._gen_aggresive_pattern(width, count)
        elif pattern == 'victim':
            pattern = Watson._gen_victim_pattern(width, count)
        elif pattern == 'increment':
            pattern = Watson._gen_increment_pattern(width, count, user_pattern)
        elif pattern == 'user':
            pattern = [user_pattern] * count
        else:
            raise ValueError('Invalid pattern {}'.format(pattern))
        return (c_type * count)(*pattern)

    @staticmethod
    def _get_ibs(ib):
        if ib == 'all':
            return compat_listrange(ifcs_ctypes.IFCS_MAX_IBS_NUM)
        try:
            ibs = ib.split(",")
            return [int(i) for i in ibs]
        except Exception as e:
            raise ValueError("Invalid ib value {}: {}".format(ib, (str(e))))

    def __init__(self, cli):
        self.cli = cli
        self.tx_active = False
        self.tx_pattern = [None] * ifcs_ctypes.IFCS_MAX_IBS_NUM
        self.tx_user = [None] * ifcs_ctypes.IFCS_MAX_IBS_NUM
        self.tx_count = [0] * ifcs_ctypes.IFCS_MAX_IBS_NUM
        self.stats_tx_buf_num = 0
        self.stats_tx_bank_num = 0
        self.event_tx_buf_num = 0
        self.thread = None
        self.thread_byte_cnt = 0
        self.thread_msg_cnt = 0
        self.thread_should_exit = False
        self.wtsn_data_bits = [None] * Watson.DATA_WIDTH
        self.wtsn_user_bits = [None] * Watson.DATA_WIDTH

        self.parser = argparse.ArgumentParser(prog='watson')
        sub_parsers = self.parser.add_subparsers()

        parser = sub_parsers.add_parser('help')
        parser.add_argument('cmd', nargs='?', default='')
        parser.set_defaults(func=lambda kwargs: Watson._cliHelp(self, **kwargs))

        parser = sub_parsers.add_parser('WtsnSetDataPattern')
        parser.add_argument('--bit', type=str, help='Watson output data lane (0-7), lanes (lane,lane,...) or all')
        parser.add_argument('--pattern', type=str, choices=Watson.PATTERNS)
        parser.add_argument('--user', type=str)
        parser.set_defaults(func=lambda kwargs: Watson._cliWtsnSetDataPattern(self, **kwargs))

        parser = sub_parsers.add_parser('WtsnShowDataPattern')
        parser.set_defaults(func=lambda kwargs: Watson._cliWtsnShowDataPattern(self, **kwargs))

        parser = sub_parsers.add_parser('WtsnRunTx')
        parser.add_argument('--duration', type=int, help='Duration (seconds)')
        parser.set_defaults(func=lambda kwargs: Watson._cliWtsnRunTx(self, **kwargs))

        parser = sub_parsers.add_parser('WtsnStopTx')
        parser.set_defaults(func=lambda kwargs: Watson._cliWtsnStopTx(self, **kwargs))

        parser = sub_parsers.add_parser('txClearPattern')
        parser.add_argument('--ib', required=True)
        parser.set_defaults(func=lambda kwargs: Watson._cliTxClearPattern(self, **kwargs))

        parser = sub_parsers.add_parser('txSetPattern')
        parser.add_argument('--ib', required=True)
        parser.add_argument('--pattern', type=str.lower, choices=Watson.PATTERNS)
        parser.add_argument('--user', type=Watson._hex_int, help='User defined pattern (32bit) for "user" pattern')
        parser.add_argument('--count', type=int, default=Watson.OSC_ENTRIES, help='Number of words (32bit) in a message')
        parser.set_defaults(func=lambda kwargs: Watson._cliTxSetPattern(self, **kwargs))

        parser = sub_parsers.add_parser('txStart')
        parser.add_argument('--duration', type=int, help='Duration (seconds)')
        parser.set_defaults(func=lambda kwargs: Watson._cliTxStart(self, **kwargs))

        parser = sub_parsers.add_parser('txStop')
        parser.set_defaults(func=lambda kwargs: Watson._cliTxStop(self, **kwargs))

        parser = sub_parsers.add_parser('txPause')
        parser.set_defaults(func=lambda kwargs: Watson._cliTxPause(self, **kwargs))

        parser = sub_parsers.add_parser('txResume')
        parser.set_defaults(func=lambda kwargs: Watson._cliTxResume(self, **kwargs))

        parser = sub_parsers.add_parser('txCounters')
        parser.set_defaults(func=lambda kwargs: Watson._cliTxCounters(self, **kwargs))

        parser = sub_parsers.add_parser('txConfig')
        parser.set_defaults(func=lambda kwargs: Watson._cliTxConfig(self, **kwargs))

        parser = sub_parsers.add_parser('debugTxStart')
        parser.add_argument('--pattern', type=str.lower, choices=Watson.PATTERNS, required=True)
        parser.add_argument('--user', type=Watson._hex_int, help='User defined pattern (32bit) for "user" pattern')
        parser.add_argument('--count', type=int, required=True, help='Number of words (32bit) in a message')
        parser.add_argument('--crc16', type=Watson._hex_int, help='User specified crc16')
        parser.add_argument('--loop', type=int, required=True, help='-1 - run until stopped')
        parser.set_defaults(func=lambda kwargs: Watson._cliDebugTxStart(self, **kwargs))

        parser = sub_parsers.add_parser('debugTxStop')
        parser.set_defaults(func=lambda kwargs: Watson._cliDebugTxStop(self, **kwargs))

        parser = sub_parsers.add_parser('debugTxCounters')
        parser.set_defaults(func=lambda kwargs: Watson._cliDebugTxCounters(self, **kwargs))

        hws_parsers = sub_parsers

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlReset')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlReset(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlGetCounters')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlGetCounters(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlTxConfig')
        parser.add_argument('--data_gate_en', type=int, choices=range(2), required=True)
        parser.add_argument('--clk_gate_en', type=int, choices=range(2), required=True)
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlTxConfig(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlConfig')
        parser.add_argument('--mode', type=str.lower, choices=['stats', 'events', '5050', '7525', '2575'], required=True)
        parser.add_argument('--ib_mask', type=Watson._hex_int, required=True)
        parser.add_argument('--stats_timer', type=Watson._hex_int, default=0xffff, help='Stats capture wait timer')
        parser.add_argument('--event_timer', type=Watson._hex_int, default=0x000f, help='Event capture wait timer')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlConfig(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlStatsConfig')
        parser.add_argument('--cfg', type=int, choices=range(8), required=True)
        parser.add_argument('--enabled', type=int, choices=range(2), required=True)
        parser.add_argument('--id', type=int, required=True, help='Statistics id')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlStatsConfig(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlStatsConfigIB')
        parser.add_argument('--ib', required=True)
        parser.add_argument('--enabled', type=int, choices=range(2), required=True)
        parser.add_argument('--id', type=int, required=True, help='Statistics id')
        parser.add_argument('--count', type=int, required=True, help='Number of words (32bit) in a message')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlStatsConfigIB(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlStatsEnable')
        parser.add_argument('--enabled', type=int, choices=range(2), required=True)
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlStatsEnable(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlStatsSetIdle')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlStatsSetIdle(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlStatsSelectTxBuffer')
        parser.add_argument('--buf', dest='buf_num', type=int, choices=range(2))
        parser.add_argument('--bank', dest='bank_num', type=int, choices=range(2))
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlStatsSelectTxBuffer(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlStatsZeroTxBuffer')
        parser.add_argument('--buf', dest='buf_num', type=int, choices=range(2))
        parser.add_argument('--bank', dest='bank_num', type=int, choices=range(2))
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlStatsZeroTxBuffer(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlStatsWriteTxBuffer')
        parser.add_argument('--buf', dest='buf_num', type=int, choices=range(2))
        parser.add_argument('--bank', dest='bank_num', type=int, choices=range(2))
        parser.add_argument('--count', type=int, required=True, help='Number of words (32bit) in a message')
        parser.add_argument('--pattern', type=str.lower, choices=Watson.PATTERNS, required=True)
        parser.add_argument('--user', type=Watson._hex_int, help='User defined pattern (32bit) for "user" pattern')
        parser.add_argument('--echo', action='store_true')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlStatsWriteTxBuffer(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlStatsReadTxBuffer')
        parser.add_argument('--buf', dest='buf_num', type=int, choices=range(2))
        parser.add_argument('--bank', dest='bank_num', type=int, choices=range(2))
        parser.add_argument('--count', type=int, required=True, help='Number of words (32bit) in a message')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlStatsReadTxBuffer(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlStatsSetupTxDebug')
        parser.add_argument('--buf', dest='buf_num', type=int, choices=range(2))
        parser.add_argument('--count', type=int, required=True, help='Number of words (32bit) in a message')
        parser.add_argument('--crc16', type=Watson._hex_int, help='User specified crc16')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlStatsSetupTxDebug(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlStatsStartTxDebug')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlStatsStartTxDebug(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlStatsStopTxDebug')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlStatsStopTxDebug(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlEventEnable')
        parser.add_argument('--enabled', type=int, choices=range(2), required=True)
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlEventEnable(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlEventSetIdle')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlEventSetIdle(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlEventSelectTxBuffer')
        parser.add_argument('--buf', type=int, choices=range(2))
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlEventSelectTxBuffer(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlEventWriteTxBuffer')
        parser.add_argument('--buf', type=int, choices=range(2))
        parser.add_argument('--count', type=int, required=True, help='Number of words to write')
        parser.add_argument('--pattern', type=str.lower, choices=Watson.PATTERNS, required=True)
        parser.add_argument('--user', type=Watson._hex_int, help='User defined pattern (32bit) for "user" pattern')
        parser.add_argument('--echo', action='store_true')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlEventWriteTxBuffer(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonCtrlEventReadTxBuffer')
        parser.add_argument('--buf', type=int, choices=range(2))
        parser.add_argument('--count', type=int, required=True, help='Number of words to read')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonCtrlEventReadTxBuffer(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonAgentStatsEnable')
        parser.add_argument('--ib', required=True)
        parser.add_argument('--enabled', type=int, choices=range(2), required=True)
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonAgentStatsEnable(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonAgentEventEnable')
        parser.add_argument('--ib', required=True)
        parser.add_argument('--enabled', type=int, choices=range(2), required=True)
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonAgentEventEnable(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonAgentOscConfig')
        parser.add_argument('--ib', required=True)
        parser.add_argument('--osc',
                            dest='osc_num',
                            type=int,
                            required=True,
                            help='OSC number: 0 for OSC-0, 1 (OSC-0a), 2 (OSC-1), 3 (OSC-1a), 4 (OSC-2), 5 (OSC-2a), 6 (OSC-3), 7 (OSC-3a)')
        parser.add_argument('--count', type=int, required=True, help='Number of stats entries in the OSC memory')
        parser.add_argument('--enabled', type=int, choices=range(2), required=True, help='1 - enable, 0 - disable')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonAgentOscConfig(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonAgentOscWrite')
        parser.add_argument('--ib', type=int, required=True)
        parser.add_argument('--osc',
                            dest='osc_num',
                            type=int,
                            required=True,
                            help='OSC number: 0 for OSC-0, 1 (OSC-0a), 2 (OSC-1), 3 (OSC-1a), 4 (OSC-2), 5 (OSC-2a), 6 (OSC-3), 7 (OSC-3a)')
        parser.add_argument('--count', type=int, default=Watson.OSC_ENTRIES, help='Number of words to write')
        parser.add_argument('--pattern', type=str.lower, choices=Watson.PATTERNS, required=True)
        parser.add_argument('--user', type=Watson._hex_int, help='User defined pattern (32bit) for "user" pattern')
        parser.add_argument('--echo', action='store_true')
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonAgentOscWrite(self, **kwargs))

        parser = hws_parsers.add_parser('mvHwsWatsonAgentOscRead')
        parser.add_argument('--ib', type=int, required=True)
        parser.add_argument('--osc',
                            dest='osc_num',
                            type=int,
                            required=True,
                            help='OSC number: 0 for OSC-0, 1 (OSC-0a), 2 (OSC-1), 3 (OSC-1a), 4 (OSC-2), 5 (OSC-2a), 6 (OSC-3), 7 (OSC-3a)')
        parser.add_argument('--count', type=int, default=Watson.OSC_ENTRIES)
        parser.set_defaults(func=lambda kwargs: Watson._mvHwsWatsonAgentOscRead(self, **kwargs))

        self.sub_cmds = self.parser._subparsers._actions[-1].choices

        super(Watson, self).__init__()

    def _cliHelp(self, cmd=''):
        if cmd == '':
            self.parser.print_help()
            return ifcs_ctypes.IFCS_SUCCESS
        parser = self.parser._subparsers._actions[-1].choices.get(cmd)
        if parser is None:
            log_err('Unknown command: {}'.format(cmd))
            return ifcs_ctypes.IFCS_INVAL
        parser.print_help()
        return ifcs_ctypes.IFCS_SUCCESS


    def _cliWtsnSetDataPattern(self, bit, pattern, user):
        if self.tx_active:
            log("Watson data traffic is currently active. Use WtsnStopTx to stop the traffic")
            return ifcs_ctypes.IFCS_SUCCESS
        if pattern == 'increment':
            log_err("Invalid pattern {}".format(pattern))
            return ifcs_ctypes.IFCS_SUCCESS
        elif pattern == 'user':
            if user is None:
                log_err("Specify user defined pattern using --user argument")
                return ifcs_ctypes.IFCS_SUCCESS
        if bit == 'all':
            bits = compat_listrange(Watson.DATA_WIDTH)
        else:
            bits = [int(b) for b in bit.split(',')]
        for bit in bits:
            self.wtsn_data_bits[bit] = pattern
            self.wtsn_user_bits[bit] = user
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliWtsnShowDataPattern(self):
        for bit in range(Watson.DATA_WIDTH):
            pattern = self.wtsn_data_bits[bit]
            if pattern == 'user':
                user = self.wtsn_user_bits[bit]
                log('Bit {}: {}'.format(bit, user))
            else:
                log('Bit {}: {}'.format(bit, pattern))
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliWtsnRunTx(self, duration):
        if self.tx_active:
            log("Watson data traffic is currently active. Use WtsnStopTx to stop the traffic")
            return ifcs_ctypes.IFCS_SUCCESS
        pattern_data = (ctypes.c_uint32 * Watson.OSC_ENTRIES)()
        for bit, pattern in enumerate(self.wtsn_data_bits):
            if pattern is None:
                continue
            if pattern == 'sso':
                bit_pattern = '0101'
            elif pattern == 'sson':
                bit_pattern = '1010'
            elif pattern == 'qh':
                bit_pattern = '1111'
            elif pattern == 'ql':
                bit_pattern = '0011'
            elif pattern == 'aggresive':
                bit_pattern = Watson.AGGRESIVE_PATTERN
            elif pattern == 'victim':
                bit_pattern = Watson.VICTIM_PATTERN
            elif pattern == 'user':
                bit_pattern = self.wtsn_user_bits[bit]
            else:
                raise ValueError("Invalid pattern {}".format(pattern))
            pattern_idx = 0
            pattern_len = (Watson.OSC_ENTRIES // (len(bit_pattern) * 4)) * (len(bit_pattern) * 4)
            for i in range(pattern_len):
                for bit_pos in range(0, 32, 8):
                    bit_value = 0 if bit_pattern[pattern_idx] == '0' else 1
                    pattern_idx += 1
                    if pattern_idx >= len(bit_pattern):
                        pattern_idx = 0
                    pattern_data[i] = pattern_data[i] | (bit_value << (bit_pos + bit))

        rc = ifcs_ctypes.mvHwsWatsonAgentOscWrite(self.cli.node_id, 0, 0, pattern_data, len(pattern_data))
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonAgentOscWrite() failed.', rc, _status_to_string(rc))

        stats_id = ifcs_ctypes.WATSON_STATS_QUEUE_DROPPED_PACKETS
        self._mvHwsWatsonCtrlStatsConfigIB(ib=0, enabled=True, id=stats_id, count=len(pattern_data))
        self._mvHwsWatsonAgentOscConfig(ib=0, osc_num=0, count=len(pattern_data), enabled=True)
        self._mvHwsWatsonAgentStatsEnable(ib=0, enabled=True)
        self._mvHwsWatsonCtrlTxConfig(data_gate_en=True, clk_gate_en=True)
        self._mvHwsWatsonCtrlConfig(mode='stats', ib_mask=0x01, stats_timer=0x1fff)
        self._mvHwsWatsonCtrlStatsConfig(cfg=0, enabled=True, id=stats_id)
        self._mvHwsWatsonCtrlStatsEnable(enabled=True)

        self.tx_active = True
        if duration is not None:
            log("Watson data traffic is active for {} seconds".format(duration))
            time.sleep(duration)
            self._cliWtsnStopTx()
        else:
            log("Watson data traffic is active. Use WtsnStopTx to stop the traffic")
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliWtsnStopTx(self):
        if not self.tx_active:
            log('Watson traffic is not active')
            return ifcs_ctypes.IFCS_SUCCESS

        self._mvHwsWatsonCtrlGetCounters()
        self._mvHwsWatsonCtrlStatsEnable(enabled=False)

        stats_id = ifcs_ctypes.WATSON_STATS_QUEUE_DROPPED_PACKETS
        self._mvHwsWatsonCtrlStatsConfigIB(ib=0, enabled=False, id=stats_id, count=Watson.OSC_ENTRIES)
        self._mvHwsWatsonCtrlStatsConfig(cfg=0, enabled=False, id=stats_id)
        self._mvHwsWatsonAgentStatsEnable(ib=0, enabled=False)
        self._mvHwsWatsonAgentOscConfig(ib=0, osc_num=0, count=Watson.OSC_ENTRIES, enabled=False)
        self._mvHwsWatsonCtrlReset()
        self._usleep(100000)
        self.tx_active = False
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliTxClearPattern(self, ib):
        ibs = Watson._get_ibs(ib)
        for ib in ibs:
            for osc_num in range(Watson.OSC_COUNT):
                self._mvHwsWatsonAgentOscWrite(ib, osc_num, 'user', 0, None, False)
            self.tx_pattern[ib] = None
            self.tx_user[ib] = None
            self.tx_count[ib] = 0
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliTxSetPattern(self, ib, pattern, count, user, echo=False):
        ibs = Watson._get_ibs(ib)
        for ib in ibs:
            if pattern is None:
                self.tx_pattern[ib] = None
                self.tx_user[ib] = None
                self.tx_count[ib] = 0
                continue

            if pattern == 'increment' or pattern == 'user':
                if user is None:
                    log_err("--user must be specifed for pattern {}".format(pattern))
                    return ifcs_ctypes.IFCS_SUCCESS

            if count > Watson.OSC_ENTRIES:
                log_err('The maximum value for count is {}'.format(Watson.OSC_ENTRIES))
                return ifcs_ctypes.IFCS_SUCCESS

            self.tx_pattern[ib] = pattern
            self.tx_user[ib] = user
            self.tx_count[ib] = count

            osc_num = 0
            pattern_count = count
            while pattern_count > 0:
                if pattern_count > Watson.OSC_ENTRIES:
                    osc_count = Watson.OSC_ENTRIES
                else:
                    osc_count = pattern_count
                self._mvHwsWatsonAgentOscWrite(ib, osc_num, pattern, osc_count, user, echo)
                pattern_count -= osc_count
                osc_num += 1

        return ifcs_ctypes.IFCS_SUCCESS

    def _cliTxStart(self, duration):
        if self.tx_active:
            log('Watson traffic is currently active. Stop Watson using "stop_tx" command then do "start_tx" again')
            return ifcs_ctypes.IFCS_SUCCESS

        self._mvHwsWatsonCtrlReset()
        self._usleep(100000)

        for buf_num in range(2):
            for bank_num in range(2):
                self._mvHwsWatsonCtrlStatsZeroTxBuffer(buf_num, bank_num)

        stats_id = ifcs_ctypes.WATSON_STATS_QUEUE_DROPPED_PACKETS
        total_size = 0
        ib_cout = 0
        ib_mask = 0
        for ib in range(ifcs_ctypes.IFCS_MAX_IBS_NUM):
            if self.tx_pattern[ib] is None:
                continue
            tx_count = self.tx_count[ib]
            total_size += tx_count
            self._mvHwsWatsonCtrlStatsConfigIB(ib=ib, enabled=True, id=stats_id, count=tx_count)
            ib_count += 1
            ib_mask |= 1 << ib
            osc_num = 0
            while tx_count > 0:
                if tx_count > Watson.OSC_ENTRIES:
                    osc_count = Watson.OSC_ENTRIES
                else:
                    osc_count = tx_count
                self._mvHwsWatsonAgentOscConfig(ib, osc_num, osc_count, True)
                tx_count -= osc_count
                osc_num += 1
            self._mvHwsWatsonAgentStatsEnable(ib=ib, enabled=True)

        if not total_size:
            log('Use txSetPattern to specify data pattern and count')
            return ifcs_ctypes.IFCS_PARAM

        self._mvHwsWatsonCtrlTxConfig(data_gate_en=True, clk_gate_en=True)
        self._mvHwsWatsonCtrlConfig(mode='stats', ib_mask=ib_mask, stats_timer=0x1fff)
        self._mvHwsWatsonCtrlStatsConfig(cfg=0, enabled=True, id=stats_id)
        self._mvHwsWatsonCtrlStatsEnable(enabled=True)
        self.tx_active = True
        if duration is not None:
            log("Sending Watson data pattern for {} seconds".format(duration))
            time.sleep(duration)
            self._cliTxStop()
        else:
            log("Sending Watson data pattern in the background. Use txStop to stop the traffic or txCounters to show the counters")
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliTxStop(self):
        if not self.tx_active:
            log('Watson traffic is not active')
            return ifcs_ctypes.IFCS_SUCCESS

        self._mvHwsWatsonCtrlGetCounters()
        self._mvHwsWatsonCtrlStatsEnable(enabled=False)

        stats_id = ifcs_ctypes.WATSON_STATS_QUEUE_DROPPED_PACKETS
        for ib in range(ifcs_ctypes.IFCS_MAX_IBS_NUM):
            if self.tx_pattern[ib] is None:
                continue
            tx_count = self.tx_count[ib]
            self._mvHwsWatsonAgentStatsEnable(ib=ib, enabled=False)
            self._mvHwsWatsonCtrlStatsConfigIB(ib=ib, enabled=False, id=stats_id, count=tx_count)
            self._mvHwsWatsonCtrlStatsConfig(cfg=0, enabled=False, id=stats_id)
            osc_num = 0
            while tx_count > 0:
                if tx_count > Watson.OSC_ENTRIES:
                    osc_count = Watson.OSC_ENTRIES
                else:
                    osc_count = tx_count
                self._mvHwsWatsonAgentOscConfig(ib, osc_num, osc_count, enabled=False)
                tx_count -= osc_count
                osc_num += 1

        self._mvHwsWatsonCtrlReset()
        self._usleep(100000)
        self.tx_active = False
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliTxPause(self):
        if not self.tx_active:
            log('Watson traffic is not active')
            return ifcs_ctypes.IFCS_SUCCESS

        enabled = ifcs_ctypes.ifcs_bool_t()
        rc = ifcs_ctypes.mvHwsWatsonCtrlStatsGetEnabled(self.cli.node_id, enabled)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlStatsGetEnabled() failed.', rc, _status_to_string(rc))

        if enabled.value:
            self._mvHwsWatsonCtrlStatsEnable(enabled=False)
        else:
            log('Watson traffic is already paused.')
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliTxResume(self):
        if not self.tx_active:
            log('Watson traffic is not active')
            return ifcs_ctypes.IFCS_SUCCESS

        enabled = ifcs_ctypes.ifcs_bool_t()
        rc = ifcs_ctypes.mvHwsWatsonCtrlStatsGetEnabled(self.cli.node_id, enabled)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlStatsGetEnabled() failed.', rc, _status_to_string(rc))

        if enabled.value:
            log('Watson traffic is already active.')
        else:
            self._mvHwsWatsonCtrlStatsEnable(enabled=True)
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliTxCounters(self):
        return self._mvHwsWatsonCtrlGetCounters()

    def _cliTxConfig(self):
        table = PrintTable()
        table.add_row(['IB', 'Pattern', 'Data Count'])
        for ib in range(ifcs_ctypes.IFCS_MAX_IBS_NUM):
            pattern = self.tx_pattern[ib]
            if pattern == 'increment' or pattern == 'user':
                pattern = "{} (0x{:08x})".format(pattern, self.tx_user[ib])
            table.add_row((ib,
                pattern,
                self.tx_count[ib]))
        table.print_table(brief=True)
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliDebugTxStart(self, pattern, count, user, crc16, loop):
        if self.thread:
            log('Watson transmit thread is already running.')
            return ifcs_ctypes.IFCS_SUCCESS

        if count < 1 or count > 4095:
            log_err('The stats_count argument must be an integer in the range  1..4095: count={}'.format(count))
            return ifcs_ctypes.IFCS_PARAM

        if crc16 is None:
            crc16 = 0

        self.thread_data = Watson._get_pattern(pattern, ctypes.c_uint32, 32, count, user)
        self.thread_buf_num = 0

        self.thread_args = argparse.Namespace()
        self.thread_args.pattern = pattern
        self.thread_args.count = count
        self.thread_args.user = user
        self.thread_args.crc16 = crc16
        self.thread_args.loop = loop

        if loop == -1 or loop >= 100000:
            log('Starting Watson transmit thread')
            self.thread = threading.Thread(target=self._run, daemon=True)
            self.thread.start()
        else:
            self._run()
            self._cliDebugTxCounters()
            self._mvHwsWatsonCtrlReset()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliDebugTxStop(self):
        if not self.thread:
            log('The Watson trasmit thread is not currently running')
            return ifcs_ctypes.IFCS_SUCCESS

        log('Stopping Watson transmit thread')
        self.thread_should_exit = True
        self.thread.join()
        log('Watson transmit thread is stopped')
        self._cliDebugTxCounters()
        self.thread = None
        self._mvHwsWatsonCtrlReset()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliDebugTxCounters(self):
        table = PrintTable()
        table.add_row(['Counter', 'Value'])
        table.add_row(['Messages', self.thread_msg_cnt])
        table.add_row(['Bytes', self.thread_byte_cnt])
        table.print_table(brief=True)
        return ifcs_ctypes.IFCS_SUCCESS

    def _run(self):
        self.thread_should_exit = False
        self.thread_byte_cnt = 0
        self.thread_msg_cnt = 0

        curr_msg_cnt = ctypes.c_uint32()
        curr_byte_cnt = ctypes.c_uint32()

        while True:
            rc = ifcs_ctypes.mvHwsWatsonCtrlReset(self.cli.node_id)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                raise CommandError('mvHwsWatsonCtrlReset() failed.', rc, _status_to_string(rc))

            rc = ifcs_ctypes.mvHwsWatsonCtrlTxConfig(self.cli.node_id, True, True)
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                raise CommandError('mvHwsWatsonCtrlTxConfig() failed.', rc, _status_to_string(rc))

            rc = ifcs_ctypes.mvHwsWatsonAgentStatsEnable(self.cli.node_id, 0, False)
            while rc == ifcs_ctypes.IFCS_DEVICE_ACCESS_ERROR:
                Watson._usleep(1)
                rc = ifcs_ctypes.mvHwsWatsonAgentStatsEnable(self.cli.node_id, 0, False)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                raise CommandError('mvHwsWatsonAgentStatsEnable() failed.', rc, _status_to_string(rc))

            rc = ifcs_ctypes.mvHwsWatsonAgentEventEnable(self.cli.node_id, 0, False)
            while rc == ifcs_ctypes.IFCS_DEVICE_ACCESS_ERROR:
                Watson._usleep(1)
                rc = ifcs_ctypes.mvHwsWatsonAgentEventEnable(self.cli.node_id, 0, False)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                raise CommandError('mvHwsWatsonAgentEventEnable() failed.', rc, _status_to_string(rc))

            rc = ifcs_ctypes.mvHwsWatsonCtrlStatsSetIdle(self.cli.node_id, False)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                raise CommandError('mvHwsWatsonCtrlStatsSetIdle() failed.', rc, _status_to_string(rc))

            data_in = self.thread_data
            data_count = 2048 if self.thread_args.count > 2048 else self.thread_args.count
            rc = ifcs_ctypes.mvHwsWatsonCtrlStatsWriteTxBuffer(self.cli.node_id, self.thread_buf_num, 0, data_in, data_count)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                raise CommandError('mvHwsWatsonCtrlStatsWriteTxBuffer() failed.', rc, _status_to_string(rc))

            if self.thread_args.count > data_count:
                data_in = ctypes.cast(ctypes.byref(self.thread_data, sizeof(ctypes.c_uint32) * count), POINTER(ctypes.c_uint32))
                data_count = self.thread_args.count - data_count
                rc = ifcs_ctypes.mvHwsWatsonCtrlStatsWriteTxBuffer(self.cli.node_id, self.thread_buf_num, 1, data_in, data_count)
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    raise CommandError('mvHwsWatsonCtrlStatsWriteTxBuffer() failed.', rc, _status_to_string(rc))

            rc = ifcs_ctypes.mvHwsWatsonCtrlStatsSetupTxDebug(self.cli.node_id, 0, self.thread_args.count, self.thread_args.crc16)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                raise CommandError('mvHwsWatsonCtrlStatsSetupTxDebug() failed.', rc, _status_to_string(rc))

            rc = ifcs_ctypes.mvHwsWatsonCtrlConfig(self.cli.node_id, ifcs_ctypes.WATSON_STREAMING_MODE_STATS, 0)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                raise CommandError('mvHwsWatsonCtrlConfig() failed.', rc, _status_to_string(rc))

            rc = ifcs_ctypes.mvHwsWatsonCtrlStatsStartTxDebug(self.cli.node_id)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                raise CommandError('mvHwsWatsonCtrlStatsStartTxDebug() failed.', rc, _status_to_string(rc))

            while True:
                rc = ifcs_ctypes.mvHwsWatsonCtrlGetCounters(self.cli.node_id, ctypes.pointer(curr_msg_cnt), ctypes.pointer(curr_byte_cnt))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    raise CommandError('mvHwsWatsonCtrlGetCounters() failed.', rc, _status_to_string(rc))
                if curr_msg_cnt.value == 1:
                    break
                Watson._usleep(1)
                if self.thread_should_exit:
                    break

            self.thread_msg_cnt += curr_msg_cnt.value
            self.thread_byte_cnt += curr_byte_cnt.value

            if self.thread_args.loop > 0:
                self.thread_args.loop -= 1
                if self.thread_args.loop == 0:
                    break

            if self.thread_should_exit:
                break
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlReset(self):
        rc = ifcs_ctypes.mvHwsWatsonCtrlReset(self.cli.node_id)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            raise CommandError('mvHwsWatsonCtrlReset() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlGetCounters(self):
        msg_cntr = (ctypes.c_uint32)()
        byte_cntr = (ctypes.c_uint32)()
        rc = ifcs_ctypes.mvHwsWatsonCtrlGetCounters(self.cli.node_id, ctypes.pointer(msg_cntr), ctypes.pointer(byte_cntr))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            raise CommandError('mvHwsWatsonCtrlGetCounters failed', rc, _status_to_string(rc))

        table = PrintTable()
        table.add_row(['Counter', 'Value'])
        table.add_row(['Messages', msg_cntr.value])
        table.add_row(['Bytes', byte_cntr.value])
        table.print_table(brief=True)
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlTxConfig(self, data_gate_en, clk_gate_en):
        rc = ifcs_ctypes.mvHwsWatsonCtrlTxConfig(self.cli.node_id, data_gate_en, clk_gate_en)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlTxConfig() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlConfig(self, mode, ib_mask, stats_timer=0xffff, event_timer=0x000f):
        if mode == 'stats':
            streaming_mode = ifcs_ctypes.WATSON_STREAMING_MODE_STATS
        elif mode == 'events':
            streaming_mode = ifcs_ctypes.WATSON_STREAMING_MODE_EVENTS
        elif mode == '5050':
            streaming_mode = ifcs_ctypes.WATSON_STREAMING_MODE_STATS_50_EVENTS_50
        elif mode == '7525':
            streaming_mode = ifcs_ctypes.WATSON_STREAMING_MODE_STATS_75_EVENTS_25
        elif mode == '2575':
            streaming_mode = ifcs_ctypes.WATSON_STREAMING_MODE_STATS_25_EVENTS_75
        else:
            log_err('Invalid streamimg mode {}'.format(mode))
            return ifcs_ctypes.IFCS_PARAM

        rc = ifcs_ctypes.mvHwsWatsonCtrlConfig(self.cli.node_id, streaming_mode, ib_mask, stats_timer, event_timer)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlConfig() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlStatsConfig(self, cfg, enabled, id):
        rc = ifcs_ctypes.mvHwsWatsonCtrlStatsConfig(self.cli.node_id, cfg, enabled, id)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlStatsConfig() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlStatsConfigIB(self, ib, enabled, id, count):
        rc = ifcs_ctypes.mvHwsWatsonCtrlStatsConfigIB(self.cli.node_id, ib, enabled, id, count)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlStatsConfigIB() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlStatsEnable(self, enabled):
        rc = ifcs_ctypes.mvHwsWatsonCtrlStatsEnable(self.cli.node_id, enabled)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlStatsEnable() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlStatsSetIdle(self):
        rc = ifcs_ctypes.mvHwsWatsonCtrlStatsSetIdle(self.cli.node_id)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlStatsSetIdle() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlStatsSelectTxBuffer(self, buf_num, bank_num):
        if not buf_num is None:
            self.stats_tx_buf_num = buf_num

        if not bank_num is None:
            self.stats_tx_bank_num = bank_num

        log('ctrlStatsSelectTxBuffer: buf={}, bank={}'.format(self.stats_tx_buf_num, self.stats_tx_bank_num))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlStatsZeroTxBuffer(self, buf_num, bank_num):
        if buf_num is None:
            buf_num = self.stats_tx_buf_num

        if bank_num is None:
            bank_num = self.stats_tx_bank_num

        rc = ifcs_ctypes.mvHwsWatsonCtrlStatsZeroTxBuffer(self.cli.node_id, buf_num, bank_num)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlStatsZeroTxBuffer() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlStatsWriteTxBuffer(self, buf_num, bank_num, pattern, count, user, echo=False):
        if count < 1 or count > 2048:
            log_err('The count argument must be an integer in the range  1..2048: count={}'.format(count))
            return ifcs_ctypes.IFCS_PARAM

        if buf_num is None:
            buf_num = self.stats_tx_buf_num

        if bank_num is None:
            bank_num = self.stats_tx_bank_num

        data_in = Watson._get_pattern(pattern, ctypes.c_uint32, 32, count, user)
        if echo:
            log('ctrlStatsWriteTxBuffer: buf={}, bank={}, count={}, patter={}, user={}'.format(buf_num, bank_num, count, pattern, user))
            self._dump_data(data_in, 32, count, 8)

        rc = ifcs_ctypes.mvHwsWatsonCtrlStatsWriteTxBuffer(self.cli.node_id, buf_num, bank_num, data_in, count)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlStatsWriteTxBuffer() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlStatsReadTxBuffer(self, buf_num, bank_num, count):
        if count < 1 or count > 2048:
            log_err('The count argument must be an integer in the range  1..2048: count={}'.format(count))
            return ifcs_ctypes.IFCS_PARAM

        if buf_num is None:
            buf_num = self.stats_tx_buf_num

        if bank_num is None:
            bank_num = self.stats_tx_bank_num

        data_out = (ctypes.c_uint32 * count)()
        rc = ifcs_ctypes.mvHwsWatsonCtrlStatsReadTxBuffer(self.cli.node_id, buf_num, bank_num, data_out, count)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlStatsReadTxBuffer() failed.', rc, _status_to_string(rc))

        log('ctrlStatsReadTxBuffer: buf={}, bank={}, count={}'.format(buf_num, bank_num, count))
        self._dump_data(data_out, 32, count, 8)
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlStatsSetupTxDebug(self, buf_num, count, crc16):
        if count < 1 or count > 4095:
            log_err('The count argument must be an integer in the range  1..4095: count={}'.format(count))
            return ifcs_ctypes.IFCS_PARAM

        if buf_num is None:
            buf_num = self.stats_tx_buf_num

        log('ctrlStatsSetupTxDebug: buf={}, count={}, crc16={}'.format(buf_num, count, crc16))

        if crc16 is None:
            crc16 = 0

        rc = ifcs_ctypes.mvHwsWatsonCtrlStatsSetupTxDebug(self.cli.node_id, buf_num, count, crc16)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlStatsSetupTxDebug() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlStatsStartTxDebug(self):
        rc = ifcs_ctypes.mvHwsWatsonCtrlStatsStartTxDebug(self.cli.node_id)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlStatsStartTxDebug() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlStatsStopTxDebug(self):
        rc = ifcs_ctypes.mvHwsWatsonCtrlStatsStopTxDebug(self.cli.node_id)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlStatsStopTxDebug() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlEventEnable(self, enabled):
        rc = ifcs_ctypes.mvHwsWatsonCtrlEnableEvent(self.cli.node_id, enabled)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlEnableEvent() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlEventSetIdle(self):
        rc = ifcs_ctypes.mvHwsWatsonCtrlEventSetIdle(self.cli.node_id)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlEventSetIdle() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlEventSelectTxBuffer(self, buf_num):
        if not buf_num is None:
            self.event_tx_buf_num = buf_num
        log('ctrlEventSelectTxBuffer: buf={}'.format(self.stats_tx_buf_num))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlEventWriteTxBuffer(self, buf_num, pattern, count, user, echo=False):
        if count < 1 or count > 256:
            log_err('The count argument must be an integer in the range  1..256: count={}'.format(count))
            return ifcs_ctypes.IFCS_PARAM

        if buf_num is None:
            buf_num = self.event_tx_buf_num

        data_in = Watson._get_pattern(pattern, ctypes.c_uint16, 16, count, user)
        if echo:
            log('ctrlEventWriteTxBuffer: buf={}, count={}, patter={}, user={}'.format(buf_num, count, pattern, user))
            self._dump_data(data_in, 16, count, 16)

        rc = ifcs_ctypes.mvHwsWatsonCtrlEventWriteTxBuffer(self.cli.node_id, buf_num, data_in, count)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlEventWriteTxBuffer() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonCtrlEventReadTxBuffer(self, buf_num, count):
        if count < 1 or count > 256:
            log_err('The count argument must be an integer in the range  1..2048: count={}'.format(count))
            return ifcs_ctypes.IFCS_PARAM

        if buf_num is None:
            buf_num = self.event_tx_buf_num

        data_out = (ctypes.c_uint16 * count)()
        rc = ifcs_ctypes.mvHwsWatsonCtrlEventReadTxBuffer(self.cli.node_id, buf_num, data_out, count)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonCtrlEventReadTxBuffer() failed.', rc, _status_to_string(rc))

        log('ctrlEventReadTxBuffer: buf={}, count={}'.format(buf_num, count))
        self._dump_data(data_out, 16, count, 8)
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonAgentStatsEnable(self, ib, enabled):
        rc = ifcs_ctypes.mvHwsWatsonAgentStatsEnable(self.cli.node_id, ib, enabled)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonAgentStatsEnable() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonAgentEventEnable(self, ib, enabled):
        rc = ifcs_ctypes.mvHwsWatsonAgentEventEnable(self.cli.node_id, ib, enabled)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonAgentEventEnable() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonAgentOscConfig(self, ib, osc_num, count, enabled):
        rc = ifcs_ctypes.mvHwsWatsonAgentOscConfig(self.cli.node_id, ib, osc_num, count, enabled)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonAgentOscConfig() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonAgentOscWrite(self, ib, osc_num, pattern, count, user, echo=False):
        if user is None:
            user = 0

        data_in = Watson._get_pattern(pattern, ctypes.c_uint32, 32, count, user)
        if echo:
            self._dump_data(data_in, 32, count, 8)

        rc = ifcs_ctypes.mvHwsWatsonAgentOscWrite(self.cli.node_id, ib, osc_num, data_in, count)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonAgentOscWrite() failed.', rc, _status_to_string(rc))
        return ifcs_ctypes.IFCS_SUCCESS

    def _mvHwsWatsonAgentOscRead(self, ib, osc_num, count):
        data_out = (ctypes.c_uint32 * count)()
        rc = ifcs_ctypes.mvHwsWatsonAgentOscRead(self.cli.node_id, ib, osc_num, data_out, count)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            raise CommandError('mvHwsWatsonAgentOscRead() failed.', rc, _status_to_string(rc))

        self._dump_data(data_out, 32, count, 8)
        return ifcs_ctypes.IFCS_SUCCESS

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        if len(self.arg_list) <= 2:
            self.parser.print_help()
            return ifcs_ctypes.IFCS_PARAM

        argv = self.arg_list[2:]
        try:
            args = self.parser.parse_args(argv)
            cmd_func = args.func
            kwargs = vars(args)
            kwargs.pop('func')
            log_dbg(1, 'args: {}'.format(kwargs))
            return cmd_func(kwargs)
        except CommandError as cmd_err:
            log_err('{}'.format(cmd_err))
            log_dbg(1, traceback.format_exc())
            return cmd_err.rc
        except Exception as e:
            log_err('{}'.format(e))
            log_err(traceback.format_exc())
            return ifcs_ctypes.IFCS_PARAM
