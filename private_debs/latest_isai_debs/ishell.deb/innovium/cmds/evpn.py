
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
from ifcs_ctypes import *
from ifcs_cmds.all import *
from print_table import PrintTable

# Class implements Ifcs related commands
class EVPN(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'show'        : self.show,
                         'help'        : self.help,
                         '?'           : self.help
                        }
        self.evpn_display_method = {
                            'sysport' : self.retrieve_evpn_sysports,
                            'nexthop' : self.retrieve_evpn_nexthops,
                               }
        self.cli = cli
        self.arg_list = []
        super(EVPN, self).__init__()
        self.ifcs_names = ['sysport','nexthop']
        '''
        self.help_str = "ifcs:        IFCS object cli commands\n"
        buflen = 64
        namebuf = create_string_buffer(buflen)
        '''
    def __del__(self):
        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_show(self, text):
        if text.upper() == text:
            return [i.upper() for i in self.ifcs_names if i.upper().startswith(text)]
        else:
            return [i.lower() for i in self.ifcs_names if i.lower().startswith(text)]

    complete_port = complete_show
    complete_l2vni = complete_show

    def getIfcsType(self, ifcs_obj_name):
        #Get IFCS Type Object
        log_dbg(1, "In getIfcsType ifcs_obj_name " + ifcs_obj_name)

        if ifcs_obj_name == 'l2vni':
            return l2vni(self.cli)
        if ifcs_obj_name == 'sysport':
            return sysport(self.cli)
        if ifcs_obj_name == 'devport':
            return devport(self.cli)
        if ifcs_obj_name == 'stp':
            return stp(self.cli)
        if ifcs_obj_name == 'l2entry':
            return l2entry(self.cli)
        if ifcs_obj_name == 'route':
            return route(self.cli)
        if ifcs_obj_name == 'node':
            return node(self.cli)
        if ifcs_obj_name == 'nexthop':
            return nexthop(self.cli)
        if ifcs_obj_name == 'l3vni':
            return l3vni(self.cli)

        return None

    # ------------
    # show command
    # ------------
    def show(self, args):
        log_dbg(1, "In EVPN show with args: "+args)
        evpn_type = args.split()[3]
        try:
            rc = self.evpn_display_method[evpn_type](args)
        except:
            log_err("Failed to get EVPN info")

        return rc

    # -------------------------------------------
    # EVPN sysport display methods
    # -------------------------------------------

    def _display_evpn_sysports(self, evpn_sysports):
        sysport = self.getIfcsType('sysport')
        table = PrintTable()
        field_names = ['Sysport', 'ES_DF_COUNT', 'ES_LB_PEER_COUNT', 'ES_DF_ALL_L2VNI']
        table.add_row(field_names)

        for sysport_hdl in evpn_sysports:
            df_count = sysport.getEsDfCount(sysport_hdl)
            peer_count = sysport.getEsLbPeerCount(sysport_hdl)
            df_all_l2vni = sysport.getEsDfAllL2vni(sysport_hdl)
            table.add_row([str(hex(int(sysport_hdl))), str(df_count), str(peer_count), str(df_all_l2vni)])
        table.print_table()

    def _display_evpn_sysport_df_list(self, evpn_sysports):
        sysport = self.getIfcsType('sysport')
        table = PrintTable()
        field_names = ['Sysport', 'ES_DF_LIST']
        table.add_row(field_names)
        for sysport_hdl in evpn_sysports:
            es_df_list = sysport.getEs_dfs(sysport_hdl)
            df_list_str = ''
            for df in es_df_list:
                if df_list_str != '':
                    df_list_str += ','
                df_list_str += str(hex(df))
            table.add_row([str(hex(int(sysport_hdl))), df_list_str])
        table.print_table()

    def _display_evpn_sysport_peer_list(self, evpn_sysports):
        sysport = self.getIfcsType('sysport')
        table = PrintTable()
        field_names = ['Sysport', 'ES_LB_PEER_LIST']
        table.add_row(field_names)
        for sysport_hdl in evpn_sysports:

            es_peer_list = sysport.getEs_lb_peers(sysport_hdl)
            es_peer_list_str = ''
            for peer in es_peer_list:
                if es_peer_list_str != '':
                    es_peer_list_str += ','
                es_peer_list_str += str(hex(peer))
            table.add_row([str(hex(int(sysport_hdl))), es_peer_list_str])
        table.print_table()

    def retrieve_evpn_sysports(self, args):
        log_dbg(1, "In display evpn sysports ")

        devport = self.getIfcsType('devport')
        if devport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            rc, all_devports = devport.bulk_get_all_devport_keys()
        except:
            log_err("Error retrieving devports")

        evpn_sysports = []
        # iterate over all devports
        for port in all_devports:
            # get the sysport
            sysport_hdl = devport.getSysport(port)

            # get the sysport
            sysport = self.getIfcsType('sysport')

            # get the sysport stats
            es_enable = sysport.getEsEnable(sysport_hdl)

            # add to table id es is enabled
            if es_enable:
                evpn_sysports.append(sysport_hdl)

        evpn_list = ''
        if (len(args.split()) > 4):
            evpn_list = args.split()[4]
        if evpn_list == '':
            self._display_evpn_sysports(evpn_sysports)
        elif evpn_list == 'es_df_list':
            self._display_evpn_sysport_df_list(evpn_sysports)
        elif evpn_list == 'es_lb_peer_list':
            self._display_evpn_sysport_peer_list(evpn_sysports)

    def retrieve_evpn_nexthops(self, args):
        log_dbg(1, "In display evpn nexthops")

        nexthop = self.getIfcsType('nexthop')
        if nexthop is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            rc, all_nexthops = nexthop.bulk_get_all_nexthop_keys()
        except:
            log_err("Error retrieving nexthops")

        table = PrintTable()
        field_names = ['Nexthop', 'EVPN_MH_PEER_ID']
        table.add_row(field_names)

        # iterate over all devports
        for nexthop_hdl in all_nexthops:
            peer_id = nexthop.getEvpnMhPeerId(nexthop_hdl)

            # add to table if peer ID is set
            if peer_id:
                table.add_row([str(hex(int(nexthop_hdl))), str(peer_id)])

        table.print_table()


    def help(self, args):
        log("Usage:: \n" + \
              "  ifcs show evpn <ifcsobj>   --- Shows input and output packet stats\n")
        log("")
        log("  *Displays output in tabular format.\n")
