#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
# *-----------------------------------------------------------------------------
#-------------------------------------------------------------------------------

from ifcs_types_util import *
from utils.common_util import build_ipaddr_attr
from utils.common_util import build_attr_list
from utils.common_util import build_fwd_policy_attr_value
from utils.common_util import getHandlesFromIfcsHandleList
from utils.mac_util import mac_addr_to_str
from utils.mac_util import get_ctype_arr
from utils.mac_util import convertMacstrtoarr

import shlex
import time
import random
import copy
import argparse

from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from ctypes import *
from testutil import pci
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']

class Sflow(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'create'           : self.create,
                         'help'             : self.help,
                         '?'                : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []




    def run_cmd(self, args):
        log_dbg(1, "in Sflow run")
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[2]](args)
        except (KeyError):
            log_dbg(1, "SflowKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "SflowValueError")
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None




    def create(self, args):
        log_dbg(1, "in sflow create")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Sflow create', prog='collector', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-direction', action="store", help='Direction INGRESS | EGRESS', required=True)
        requiredArgs.add_argument('-collector_set', action="store", help='Collector set handle', required=True)
        requiredArgs.add_argument('-src_port_handle', action="store", help='Source syport handle', required=True)
        requiredArgs.add_argument('-sample_rate', action="store", help='sampling rate in percentage', required=True)
        try:
            res = parser.parse_args(self.arg_list)
        except:
            log('Create parse_args failed')
            return 1

        # Get direction
        Dir = str(res.direction)
        if Dir == 'INGRESS':
            direction = ifcs_ctypes.IFCS_TRAFFIC_MONITOR_DIRECTION_INGRESS
        elif Dir == 'EGRESS':
            direction = ifcs_ctypes.IFCS_TRAFFIC_MONITOR_DIRECTION_EGRESS

        # Get collector set handle
        collector_set_handle = int(res.collector_set, 0)

        # Get src port handle
        src_port_handle = int(res.src_port_handle, 0)

        # Get sample rate
        sample_rate = int(res.sample_rate, 0)

        #from ifcs_cmds.all import *
        #sysportcliobj = Sysport(self.cli)
        #sysportcliobj.getSflowIngress(src_port_handle)
        pkt_attr = ifcs_ctypes.ifcs_traffic_monitor_policy_t()
        rc = ifcs_ctypes.ifcs_traffic_monitor_policy_t_init(pointer(pkt_attr))
        assert rc == ifcs_ctypes.IFCS_SUCCESS
        pkt_attr.collector_set = collector_set_handle
        pkt_attr.traffic_monitor_action = ifcs_ctypes.IFCS_TRAFFIC_MONITOR_ACTION_ENABLE
        pkt_attr.sampling_rate = sample_rate
        pkt_attr.traffic_monitor_container = ifcs_ctypes.IFCS_TRAFFIC_MONITOR_CONTAINER_1

        attr_t       = ifcs_ctypes.ifcs_attr_t()
        if Dir == 'INGRESS':
            attr_t.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_SFLOW_INGRESS
        elif Dir == 'EGRESS':
            attr_t.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_SFLOW_EGRESS
        attr_t.value.traffic_monitor_policy = pkt_attr

        rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id, src_port_handle, 1, pointer(attr_t))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Sflow Entry creation failed rc: {0}".format(rc))
        else:
            log("Sflow Entry creation successful for Sysport hdl= " + hex(src_port_handle))
        return rc


    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['create', 'Create Sflow'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        sflow_help_string = """
Usage::

    Type "config sflow <command>" followed by -h to see command's sub-options.
"""
        log(sflow_help_string)
