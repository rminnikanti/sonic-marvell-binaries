#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import argparse
import sys
import time
import shlex
from cmdmgr import Command
from ifcs_cmds.devport import Devport as Devport
from utils.compat_util import *
from verbosity import *
from print_table import PrintTable
from ctypes import *
ifcs_ctypes = sys.modules['ifcs_ctypes']

# Class implements Port related command
class Port(Command):
    def __init__(self, cli):
        self.sub_cmds = {'info'        : self.info,
                         'loopback'    : self.loopback,
                         'sig_det_mode': self.sig_det_mode,
                         'enable'      : self.enable,
                         'disable'     : self.enable,
                         'lt_enable'   : self.enable,
                         'lt_disable'  : self.enable,
                         'an_enable'   : self.enable,
                         'an_disable'  : self.enable,
                         'create'      : self.create,
                         'delete'      : self.delete,
                         'status'      : self.status,
                         'debug'       : self.debug,
                         'dbg'         : self.dbg,
                         'tx_eq'       : self.tx_eq,
                         'help'        : self.help,
                         '?'           : self.help,
                         'pdinfo'      : self.pdinfo,
                         'tx_eq_preset'        : self.tx_eq_preset,
                         'cut_through_enable'  : self.cut_through,
                         'cut_through_disable' : self.cut_through,
                         'admin_st_toggle_test': self.admin_st_toggle_test
                        }
        self.cli = cli
        self.arg_list = []
        self.pi = []
        self.active_node = -1
        self.all_devports = {}
        self.devport_obj = Devport(cli)

    def set_active_node(self, node_id):
        self.active_node = node_id
        log("Port: NodeId: ", node_id)

    def run_cmd(self, args):
        log_dbg(1, "in Port run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except (KeyError):
            log_dbg(
                1, "KeyError in port [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except (ValueError):
            log_dbg(
                1, "ValueError in port [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except:
            log_dbg(
                1, "OtherError in port [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    @staticmethod
    def get_ifcs_devport_type(devport_type):
        if devport_type == 'eth':
            return ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH

        if devport_type == 'il':
            return ifcs_ctypes.IFCS_DEVPORT_TYPE_IL

        if devport_type == 'mgmt':
            return ifcs_ctypes.IFCS_DEVPORT_TYPE_AUX

        if devport_type == 'cpu':
            return ifcs_ctypes.IFCS_DEVPORT_TYPE_CPU

        return ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH

    @staticmethod
    def get_ifcs_devport_speed(devport_speed):
        if devport_speed == '1':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_1G

        if devport_speed == '10':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_10G

        if devport_speed == '25':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_25G

        if devport_speed == '40':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_40G

        if devport_speed == '50':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_50G

        if devport_speed == '100':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_100G

        if devport_speed == '200':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_200G

        if devport_speed == '400':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_400G

        if devport_speed == '800':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_800G

        return ifcs_ctypes.IFCS_DEVPORT_SPEED_100G

    @staticmethod
    def get_ifcs_devport_isg(device_type, isg):
        if isg == 0:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG0
        if isg == 1:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG1
        if isg == 2:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG2
        if isg == 3:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG3
        if isg == 4:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG4
        if isg == 5:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG5
        if isg == 6:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG6
        if isg == 7:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG7
        if isg == 8:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG8
        if isg == 9:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG9
        if isg == 10:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG10
        if isg == 11:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG11
        if isg == 12:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG12
        if isg == 13:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG13
        if isg == 14:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG14
        if isg == 15:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG15
        if isg == 16:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG16
        if isg == 17:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG17
        if isg == 18:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG18
        if isg == 19:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG19
        if isg == 20:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG20
        if isg == 21:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG21
        if isg == 22:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG22
        if isg == 23:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG23
        if isg == 24:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG24
        if isg == 25:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG25
        if isg == 26:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG26
        if isg == 27:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG27
        if isg == 28:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG28
        if isg == 29:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG29
        if isg == 30:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG30
        if isg == 31:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG31
        if isg == 32:
            if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
                return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_MSER0
            else:
                return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG32
        if isg == 33:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG33
        if isg == 34:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG34
        if isg == 35:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG35
        if isg == 36:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG36
        if isg == 37:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG37
        if isg == 38:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG38
        if isg == 39:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG39
        if isg == 40:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG40
        if isg == 41:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG41
        if isg == 42:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG42
        if isg == 43:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG43
        if isg == 44:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG44
        if isg == 45:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG45
        if isg == 46:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG46
        if isg == 47:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG47
        if isg == 48:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG48
        if isg == 49:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG49
        if isg == 50:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG50
        if isg == 51:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG51
        if isg == 52:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG52
        if isg == 53:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG53
        if isg == 54:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG54
        if isg == 55:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG55
        if isg == 56:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG56
        if isg == 57:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG57
        if isg == 58:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG58
        if isg == 59:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG59
        if isg == 60:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG60
        if isg == 61:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG61
        if isg == 62:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG62
        if isg == 63:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG63
        if isg == 64:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG64

    @staticmethod
    def get_ifcs_devport_fec(fec_mode):
        if fec_mode == 'KR':
            return ifcs_ctypes.IFCS_DEVPORT_FEC_MODE_KR

        if fec_mode == 'KP':
            return ifcs_ctypes.IFCS_DEVPORT_FEC_MODE_KP

        if fec_mode == 'FC':
            return ifcs_ctypes.IFCS_DEVPORT_FEC_MODE_FC

        if fec_mode == 'NONE':
            return ifcs_ctypes.IFCS_DEVPORT_FEC_MODE_NONE

        if fec_mode == 'KPI':
            return ifcs_ctypes.IFCS_DEVPORT_FEC_MODE_KPI

        return ifcs_ctypes.IFCS_DEVPORT_FEC_MODE_KR

    @staticmethod
    def get_devport_enum_type(devport_enum):
        if devport_enum == '0':
            return 'ETH'

        if devport_enum == '1':
            return 'AUX'

        if devport_enum == '2':
            return 'CPU'

        if devport_enum == '3':
            return 'IL'

        if devport_enum == '4':
            return 'RECIRC'

        return 'NONE'

    @staticmethod
    def get_devport_enum_speed(devport_enum):
        if devport_enum == '10':
            return '1G'

        if devport_enum == '1':
            return '10G'

        if devport_enum == '2':
            return '25G'

        if devport_enum == '3':
            return '40G'

        if devport_enum == '4':
            return '50G'

        if devport_enum == '5':
            return '100G'

        if devport_enum == '6':
            return '200G'

        if devport_enum == '7':
            return '400G'

        if devport_enum == '11':
            return '800G'

        return 'NONE'

    @staticmethod
    def get_devport_enum_fec(devport_enum):
        if devport_enum == '1':
            return 'KRFEC'

        if devport_enum == '2':
            return 'KPFEC'

        if devport_enum == '3':
            return 'FCFEC'

        if devport_enum == '4':
            return 'KPIFEC'

        return 'NOFEC'

    @staticmethod
    def get_devport_enum_loopback(devport_enum):
        if devport_enum == '1':
            return 'PCS'

        if devport_enum == '2':
            return 'PMA'

        if devport_enum == '3':
            return 'REMOTE_LPBK'

        return 'NONE'

    @staticmethod
    def get_devport_enum_oper(devport_enum):
        if devport_enum == '1':
            return 'INITED'

        if devport_enum == '2':
            return 'DISABLED'

        if devport_enum == '3':
            return 'ENABLED'

        if devport_enum == '4':
            return 'AN_COMPLETE'

        if devport_enum == '5':
            return 'LINK_UP'

        if devport_enum == '6':
            return 'BUSY'

        return 'UINITED'

    def is_managed(self, devport):
        try:
            devport_type = self.all_devports[devport]
            return ((devport_type == ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH) or
                    (devport_type == ifcs_ctypes.IFCS_DEVPORT_TYPE_AUX))
        except:
            pass
        return False

    def get_all_devports(self):
        all_devports = {}

        #Do get all devport to figure out max devports configured
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            devport = arg
            attr = attr_list[ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE]
            assert attr.id == ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE
            devport_type = attr.value.u32
            all_devports[devport] = devport_type

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t,
            c_uint32,
            POINTER(ifcs_ctypes.ifcs_attr_t),
            POINTER(None))
        callback = callback_type(myCallback)

        try:
            rc = ifcs_ctypes.ifcs_devport_get_all(self.cli.node_id, 0, None,
                    compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
            if ( rc != ifcs_ctypes.IFCS_SUCCESS):
                log("Failed to get all devport rc: {0}".format(rc))
        except:
            log("In except of devport get_all")
            pass

        self.all_devports = all_devports

    def get_devports(self, devport_arg):
        self.get_all_devports()
        if devport_arg == 'all':
            # Port range not given, default to all ports
            devports = compat_listkeys(self.all_devports)
        else:
            # Use given devport range
            devports = []
            for dp in devport_arg.split(","):
                if '-' in dp:
                    dp_range = dp.split("-")
                    if len(dp_range) == 2:
                        for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                            devports.append(j)
                    else:
                        raise Exception("Invalid devport range: {}".format(dp))
                else:
                    devports.append(int(dp))
        return devports

    def devport_attr_set(self, devport, attr_count, attr_p):
        rc = ifcs_ctypes.ifcs_devport_attr_set(self.cli.node_id, devport,
                                               attr_count, attr_p)
        return rc

    def devport_attr_get(self, devport, attr_count, attr_p):
        actual_count = c_uint32(0)
        rc = ifcs_ctypes.ifcs_devport_attr_get(self.cli.node_id, devport,
                                               attr_count, attr_p, pointer(actual_count))
        return rc

    def create(self, args):
        log("devport create")

        self.arg_list.pop(0)

        args_list = args.split()
        device_type     = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)

        if len(args_list) < 10:
            log("Invalid number of arguments.")
            log("port create <port> <type> <num_lanes> <start_lane> <speed> " \
                   "<isg> <fec> <sysport> <tx_pll_bw> - ifcs port create\n")
            return

        devport         = int(args_list[2])
        devport_type    = Port.get_ifcs_devport_type(args_list[3])
        num_lanes       = int(args_list[4])
        start_lane      = int(args_list[5])
        devport_speed   = Port.get_ifcs_devport_speed(args_list[6])
        isg             = Port.get_ifcs_devport_isg(device_type, int(args_list[7]))
        fec_mode        = Port.get_ifcs_devport_fec(args_list[8])
        sysport_handle  = ifcs_ctypes.IFCS_HANDLE_SYSPORT(int(args_list[9]))

        if len(args_list) == 11:
            tx_pll_bw   = int(args_list[10], 16)

        node_id = self.cli.node_id
        attr_count = 8
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE;
        attr_list_p[0].value.u32 = devport_type;

        attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_NUM_LANES;
        attr_list_p[1].value.u32 = num_lanes;

        attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_START_LANE;
        attr_list_p[2].value.u32 = start_lane;

        attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SPEED;
        attr_list_p[3].value.u32 = devport_speed;

        attr_list_p[4].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SERDES_GROUP;
        attr_list_p[4].value.u32 = isg;

        attr_list_p[5].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_FEC_MODE;
        attr_list_p[5].value.u32 = fec_mode;

        attr_list_p[6].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT;
        attr_list_p[6].value.handle = sysport_handle;

        if len(args_list) == 11:
            attr_list_p[7].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TX_PLL_BW_FREQ;
            attr_list_p[7].value.handle = tx_pll_bw;
        else:
            attr_count = 7

        rc = ifcs_ctypes.ifcs_devport_create (node_id,
                                  devport,
                                  attr_count,
                                  compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

        assert rc == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during port create:" +\
                str(devport)

        log("create done")

    def delete(self, args):

        self.arg_list.pop(0)

        args_list = args.split()

        log("Port " + args_list[1])

        if len(args_list) < 3:
            log("Usage: " + args_list[0] + " " + args_list[1] + " <devport>")
            return

        devports = self.get_devports(args_list[2])

        for devport in devports:
            if not self.is_managed(devport):
                continue
            rc = ifcs_ctypes.ifcs_devport_delete(self.cli.node_id, devport)

            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                   "ERR during port delete:" +\
                    str(devport)

        log("Port " + args_list[1] + " done")

    def enable(self, args):
        self.arg_list.pop(0)
        en = self.arg_list.pop(0)
        res = self.arg_list.pop(0)

        devports = self.get_devports(res)

        try:
            # Enable/Disable all the ports
            devport_attr = ifcs_ctypes.ifcs_attr_t()
            if en == 'enable':
                devport_attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE
                devport_attr.value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE
            elif en == 'lt_enable':
                devport_attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_TRAINING
                devport_attr.value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE
            elif en == 'lt_disable':
                devport_attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_TRAINING
                devport_attr.value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE
            elif en == 'an_enable':
                devport_attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_AUTO_NEG
                devport_attr.value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE
            elif en == 'an_disable':
                devport_attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_AUTO_NEG
                devport_attr.value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE
            else:
                devport_attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE
                devport_attr.value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE

            for devport in devports:
                if not self.is_managed(devport):
                    continue
                rc = self.devport_attr_set(devport, 1, pointer(devport_attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin disable:" + str(devport)
        except:
            log("Hit except (Devport enable) config")

    def loopback(self, args):
        log("loopback set")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        res = self.arg_list.pop(0)

        args_list = args.split()

        devports = self.get_devports(res)

        loopback = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE

        if len(args_list) == 4:
            if args_list[3] == 'PCS':
                loopback = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PCS
            elif args_list[3] == 'PMA':
                loopback = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PMA
            elif args_list[3] == 'REMOTE':
                loopback = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_REMOTE_LPBK

        try:
            attr = ifcs_ctypes.ifcs_attr_t()
            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
            attr.value.u32 = loopback

            for devport in devports:
                if not self.is_managed(devport):
                    continue
                rc = self.devport_attr_set(devport, 1, pointer(attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port loopback set:" + str(devport)
        except:
            log("Hit except (Devport loopback) config")

    def sig_det_mode(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        res = self.arg_list.pop(0)

        args_list = args.split()

        devports = self.get_devports(res)

        flag = ifcs_ctypes.IFCS_DEVPORT_SIGNAL_DETECT_MODE_MODE1

        if len(args_list) == 4:
            if args_list[3] == '1':
                flag = ifcs_ctypes.IFCS_DEVPORT_SIGNAL_DETECT_MODE_MODE2

        try:
            attr = ifcs_ctypes.ifcs_attr_t()
            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SIG_DET_MODE
            attr.value.u32 = flag

            for devport in devports:
                if not self.is_managed(devport):
                    continue
                rc = self.devport_attr_set(devport, 1, pointer(attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during sig det mode set:" + str(devport)
        except:
            log("Hit except (Sig det mode) config")

    def info(self, args):
        self.arg_list.pop(0)

        args_list = args.split()
        device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)

        table = PrintTable()
        table.add_row(['devport', 'type', 'isg', 'speed', 'fec', 'num_lanes', 'start_lane', 'loopback', 'auto_neg', 'link_training', 'oper_state', 'admin_state', 'link_status'])
        if (len(args_list) < 3):
            devports = self.get_devports('all')
        else:
            devports = self.get_devports(args_list[2])

        attr = ifcs_ctypes.ifcs_attr_t()

        for devport in sorted(devports):
            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE
            ret = self.devport_attr_get(devport, 1, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            port_type = Port.get_devport_enum_type(str(attr.value.u32))

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SERDES_GROUP
            ret = self.devport_attr_get(devport, 1, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
                serdes_group = str(attr.value.u32 - 1)
            else:
                if attr.value.u32 > ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_MSER0:
                    serdes_group = str(attr.value.u32 - 2)
                else:
                    serdes_group = str(attr.value.u32 - 1)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SPEED
            ret = self.devport_attr_get(devport, 1, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            speed = Port.get_devport_enum_speed(str(attr.value.u32))

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_FEC_MODE
            ret = self.devport_attr_get(devport, 1, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            fec_mode = Port.get_devport_enum_fec(str(attr.value.u32))

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_NUM_LANES
            ret = self.devport_attr_get(devport, 1, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            num_lanes = str(attr.value.u32)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_START_LANE
            ret = self.devport_attr_get(devport, 1, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            start_lane = str(attr.value.u32)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
            ret = self.devport_attr_get(devport, 1, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            loopback = Port.get_devport_enum_loopback(str(attr.value.u32))

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_AUTO_NEG
            ret = self.devport_attr_get(devport, 1, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            auto_neg = str(attr.value.u32)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_TRAINING
            ret = self.devport_attr_get(devport, 1, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            link_training = str(attr.value.u32)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_OPER_STATE
            ret = self.devport_attr_get(devport, 1, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            oper_state = Port.get_devport_enum_oper(str(attr.value.u32))

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE
            ret = self.devport_attr_get(devport, 1, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            admin_state = str(attr.value.u32)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_STATUS
            ret = self.devport_attr_get(devport, 1, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            link_status = str(attr.value.u32)

            table.add_row([devport, port_type, serdes_group, speed, fec_mode, num_lanes, start_lane, loopback, auto_neg, link_training, oper_state, admin_state, link_status])

        table.print_table(brief=True)
        table.reset_table()

        return

    def debug(self, args):
        args_list = args.split()
        deb = int(args_list[2])
        if( deb == 1):
           '''
           count = 2
           attr = (ifcs_ctypes.ifcs_attr_t * count)()
           attr[0].id = IFCS_DEVPORT_ATTR_PFC_WD_MITIGATION_ACTION
           attr[0].value.u32 = IFCS_PFC_WD_MITIGATION_ACTION_DROP
           rc = ifcs_ctypes.im_devport_attr_set(0, 2, 1, attr);
           assert rc == IFCS_SUCCESS, "IFCS_PFC_WD_MITIGATION_ACTION_DROP set failed rc " + str(rc) + ""
           '''
           ifcs_ctypes.im_queue_pfcwd_mitigate(0,2,5);
        else:
           ifcs_ctypes.im_queue_pfcwd_restore(0,2,5);

    def dbg(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        args_list = args.split()

        if len(args_list) == 4:
            attr = self.arg_list.pop(0)
            flag = self.arg_list.pop(0)
            try:
                if attr == 'pic_intr_enable':
                    linkscan_attr_ct = 1
                    linkscan_attr = (ifcs_ctypes.ifcs_attr_t * linkscan_attr_ct)()
                    linkscan_attr[0].id =  ifcs_ctypes.IM_LINKSCAN_ATTR_PIC_INTR_ENABLE;
                    linkscan_attr[0].value.u32 = int(flag);
                    rc = ifcs_ctypes.im_linkscan_attr_set(self.cli.node_id, linkscan_attr_ct, linkscan_attr);
                    assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during im linkscan attr set"

            except:
                    log("Dbg operation failed")

        else:
            res = self.arg_list.pop(0)
            attr = self.arg_list.pop(0)
            flag = self.arg_list.pop(0)

            devports = self.get_devports(res)

            try:
                devport_attr = ifcs_ctypes.ifcs_attr_t()
                if attr == 'an_stop_on_hcd':
                    devport_attr.id =  ifcs_ctypes.IM_DEVPORT_ATTR_AUTO_NEG_STOP_ON_HCD
                    devport_attr.value.u32 = int(flag)
                elif attr == 'an_restart_disable':
                    devport_attr.id =  ifcs_ctypes.IM_DEVPORT_ATTR_AUTO_NEG_RESTART_DISABLE
                    devport_attr.value.u32 = int(flag)
                elif attr == 'lt_restart_disable':
                    devport_attr.id =  ifcs_ctypes.IM_DEVPORT_ATTR_LINK_TRAINING_RESTART_DISABLE
                    devport_attr.value.u32 = int(flag)
                elif attr == 'an_nrz_link_fail_timer':
                    devport_attr.id =  ifcs_ctypes.IM_DEVPORT_ATTR_AUTO_NEG_NRZ_LINK_FAIL_PERIOD
                    devport_attr.value.u32 = int(flag)
                elif attr == 'an_pam4_link_fail_timer':
                    devport_attr.id =  ifcs_ctypes.IM_DEVPORT_ATTR_AUTO_NEG_PAM4_LINK_FAIL_PERIOD
                    devport_attr.value.u32 = int(flag)

                for devport in devports:
                    if not self.is_managed(devport):
                        continue
                    rc = ifcs_ctypes.im_devport_attr_set(self.cli.node_id, devport, 1, pointer(devport_attr))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during im devport attr set:" + str(devport)

            except:
                log("Dbg operation failed")

    def pdinfo(self, args):
        args_list = args.split()
        table = PrintTable()
        table.add_row(['Devport', 'IB', 'IBport', 'PIC_ID', 'PIC_PORT'])
        if (len(args_list) < 3):
            devports = self.get_devports('all')
        else:
            devports = self.get_devports(args_list[2])

        info = ifcs_ctypes.im_devport_info_t()
        for devport in sorted(devports):
            rc = ifcs_ctypes.im_devport_info_get(self.cli.node_id, devport, pointer(info))
            if rc == ifcs_ctypes.IFCS_SUCCESS:
                table.add_row([devport, info.pi_ib, info.pi_ibport, info.pi_pic_id, info.pi_pic_port])

        table.print_table(brief=True)
        table.reset_table()

        return

    def status_chain_dump(self, kspace):
        node_id = self.cli.node_id
        ifcs_ctypes.im_devport_pic_status_chain_dump(node_id, kspace)

    def status(self, args):
        self.arg_list.pop(0)

        args_list = args.split()
        kspace = c_int(0)

        if len(args_list) == 3:
            kspace = c_int(int(args_list[2]))

        self.status_chain_dump(kspace)

    def tx_eq(self, args):
        log("TX EQ")

        self.arg_list.pop(0)

        args_list = args.split()

        if len(args_list) < 5:
            log("Usage: port tx_eq <set/get> <port> <lane_mask>")
            return

        devport = c_uint32(int(args_list[3]))

        rc = ifcs_ctypes.ifcs_status_t()

        node_id = self.cli.node_id

        if args_list[2] == 'set':
            if len(args_list) < 10:
                log("Usage: port tx_eq <set/get> <port> <lane_mask> <pre1> <pre2> <pre3> <attn> <post>")
                return
            attr_count = 6
            attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

            attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK;
            attr_list_p[0].value.u8 = c_uint8(int(args_list[4]));

            attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TX_EQ_PRE1;
            TxEqPre1 = ifcs_i8_list_s()
            TxEqPre1.count = 1
            TxEqPre1.arr = (c_byte * TxEqPre1.count)()
            TxEqPre1.arr[0] = c_int8(int(args_list[5]));
            attr_list_p[1].value.i8_list = TxEqPre1

            attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TX_EQ_PRE2;
            TxEqPre2 = ifcs_i8_list_s()
            TxEqPre2.count = 1
            TxEqPre2.arr = (c_byte * TxEqPre2.count)()
            TxEqPre2.arr[0] = c_int8(int(args_list[6]));
            attr_list_p[2].value.i8_list = TxEqPre2

            attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TX_EQ_PRE3;
            TxEqPre3 = ifcs_i8_list_s()
            TxEqPre3.count = 1
            TxEqPre3.arr = (c_byte * TxEqPre3.count)()
            TxEqPre3.arr[0] = c_int8(int(args_list[7]));
            attr_list_p[3].value.i8_list = TxEqPre3

            attr_list_p[4].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TX_EQ_ATTN;
            TxEqAttn = ifcs_i8_list_s()
            TxEqAttn.count = 1
            TxEqAttn.arr = (c_byte * TxEqAttn.count)()
            TxEqAttn.arr[0] = c_int8(int(args_list[8]));
            attr_list_p[4].value.i8_list = TxEqAttn

            attr_list_p[5].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TX_EQ_POST;
            TxEqPost = ifcs_i8_list_s()
            TxEqPost.count = 1
            TxEqPost.arr = (c_byte * TxEqPost.count)()
            TxEqPost.arr[0] = c_int8(int(args_list[9]));
            attr_list_p[5].value.i8_list = TxEqPost

            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                                 attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                   "ERR during port tx_eq set:" +\
                    str(devport)

            log("TX EQ set done")
        elif args_list[2] == 'get':
            tx_eq_pre1 = c_int8(0)
            tx_eq_pre2 = c_int8(0)
            tx_eq_pre3 = c_int8(0)
            tx_eq_attn = c_int8(0)
            tx_eq_post = c_int8(0)

            lane_mask = c_uint8(int(args_list[4]));

            rc = ifcs_ctypes.im_devport_get_tx_eq(node_id, devport, lane_mask, pointer(tx_eq_pre1), pointer(tx_eq_pre2),
                                     pointer(tx_eq_pre3), pointer(tx_eq_attn), pointer(tx_eq_post));

            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                   "ERR during port tx_eq get:" +\
                    str(devport)

            log("PRE1\tPRE2\tPRE3\tATTN\tPOST\n")
            log("%d\t%d\t%d\t%d\t%d" %(tx_eq_pre1.value, tx_eq_pre2.value, tx_eq_pre3.value, tx_eq_attn.value, tx_eq_post.value))
        else:
            log("Invalid port tx_eq <set/get> param")

    def get_tx_eq_preset_parser(self):
        parser = argparse.ArgumentParser(prog='tx_eq_preset', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        cmd_sub_parser = parser.add_subparsers(dest="cmd", required=True)

        set_parser = cmd_sub_parser.add_parser("set")
        setting_sub_parser = set_parser.add_subparsers(dest="setting", required=True)

        nrz_parser = setting_sub_parser.add_parser("nrz")
        nrz_parser.add_argument("-p", "--port", type=int, required=True)
        nrz_parser.add_argument("-l", "--lane", type=int, help="all lanes when not specified")
        nrz_parser.add_argument("preset", type=str, choices=["init", "preset1"])

        pam4_parser = setting_sub_parser.add_parser("pam4")
        pam4_parser.add_argument("-p", "--port", type=int, required=True)
        pam4_parser.add_argument("-l", "--lane", type=int, help="all lanes when not specified")
        pam4_parser.add_argument("preset", type=str, choices=["preset1", "preset2", "preset3", "preset4", "preset5"])

        preset_parser = setting_sub_parser.add_parser("init", aliases=["preset1", "preset2", "preset3", "preset4", "preset5"])
        preset_parser.add_argument("-p", "--port", type=int, required=True)
        preset_parser.add_argument("-l", "--lane", type=int, help="all lanes when not specified")
        preset_parser.add_argument("pre1", type=int)
        preset_parser.add_argument("pre2", type=int)
        preset_parser.add_argument("pre3", type=int)
        preset_parser.add_argument("main", type=int)
        preset_parser.add_argument("post", type=int)

        get_parser = cmd_sub_parser.add_parser("get")
        get_parser.add_argument("-p", "--port", type=int, required=True)
        return parser

    def tx_eq_preset(self, args):
        self.arg_list.pop(0)
        args_list = args.split()

        device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)

        parser = self.get_tx_eq_preset_parser()
        args = parser.parse_args(args_list[2:])

        attr = ifcs_ctypes.ifcs_attr_t()
        attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_NUM_LANES
        ret = self.devport_attr_get(args.port, 1, pointer(attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS, "get num_lanes failed : ret = [" + str(ret) + "]"
        num_lanes = attr.value.u32

        if args.cmd == 'set':
            if args.setting in ["nrz", "pam4"]:
                attr_name = "IFCS_DEVPORT_ATTR_TX_EQ_PRESET_{}".format(args.setting.upper())
                if not hasattr(ifcs_ctypes, attr_name):
                    log("tx_eq_preset: invalid encoding {}".format(args.setting))
                    return

                preset_name = "IFCS_DEVPORT_TX_EQ_PRESET_{}".format(args.preset.upper())
                if not hasattr(ifcs_ctypes, preset_name):
                    log("tx_eq_preset: invalid preset {}".format(args.preset))
                    return
                preset_value = getattr(ifcs_ctypes, preset_name)

                attr = ifcs_ctypes.ifcs_attr_t()
                attr.id = getattr(ifcs_ctypes, attr_name)
                if args.lane is None:
                    attr.value.devport_tx_eq_preset_list.count = num_lanes
                    attr.value.devport_tx_eq_preset_list.arr = (ifcs_ctypes.ifcs_devport_tx_eq_preset_t * num_lanes)()
                    for lane in range(num_lanes):
                        attr.value.devport_tx_eq_preset_list.arr[lane] = preset_value
                else:
                    if args.lane < 0 or args.lane >= num_lanes:
                        log("tx_eq_preset: invalid lane number {}. valid range: 0..{}".format(args.lane, num_lanes - 1))
                        return

                    rc = self.devport_attr_get(args.port, 1, pointer(attr))
                    if ifcs_ctypes.IFCS_STATUS_REASON(rc) == ifcs_ctypes.IFCS_LENGTH_MISMATCH:
                        attr.value.devport_tx_eq_preset_list.arr = (ifcs_ctypes.ifcs_devport_tx_eq_preset_t * attr.value.devport_tx_eq_preset_list.count)()
                        rc = self.devport_attr_get(args.port, 1, pointer(attr))
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log("tx_eq_preset: failed to get {} attribute. rc={}".format(attr_name, ifcs_ctypes.IFCS_STATUS_REASON(rc)))
                        return

                    if args.lane >= attr.value.devport_tx_eq_preset_list.count:
                        new_arr = (ifcs_ctypes.ifcs_devport_tx_eq_preset_t * (args.lane + 1))()
                        for i in range(attr.value.devport_tx_eq_preset_list.count):
                            new_arr[i] = attr.value.devport_tx_eq_preset_list.arr[i]

                        for i in range(attr.value.devport_tx_eq_preset_cfg_list.count, args.lane):
                            new_arr[i] = ifcs_ctypes.IFCS_DEVPORT_TX_EQ_PRESET_DEFAULT

                        attr.value.devport_tx_eq_preset_list.count = args.lane + 1
                        attr.value.devport_tx_eq_preset_list.arr = new_arr

                    attr.value.devport_tx_eq_preset_list.arr[args.lane] = preset_value

                rc = self.devport_attr_set(args.port, 1, pointer(attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port tx_eq_preset set: {}".format(args.port)
            elif args.setting in ["init", "preset1", "preset2", "preset3", "preset4", "preset5"]:
                attr_name = "IFCS_DEVPORT_ATTR_TX_EQ_{}_PRESET".format(args.setting.upper())
                if not hasattr(ifcs_ctypes, attr_name):
                    log("tx_eq_preset: invalid preset {}".format(args.setting))
                    return

                attr = ifcs_ctypes.ifcs_attr_t()
                attr.id = getattr(ifcs_ctypes, attr_name)
                if args.lane is None:
                    attr.value.devport_tx_eq_preset_cfg_list.count = num_lanes
                    attr.value.devport_tx_eq_preset_cfg_list.arr = (ifcs_ctypes.ifcs_devport_tx_eq_preset_cfg_t * num_lanes)()
                    for lane in range(num_lanes):
                        tx_eq_cfg = attr.value.devport_tx_eq_preset_cfg_list.arr[lane]
                        tx_eq_cfg.pre1 = args.pre1
                        tx_eq_cfg.pre2 = args.pre2
                        tx_eq_cfg.pre3 = args.pre3
                        tx_eq_cfg.main = args.main
                        tx_eq_cfg.post = args.post
                else:
                    if args.lane < 0 or args.lane >= num_lanes:
                        log("tx_eq_preset: invalid lane number {}. valid range: 0..{}".format(args.lane, num_lanes - 1))
                        return

                    rc = self.devport_attr_get(args.port, 1, pointer(attr))
                    if ifcs_ctypes.IFCS_STATUS_REASON(rc) == ifcs_ctypes.IFCS_LENGTH_MISMATCH:
                        attr.value.devport_tx_eq_preset_cfg_list.arr = (ifcs_ctypes.ifcs_devport_tx_eq_preset_cfg_t * attr.value.devport_tx_eq_preset_cfg_list.count)()
                        rc = self.devport_attr_get(args.port, 1, pointer(attr))
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log("tx_eq_preset: failed to get {} attribute. rc={}".format(attr_name, ifcs_ctypes.IFCS_STATUS_REASON(rc)))
                        return

                    if args.lane >= attr.value.devport_tx_eq_preset_cfg_list.count:
                        new_arr = (ifcs_ctypes.ifcs_devport_tx_eq_preset_cfg_t * (args.lane + 1))()
                        for i in range(attr.value.devport_tx_eq_preset_cfg_list.count):
                            new_arr[i] = attr.value.devport_tx_eq_preset_cfg_list.arr[i]

                        for i in range(attr.value.devport_tx_eq_preset_cfg_list.count, args.lane):
                            new_arr[i].pre1 = ifcs_ctypes.IFCS_DEVPORT_TX_EQ_PRESET_DEFAULT
                            new_arr[i].pre2 = ifcs_ctypes.IFCS_DEVPORT_TX_EQ_PRESET_DEFAULT
                            new_arr[i].pre3 = ifcs_ctypes.IFCS_DEVPORT_TX_EQ_PRESET_DEFAULT
                            new_arr[i].main = ifcs_ctypes.IFCS_DEVPORT_TX_EQ_PRESET_DEFAULT
                            new_arr[i].post = ifcs_ctypes.IFCS_DEVPORT_TX_EQ_PRESET_DEFAULT

                        attr.value.devport_tx_eq_preset_cfg_list.count = args.lane + 1
                        attr.value.devport_tx_eq_preset_cfg_list.arr = new_arr

                    tx_eq_cfg = attr.value.devport_tx_eq_preset_cfg_list.arr[args.lane]
                    tx_eq_cfg.pre1 = args.pre1
                    tx_eq_cfg.pre2 = args.pre2
                    tx_eq_cfg.pre3 = args.pre3
                    tx_eq_cfg.main = args.main
                    tx_eq_cfg.post = args.post

                rc = self.devport_attr_set(args.port, 1, pointer(attr))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log("tx_eq_preset: failed to set {} attribute. rc={}".format(attr_name, ifcs_ctypes.IFCS_STATUS_REASON(rc)))
                    return
            else:
                log("invalid setting: {}".format(args.setting))
        elif args.cmd == "get":
            log("Devport: {}".format(args.port))
            attr = ifcs_ctypes.ifcs_attr_t()
            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_NUM_LANES
            rc = self.devport_attr_get(args.port, 1, attr)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Failed to get number of lanes. rc={}".format(ifcs_ctypes.IFCS_STATUS_REASON(rc)))
                return
            num_lanes = attr.value.u32

            table = PrintTable()

            if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
                header = ["encoding"] + ["lane{}".format(lane) for lane in range(num_lanes)]
                table.add_row(header)
                for encoding in ["nrz", "pam4"]:
                    attr_name = "IFCS_DEVPORT_ATTR_TX_EQ_PRESET_{}".format(encoding.upper())
                    attr = ifcs_ctypes.ifcs_attr_t()
                    attr.id = getattr(ifcs_ctypes, attr_name)
                    rc = self.devport_attr_get(args.port, 1, pointer(attr))
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        if ifcs_ctypes.IFCS_STATUS_REASON(rc) == ifcs_ctypes.IFCS_LENGTH_MISMATCH:
                            attr.value.devport_tx_eq_preset_list.arr = (ifcs_ctypes.ifcs_devport_tx_eq_preset_t * attr.value.devport_tx_eq_preset_list.count)()
                            rc = self.devport_attr_get(args.port, 1, pointer(attr))
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log("tx_eq_preset: failed to get {} attribute. rc={}".format(attr_name, ifcs_ctypes.IFCS_STATUS_REASON(rc)))
                            return
                    row = [encoding] + [""] * num_lanes
                    assert attr.value.devport_tx_eq_preset_list.count <= num_lanes
                    for lane in range(attr.value.devport_tx_eq_preset_list.count):
                        preset_value = attr.value.devport_tx_eq_preset_list.arr[lane]
                        preset_value = self.devport_obj.enum_to_str("devport_tx_eq_preset", preset_value).lower()
                        row[lane + 1] = preset_value
                    table.add_row(row)

                log("TX equalization preset select:")
                table.print_table(brief=True)
                log("")
                table.reset_table()

            table.add_row(["preset", "lane", "pre1", "pre2", "pre3", "main", "post"])
            if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
                preset_list = ["preset1", "preset2", "preset3"]
            elif device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
                preset_list = ["init", "preset1", "preset2", "preset3", "preset4", "preset5"]

            for preset in preset_list:
                attr_name = "IFCS_DEVPORT_ATTR_TX_EQ_{}_PRESET".format(preset.upper())
                attr = ifcs_ctypes.ifcs_attr_t()
                attr.id = getattr(ifcs_ctypes, attr_name)
                rc = self.devport_attr_get(args.port, 1, pointer(attr))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    if ifcs_ctypes.IFCS_STATUS_REASON(rc) == ifcs_ctypes.IFCS_LENGTH_MISMATCH:
                        attr.value.devport_tx_eq_preset_cfg_list.arr = (ifcs_ctypes.ifcs_devport_tx_eq_preset_cfg_t * attr.value.devport_tx_eq_preset_cfg_list.count)()
                        rc = self.devport_attr_get(args.port, 1, pointer(attr))
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log("tx_eq_preset: failed to get {} attribute. rc={}".format(attr_name, ifcs_ctypes.IFCS_STATUS_REASON(rc)))
                        return
                
                if attr.value.devport_tx_eq_preset_cfg_list.count:
                    for lane in range(attr.value.devport_tx_eq_preset_cfg_list.count):
                        tx_eq_cfg = attr.value.devport_tx_eq_preset_cfg_list.arr[lane]
                        pre1 = "default" if tx_eq_cfg.pre1 == ifcs_ctypes.IFCS_DEVPORT_TX_EQ_PRESET_DEFAULT else tx_eq_cfg.pre1
                        pre2 = "default" if tx_eq_cfg.pre3 == ifcs_ctypes.IFCS_DEVPORT_TX_EQ_PRESET_DEFAULT else tx_eq_cfg.pre2
                        if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
                            pre3 = "n/a"
                        elif device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
                            pre3 = "default" if tx_eq_cfg.pre2 == ifcs_ctypes.IFCS_DEVPORT_TX_EQ_PRESET_DEFAULT else tx_eq_cfg.pre3
                        main = "default" if tx_eq_cfg.main == ifcs_ctypes.IFCS_DEVPORT_TX_EQ_PRESET_DEFAULT else tx_eq_cfg.main
                        post = "default" if tx_eq_cfg.post == ifcs_ctypes.IFCS_DEVPORT_TX_EQ_PRESET_DEFAULT else tx_eq_cfg.post
                        table.add_row([preset, lane, pre1, pre2, pre3, main, post])
                    
            log("TX equalization preset configuration:")
            table.print_table(brief=True)
        else:
            log("Invalid command: {}".format(args.cmd))

    def cut_through(self, args):
        self.arg_list.pop(0)
        args_list = args.split()
        log("Port " + args_list[1])
        if len(args_list) < 3:
            log("Usage: " + args_list[0] + " " + args_list[1] + " <port>")
            return

        devport = c_uint32(int(args_list[2]))

        enable = 0
        if len(args_list) == 3:
            if args_list[1] == 'cut_through_enable':
                enable = 1
            elif args_list[1] == 'cut_through_disable':
                enable = 0

        rc = ifcs_ctypes.ifcs_status_t()

        node_id = self.cli.node_id
        attr_count = 1
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_CUT_THROUGH_ENABLE;
        attr_list_p[0].value.u32 = enable;

        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport, attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "ERR during port cut_through set:" + str(devport)

        log("cut through set done")

    def admin_st_toggle_test(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        res = self.arg_list.pop(0)
        loop_cnt = self.arg_list.pop(0)
        max_wait_time = self.arg_list.pop(0)
        stop_on_link_down = self.arg_list.pop(0)

        devports = self.get_devports(res)

        devport_attr = ifcs_ctypes.ifcs_attr_t()

        for loop in range(0, int(loop_cnt)):
            log("\nLOOP:" + str(loop))
            devport_attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE
            devport_attr.value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE

            for devport in devports:
                if not self.is_managed(devport):
                    continue
                rc = self.devport_attr_set(devport, 1, pointer(devport_attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin enable:" + str(devport)

            # Wait for all ports to go link-up for max_wait_time secs
            timer_val=float(max_wait_time)
            wait_time=0
            devport_attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_STATUS
            devport_attr.value.u32 = 0
            link_status=True
            while wait_time<timer_val:
                link_status=True
                for devport in devports:
                    if not self.is_managed(devport):
                        continue
                    rc = self.devport_attr_get(devport, 1, pointer(devport_attr))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during port admin enable:" +\
                        str(devport)

                    if (devport_attr.value.u32 != 1):
                        if (wait_time >= timer_val - 0.1):
                            log("Port not UP:" + str(devport))
                            if stop_on_link_down == '1':
                                link_status=False
                                break
                        link_status=False
                if link_status:
                    break
                else:
                    wait_time+=0.1
                    time.sleep(0.1)

            if stop_on_link_down == '1' and link_status == False:
                break

            devport_attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE
            devport_attr.value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE

            for devport in devports:
                if not self.is_managed(devport):
                    continue
                rc = self.devport_attr_set(devport, 1, pointer(devport_attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin disable:" + str(devport)

    def help(self, args):
        self.cli.error()
        log("Usage: \n",
              "port info       <devport> - ifcs port info\n",
              "port loopback   <devport> - ifcs port loopback\n",
              "port enable     <devport> - ifcs port enable\n",
              "port disable    <devport> - ifcs port disable\n",
              "port lt_enable  <devport> - ifcs port LT enable\n",
              "port lt_disable <devport> - ifcs port LT disable\n",
              "port an_enable  <devport> - ifcs port AN enable\n",
              "port an_disable <devport> - ifcs port AN disable\n",
              "port create     <port> <type> <num_lanes> <start_lane> <speed>",
                "<isg> <fec> <sysport> - ifcs port create\n",
              "port delete     <devport> - ifcs port delete\n",
              "port status               - ifcs port status\n",
              "port tx_eq      <set/get> <port> <lane_mask> <pre1> <pre2> <pre3> <attn> <post> - ifcs port tx_eq\n",
              "port tx_eq_preset set <nrz/pam4>       -p/--port <port> [-l/--lane <lane>] <preset>\n",
              "port tx_eq_preset set <init/preset1-5> -p/--port <port> [-l/--lane <lane>] <pre1> <pre2> <pre3> <main> <post>\n",
              "port tx_eq_preset get -p/--port <port>\n",
              "port pdinfo     <devport> - ifcs pd info\n",
              "port cut_through_enable   <port> - ifcs port cut_through_enable\n",
              "port cut_through_disable  <port> - ifcs port cut_through_disable\n",
              "port admin_st_toggle_test <devport> <iterations> <wait_time> <stop_on_link_down> - ifcs port admin state toggle test\n",
              "port help or ?            - show this text\n",
              "\nArguments:\n",
              "<devport> [all | <port> | <port range>]\n")
