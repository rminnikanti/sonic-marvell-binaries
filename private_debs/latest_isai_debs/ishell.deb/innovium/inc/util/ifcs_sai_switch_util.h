/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_switch_util.h
 * @brief ISAI Util Include file for SWITCH module
 */


#ifndef __IFCS_SAI_SWITCH_UTIL_H__
#define __IFCS_SAI_SWITCH_UTIL_H__

#include "util/ifcs_sai_switch_util_dep.h"
#include "ifcs_node.h"



/*
 * @brief Set the hash object for IPv4 packets
 *
 * @param [in] switch_id   - SAI switch object ID
 * @param [in] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_hash_ipv4_set(sai_object_id_t switch_id,
                             sai_attribute_t *attr_p);


/*
 * @brief Set the hash object for IPv6 packets
 *
 * @param [in] switch_id   - SAI switch object ID
 * @param [in] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_hash_ipv6_set(sai_object_id_t switch_id,
                             sai_attribute_t *attr_p);


/*
 * @brief Set the hash object for IPv4 inIPv4 packets
 *
 * @param [in] switch_id   - SAI switch object ID
 * @param [in] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_hash_ipv4_in_ipv4_set(sai_object_id_t switch_id,
                                     sai_attribute_t *attr_p);

sai_status_t
isai_im_switch_get_device_type(ifcs_node_id_t     node_id,
                               ifcs_device_type_t *device_type_p);

/*
 * @brief Add port default STP
 *
 * @param [in] switch_oid   - SAI switch object ID
 * @param [in] port_oid     - Port object ID
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_add_port_default_stp(sai_object_id_t switch_oid, sai_object_id_t port_oid);

/*
 * @brief Get datapath init done or not
 *
 * @param [in] switch_oid   - SAI switch object ID
 * @param [out] init_done   - Is init done
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_get_datapath_init_done(sai_object_id_t switch_id,
                                     bool            *init_done);

/**
 * @brief Get attributes for a given switch
 *
 * @param [in]     switch_object_id  - switch Object_id
 * @param [in]     attr_count        - Number of attributes
 * @param [in,out] attr_list_p       - Attribute list
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_get_switch(sai_object_id_t switch_object_id,
                         uint32_t        attr_count,
                         sai_attribute_t *attr_list_p);

/**
 * @brief Get attributes for a given switch
 *
 * @param [in]     switch_object_id  - switch Object_id
 * @param [in]     ifcs_attr_id        - Number of attributes
 * @param [in,out] attr_p      - Attribute list
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_get_switch_ds_object(sai_object_id_t switch_object_id,
        ifcs_attr_id_t  ifcs_attr_id,
        sai_attribute_t *attr_p);

/*
 * @brief Get switch pfc flood control
 *
 * @param [in] switch_oid   - SAI switch object ID
 * @param [out] is_enable   - Is enabled
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_get_switch_pfc_flood_control(sai_object_id_t switch_oid,
                                     bool            *is_enable);

/*
 * @brief Set the Datapath init status
 *
 * @param [in] switch_oid   - SAI switch object ID
 * @param [in] init_done    - Datapath init status
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_set_datapath_init_done(sai_object_id_t switch_oid,
                                     bool            init_done);

/*
 * @brief Returns whether a given OID is of CPU port or not
 *
 * @param [in]  switch_oid  -  Switch Object ID
 * @param [in]  oid         -  Object ID for comparision
 * @param [out] port_is_cpu -  True if port is cpu
 * @return bool
 */
sai_status_t
isai_im_switch_is_cpu_port(sai_object_id_t switch_id,
                           sai_object_id_t oid,
                           bool            *port_is_cpu);

/*
 * @brief Set switch pfc flood control
 *
 * @param [in] switch_oid   - SAI switch object ID
 * @param [in] is_enable   - Is enabled
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_set_switch_pfc_flood_control(sai_object_id_t switch_oid,
                                     bool            is_enable);

/*
 * @brief Get Egress PFC info
 *
 * @param [in] node_id   - SAI switch object ID
 * @param [out] sai_attr_p   - info
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_get_egress_pfc_info(ifcs_node_id_t node_id,
    sai_attribute_t *sai_attr_p);

/*
 * @brief Get Default VR Object ID
 *
 * @param [in] switch_oid   - SAI switch object ID
 * @param [out] def_vr_oid  - default vr oid
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_get_default_vr_oid(sai_object_id_t switch_oid,
                               sai_object_id_t *def_vr_oid);

/*
 * @brief Decrement the refcount of internal Storm control ACL table and
 * delete the ACL table if refcount reaches zero.
 *
 * @param [in]  node_id   - ifcs node id
 * @return sai_status_t
 *
 * @details
 * This function decrements the refcounnt of the internal ACL table that is
 * used for port storm control feature.
 */
sai_status_t
isai_im_switch_policer_acl_table_dec_ref_count(ifcs_node_id_t node_id);

/*
 * @brief Get the SDK handle of internal Storm control ACL table.
 *
 * @param [in]  node_id   - Switch OID
 * @param [out]  acl_table_handle_p  - Pointer to ACL table handle
 * @param [out] inc_ref_count        - Increment ACL table refcount
 * @return sai_status_t
 *
 * @details
 * This function returns the SDK handle of the internal ACL table that is
 * created to implement the port storm control policer attributes.
 */
sai_status_t
isai_im_switch_policer_acl_table_get(ifcs_node_id_t node_id,
                                     isai_policer_type_t policer_type,
                                     ifcs_handle_t  *acl_table_handle_p,
                                     bool           inc_ref_count);

/*
 * @brief Remove port default STP
 *
 * @param [in] port_oid   - port object id
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_remove_port_default_stp(sai_object_id_t    port_oid);

/*
 * @brief Create IFCS ECMP hash attribute default handles in ISAI DS
 *
 * @param [in] sai_switch_init_info_p - Switch Init data
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_attr_create_default_ecmp_hash_attr(sai_switch_init_info_t
                                           *sai_switch_init_info_p);

/*
 * @brief Get the CPU Port
 *
 * @param [in]     switch_oid   - SAI switch object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_cpu_port_get(sai_object_id_t switch_oid,
                                  sai_attribute_t *attr_p);

/**
 * @brief: Create hash
 *
 * @param [in] hash_object_id_p            - Pointer to hash object
 * @param [in] switch_id                   - Switch Id
 * @param [in] attr_count                  - Number of attributes
 * @param [in] attr_list_p                 - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_switch_hash_create( sai_object_id_t      *hash_object_id_p,
                    sai_object_id_t       switch_id,
                    uint32_t              attr_count,
                    const sai_attribute_t *attr_list_p);

/*
 * @brief Get the default 802.1q bridge id
 *
 * @param [in]     switch_oid   - SAI switch object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_get_default_1q_bridge_id(sai_object_id_t switch_oid,
                                              sai_attribute_t *attr_p);

/*
 * @brief Get default SAI STP instance ID
 *
 * @param [in]     switch_oid   - SAI switch object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_default_stp_inst_id_get(sai_object_id_t switch_oid,
                                             sai_attribute_t *attr_p);

/*
 * @brief Get default trap group
 *
 * @param [in]     switch_oid   - SAI switch object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_default_trap_group_get(sai_object_id_t switch_oid,
                                            sai_attribute_t *attr_p);

/*
 * @brief Get default trap group
 *
 * @param [in]     switch_oid   - SAI switch object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_vxlan_default_router_mac_get(sai_object_id_t switch_oid,
                                         sai_attribute_t *attr_p);

/*
 * @brief Get default VLAN ID
 *
 * @param [in]     switch_oid   - SAI switch object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_default_vlan_id_get(sai_object_id_t switch_oid,
                                         sai_attribute_t *attr_p);

/*
 * @brief Get switch FDB Event notification callback function passed to the adapter.
 *
 * @param [in]     switch_oid   - SAI switch object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_fdb_event_notify_get(sai_object_id_t switch_oid,
                                          sai_attribute_t *attr_p);

/*
 * @brief Get switch Received packet event notification callback function passed to the adapter.
 *
 * @param [in]     switch_oid   - SAI switch object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_packet_event_notify_get(sai_object_id_t switch_oid,
                                             sai_attribute_t *attr_p);

/*
 * @brief Get default SAI Virtual Router ID
 *
 * @param [in]     switch_oid   - SAI switch object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_default_virtual_router_id_get(sai_object_id_t switch_oid,
                                                   sai_attribute_t *attr_p);
/**
 * @brief Set attributes for a given switch
 *
 * @param [in]     switch_oid  - switch Object_id
 * @param [in]     ifcs_attr_id -  attr id
 * @param [in]     attr         - Attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_set_switch_ds_object(sai_object_id_t switch_oid,
        ifcs_attr_id_t  ifcs_attr_id,
        sai_attribute_t attr);
/*
 * @brief Get switch pfc flood control
 *
 * @param [in] node_id   - Node id
 * @param [out] acl_tbl_hdl_p   - acl table handle
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_get_egress_pfc_acl_table(ifcs_node_id_t node_id,
                                          ifcs_handle_t *acl_tbl_hdl_p);

sai_status_t
isai_im_switch_get_switch_attr(sai_object_id_t switch_oid,
                               uint32_t        attr_count,
                               sai_attribute_t *attr_list_p);


/*
 * @brief Get Switch Mac Address
 *
 * @param [in]     switch_id   - SAI switch object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_mac_addr_get(sai_object_id_t switch_oid,
                            sai_attribute_t *attr_p);

/*
 * @brief Get default virtual router ID
 *
 * @param [in]  switch_id     - Switch Object ID
 * @param [out] def_vr_oid_p  - Pointer to store default VR ID
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_def_vr_id_get(
    sai_object_id_t switch_oid,
    sai_object_id_t *def_vr_oid_p);

/*
 * @brief Get switch DSCP-to-TC map
 *
 * @param [in]  switch_id    - Switch Object ID
 * @param [out] qmap_oid_p   - Pointer to qos map OID
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_dscp_to_tc_qmap_oid_get(
    sai_object_id_t switch_oid,
    sai_object_id_t *qmap_oid_p);

/*
 * @brief Get packet size for a given trap type
 *
 * @param [in]  switch_id    - Switch Object ID
 * @param [in]  trap_type - Trap type
 * @param [out] pkt_size - Pointer packet size
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_get_trap_type_pkt_size(sai_object_id_t switch_oid,
                                      sai_hostif_trap_type_t trap_type,
                                      uint32_t *pkt_size);


/*
 * @brief Free up memory used for trap-type, packet size config
 *
 * @param [in]  switch_id    - Switch Object ID
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_free_trap_type_pkt_size_db(sai_object_id_t switch_oid);

sai_status_t
isai_im_switch_get_acl_entry_maximum_priority(ifcs_node_id_t    node_id,
                                              sai_attribute_t   *sai_attr_p);

sai_status_t
isai_im_switch_get_acl_entry_minimum_priority(ifcs_node_id_t    node_id,
                                              sai_attribute_t   *sai_attr_p);

/*
 * @brief Set switch ID
 *
 * @param [in] node_id   - Node ID
 * @param [in] device_id - Device ID
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_set_switch_id(ifcs_node_id_t node_id,
                             uint16_t device_id);

/*
 * @brief Get switch device ID
 *
 * @param [in] node_id - Node ID
 * @param [in,out] device_id_p - pointer to Device ID
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_get_device_id(ifcs_node_id_t node_id,
                             uint16_t *device_id_p);

/*
 * @brief Get switch IFA protocol value
 *
 * @param [in] node_id         - Node ID
 * @param [in,out] ifa_proto_p - pointer to ifa_proto
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_get_ifa_proto_value(ifcs_node_id_t node_id,
                                   uint8_t *ifa_proto_p);


/*
 * @brief Get ars profile oid
 *
 * @param [in] node_id         - Node ID
 * @param [in,out] ars_profile_oid_p - pointer to ars profile oid
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_get_ars_profile_oid(ifcs_node_id_t node_id,
                                   sai_object_id_t *ars_profile_oid_p);

/*
 * @brief Set ars profile oid
 *
 * @param [in] node_id         - Node ID
 * @param [in] ars_profile_oid - ars profile oid
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_set_ars_profile_oid(ifcs_node_id_t node_id,
                                   sai_object_id_t ars_profile_oid);

sai_status_t
isai_im_switch_get_port_list(ifcs_node_id_t     node_id,
                             sai_attribute_t    *attr_p);

/*
 * @brief Set TC Flood Control Drop
 *
 * @param [in] switch_oid   - SAI switch object ID
 * @param [in] hw_tc_drop   - Drop setting for TC
 * @return sai_status_t
 */
sai_status_t
isai_im_switch_set_tc_flood_control_drop(sai_object_id_t switch_oid,
                                         bool hw_tc_drop);

sai_status_t
isai_im_switch_set_viz_type_foi(ifcs_node_id_t node_id,
                                uint32_t viz_type,
                                bool enable_foi);
#endif /* __IFCS_SAI_SWITCH_UTIL_H__ */
