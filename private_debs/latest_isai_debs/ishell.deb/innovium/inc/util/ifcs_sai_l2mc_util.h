
/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_l2mc_util.h
 * @brief ISAI Util Include file for TUNNEL module
 */


#ifndef __IFCS_SAI_L2MC_UTIL_H__
#define __IFCS_SAI_L2MC_UTIL_H__

#include "util/ifcs_sai_l2mc_util_dep.h"

/**
 * @brief Initializes L2MC module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_l2mc_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes L2MC module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_l2mc_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

#endif /* __IFCS_SAI_L2MC_UTIL_H__ */
