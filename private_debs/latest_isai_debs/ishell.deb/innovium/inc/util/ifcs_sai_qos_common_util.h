/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_qos_common_util.h
 * @brief ISAI Util Include file for QOS_COMMON module
 */


#ifndef __IFCS_SAI_QOS_COMMON_UTIL_H__
#define __IFCS_SAI_QOS_COMMON_UTIL_H__

#include "util/ifcs_sai_qos_common_util_dep.h"

sai_status_t
isai_im_qos_common_scheduler_group_sai_id_get(ifcs_node_id_t        node_id,
                                              uint32_t              dev_port,
                                              uint32_t              scheduler_group_id,
                                              sai_object_id_t       *id_p,
                                              bool                  is_create,
                                              uint32_t              attr_count,
                                              const sai_attribute_t *attr_list_p);

sai_status_t
isai_im_qos_common_pg_sai_id_get(ifcs_node_id_t        node_id,
                                 uint32_t              dev_port,
                                 uint32_t              pg_id,
                                 sai_object_id_t       *id_p,
                                 bool                  is_create,
                                 uint32_t              attr_count,
                                 const sai_attribute_t *attr_list_p);


/**
 * @brief set the node_id in qos_info
 * @param[in] node_id_new       - ifcs node_id
 * @param[in] qos_object_id - sai object id
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_node_id_set(sai_object_id_t qos_object_id,
                               ifcs_node_id_t  node_id_new);


sai_status_t
isai_im_qos_common_queue_sai_id_get(ifcs_node_id_t        node_id,
                                    uint32_t              dev_port,
                                    uint32_t              queue_id,
                                    sai_object_id_t       *id_p,
                                    bool                  is_create,
                                    uint32_t              attr_count,
                                    const sai_attribute_t *attr_list_p);


/*
 *  Return the buffer profiles associated with the IPGs of this port.
 */
sai_status_t
isai_im_qos_common_ingress_buffer_profile_list_get(ifcs_node_id_t  node_id,
                                                   sai_object_id_t port_oid,
                                                   sai_attribute_t *attr_p);

/*
 *  Return the buffer profiles associated with the Qs of this port.
 */
sai_status_t
isai_im_qos_common_egress_buffer_profile_list_get(ifcs_node_id_t  node_id,
                                                  sai_object_id_t port_oid,
                                                  sai_attribute_t *attr_p);

/**
 * @brief set scheduler for a given port
 *
 * @param [in] port_oid    -    port oid
 * @param [in] attr_list_p        - Attribute list
 * @param [in] prev_sched_id   - previous scheduler if attached
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_port_scheduler_set(ifcs_node_id_t        node_id,
                                      sai_object_id_t       port_oid,
                                      const sai_attribute_t *attr_list_p,
                                      sai_object_id_t       prev_sched_id);

/*
 * The caller is supposed to have called ifcs_sai_shim_get_scheduler_group_list_count_from_port()
 * and alloced attr_p->value.objlist.list */
sai_status_t
isai_im_qos_common_get_scheduler_group_list_from_port(ifcs_node_id_t  node_id,
                                                      sai_object_id_t port_oid,
                                                      sai_attribute_t *attr_p);

sai_status_t
isai_im_qos_common_get_qos(
    sai_object_id_t qos_object_id,
    uint32_t        attr_count,
    sai_attribute_t *attr_list_p);

/**
 * @brief Don't use it for hash DS i.e ipg as of now
 * Callee allocs objlist->list;
 * Caller needs to free objlist->list;
 */
sai_status_t
isai_im_qos_common_get_sai_object_list_of_qos_type(sai_object_id_t   switch_oid,
                                                   sai_object_type_t obj_type,
                                                   sai_object_list_t *objlist);

/**
 * @brief Get sai_attr_count of the given ISAI QoS object
 *
 * @param[in] qos_object_id          - sai_object_id_t of ISAI QoS object
 * @param[out] sai_attr_countp -  return value
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_db_sai_attr_count_get(const sai_object_id_t qos_object_id,
                                         uint32_t              *sai_attr_countp);

/**
 * @brief Get sai_attr_list of the given ISAI QoS object
 * Callee allocs the list and sublist for
 * SAI_POLICER_ATTR_ENABLE_COUNTER_PACKET_ACTION_LIST
 * Caller needs to free the list and sublist.
 *
 * @param[in] qos_object_id    - sai_object_id_t of ISAI QoS object
 * @param[out] sai_attr_listpp -  return value
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_db_sai_attr_list_get(const sai_object_id_t qos_object_id,
                                        sai_attribute_t       **sai_attr_listpp);


/*
 * @brief Get the attr list for given qos object
 * Caller needs to free the list.
 *
 * @param [in]  qos_object_id - qos Object_id
 * @param [out] attr_count_p  - SAI attr count
 * @param [out] attr_list_pp  - SAI attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_object_attr_list_get(sai_object_id_t qos_object_id,
                                        uint32_t        *attr_count_p,
                                        sai_attribute_t **attr_list_pp);



/**
 * @brief Set attributes of a SAI QoS object id
 * @param[in] qos_object_id   - Obj ID
 * @param[in] attr_count  - user provided attr list count
 * @param[in] attr_list_p  - user provided attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_sai_attr_set(sai_object_id_t       qos_object_id,
                                uint32_t              attr_count,
                                const sai_attribute_t *attr_list_p);

/**
 * @brief Get handle of the given ISAI QoS object
 *
 * @param[in] qos_object_id           - sai_object_id_t of ISAI QoS object
 * @param[out] handle_p -  return value
 * @return sai_status_t
 */
/* DO NOT USE THS API FOR POLCER, USE THE ONE IN ifcs_sai_shim_policer.c */
sai_status_t
isai_im_qos_common_db_handle_get(const sai_object_id_t qos_object_id,
                                 ifcs_handle_t         *handle_p);

/**
 * @brief set handle of the given ISAI QoS object
 *
 * @param[in] qos_object_id          - sai_object_id_t of ISAI QoS object
 * @param[in] handle -  Handle to set in DB
 * @return sai_status_t
 */
/* DO NOT USE THS API FOR POLCER, USE THE ONE IN ifcs_sai_shim_policer.c */
sai_status_t
isai_im_qos_common_db_handle_set(const sai_object_id_t qos_object_id,
                                 ifcs_handle_t         handle);

/*
 * @brief  Validate a given QoS  object
 *
 * @param [in] qos_object_id - oid
 * @param [in] obj_type = sai_object_type
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_qos_common_obj_validate(sai_object_id_t   qos_object_id,
                                sai_object_type_t obj_type);

/**
 * @brief Attach/detach a SAI object to another SAI object.
 * Eg: attach a scheduler to a queue, buffer-profile to a queue
 * Type information is encoded in the object-ids.
 * @param[in] qos_object_id - object that is being attached
 * @param[in] bindpoint_obj_id - object to which we are attaching
 * @param[in] is_attach - if true attach else detach
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_sai_object_attach(sai_object_id_t qos_object_id,
                                     sai_object_id_t bindpoint_obj_id,
                                     bool            is_attach);

sai_status_t
isai_im_qos_common_hw_program(ifcs_node_id_t  node_id,
                              sai_object_type_t  action_obj_type,
                              sai_object_id_t action_obj_id,
                              sai_object_id_t target_obj_id,
                              ifcs_handle_t   handle,
                              uint32_t        attr_count,
                              sai_attribute_t *attr_list_p);

/**
 * @brief Program hardware on attach of a SAI object to another SAI object.
 * Eg: attach a scheduler to a queue, update the queue' scheduling related
 * attributes.
 * @param[in] action_obj_id - object that is being attached;
 *                            pass SAI_NULL_OBJECT_ID to signify unprogram.
 * @param[in] action_obj_type - isai action object type when
 *                              action_obj_type is SAI_NULL_OBJECT_ID
 * @param[in] target_obj_id - object to which we are attaching
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_hw_update(ifcs_node_id_t   node_id,
                             sai_object_id_t  action_obj_id,
                             sai_object_id_t  action_obj_type,
                             sai_object_id_t  target_obj_id);

/* Given a scheduler group OID, return the underlying Queue OID */
sai_status_t
isai_im_qos_common_scheduler_group_queue_get(
    sai_object_id_t scheduler_group_object_id,
    sai_object_id_t *queue_oid_p);

sai_status_t
isai_im_qos_common_validate_buffer_profile_attrs(
    sai_object_id_t buffer_profile_id,
    sai_object_id_t target_oid);

/**
 * @brief Free a SAI object id
 *
 * @param[in] oid          - SAI  obj id
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_sai_id_delete(sai_object_id_t oid);

/*
 * This API verifies whether the reserved size attribute that the user
 * is requesting for the ipg/queue is less than or equal to the
 * available space in the dtm partition. It covers 3 scenarios
 *
 * 1. Updating the reserved size attribute of a buffer profile
 * 2. Updating the buffer profile id of a IPG
 * 3. Updating the buffer profile id of a queue
 *
 * Reserve size verification in each scenario is dealt with in a
 * seperate API
 *
 * Parameters:
 *    oid_of_object_getting_updated [in] : ipg/queue/buffer profile oid
 *    profile_oid                   [in] : buffer profile oid if the 1st
 *                                         parameter is ipg/queue. Else 0
 *    bf_attr_count                 [in] : buffer profile attr list count
 *    bf_attr_list                  [in] : buffer profile attribute list
 **/

sai_status_t
isai_im_qos_common_verify_reserved_size(
    sai_object_id_t       oid_of_object_getting_updated,
    sai_object_id_t       profile_oid,
    uint32_t              bf_attr_count,
    const sai_attribute_t *bf_attr_list_p);

/**
 * @brief Get an unique SAI object hash
 *
 * @param[in] node_id       - Node ID
 * @param[in] type     -  SAI Object Type
 * @param[in] attr_count  - user provided attr list count
 * @param[in] attr_list_p  - user provided attr list
 * @param[in,out] id_p          - u32 obj id
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_sai_hash_create(ifcs_node_id_t        node_id,
                                   sai_object_id_t        type,
                                   uint32_t              attr_count,
                                   const sai_attribute_t *attr_list_p,
                                   sai_object_id_t       *id_p);

/**
 * @brief Get the node_id in qos_info
 * @param[in] id           - SAI Object id
 * @param[out] node_id_p       - ifcs node_id
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_node_id_get(sai_object_id_t id,
                          ifcs_node_id_t  *node_id_p);

/**
 * @brief Get an unique SAI object id
 *
 * @param[in] node_id       - Node ID
 * @param[in] type     -  SAI Object Type
 * @param[in] attr_count  - user provided attr list count
 * @param[in] attr_list_p  - user provided attr list
 * @param[in,out] id_p          - u32 obj id
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_sai_id_create(ifcs_node_id_t         node_id,
                                 sai_object_id_t        type,
                                 uint32_t               attr_count,
                                 const sai_attribute_t *attr_list_p,
                                 sai_object_id_t       *id_p);

/**
 * @brief  Is object in use
 * Eg: is scheduler attached to any q
 * @param[in] qos_object_id - object that is being attached
 * @return  bool
 */
sai_status_t
isai_im_qos_common_sai_object_in_use(sai_object_id_t qos_object_id,
                                     bool            *in_use_p);

/*
 * @brief  Get the bind point list
 *
 * @param [in] qos_object_id         - Bound to object ID (qos type)
 * @param [out] num_bindpoints_p  - Num. bind points
 * @param [out] bind_point_list_pp - Bind Points List
 * @return sai_status_t
 */
sai_status_t
isai_im_qos_common_get_bind_point_list(sai_object_id_t qos_object_id,
                                       uint32_t        *num_bindpoints_p,
                                       sai_object_id_t **bind_point_list_pp);

sai_status_t
isai_im_qos_common_get_priority_group_list_from_port(sai_object_id_t port_oid,
                                                 sai_attribute_t *attr_p);

sai_status_t
isai_im_qos_common_get_queue_list_from_port(sai_object_id_t port_oid,
                                        sai_attribute_t *attr_p);

sai_status_t
isai_im_qos_common_get_priority_group_list_count_from_port(sai_object_id_t port_oid,
                                                       uint32_t        *count_p);


#endif /* __IFCS_SAI_QOS_COMMON_UTIL_H__ */
