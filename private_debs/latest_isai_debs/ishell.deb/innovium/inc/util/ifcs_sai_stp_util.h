/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_stp_util.h
 * @brief ISAI Util Include file for STP module
 */


#ifndef __IFCS_SAI_STP_UTIL_H__
#define __IFCS_SAI_STP_UTIL_H__

#include "util/ifcs_sai_stp_util_dep.h"

sai_status_t
isai_im_stp_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_stp_deinit(sai_switch_deinit_info_t *sai_switch_deinit_info_p);

sai_status_t
isai_im_stp_get_stp_port_oid(sai_object_id_t stp_oid, sai_object_id_t port_oid,
                             sai_object_id_t    *stp_port_oid_p);


/**
 * @brief: Create STP
 *
 * @param [in] stp_object_id_p            - Pointer to STP object
 * @param [in] switch_id                  - Switch Id
 * @param [in] attr_count                 - Number of attributes
 * @param [in] attr_list_p                - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_stp_create( sai_object_id_t       *stp_object_id_p,
                    sai_object_id_t       switch_id,
                    uint32_t              attr_count,
                    const sai_attribute_t *attr_list_p);

/**
 * @brief: Remove STP
 *
 * @param [in] stp_object_id       - Stp Port object
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_stp_remove( sai_object_id_t    stp_object_id);

/**
 * @brief: Create STP Port
 *
 * @param [in] stp_port_object_id_p       - Pointer to STP Port object
 * @param [in] switch_id                  - Switch Id
 * @param [in] attr_count                 - Number of attributes
 * @param [in] attr_list_p                - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_stp_port_create(sai_object_id_t       *stp_port_object_id_p,
                        sai_object_id_t       switch_id,
                        uint32_t              attr_count,
                        const sai_attribute_t *attr_list_p);

/**
 * @brief: Remove STP Port
 *
 * @param [in] stp_port_object_id     - Pointer to STP Port object
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_stp_port_remove(sai_object_id_t   stp_port_object_id);

/**
 * @brief: Get STP Handle given STP OID
 *
 * @param [in] stp_oid       - STP Object ID
 * @param [out]stp_hdl_p     - Pointer to STP handle
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_stp_get_stp_hdl(sai_object_id_t stp_oid,
                        ifcs_handle_t   *stp_hdl_p);
/**
 * @brief: Get STP OID given STP Handle
 *
 * @param [in] node_id       - IFCS node id
 * @param [in] stp_hdl       - STP Handle
 * @param [out]stp_oid_p     - Pointer to STP object id
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_stp_get_stp_oid(ifcs_node_id_t  node_id,
                        ifcs_handle_t   stp_hdl,
                        sai_object_id_t *stp_oid_p);
#endif /* __IFCS_SAI_STP_UTIL_H__ */
