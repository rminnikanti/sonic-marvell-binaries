/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_mirror_util.h
 * @brief ISAI Util Include file for MIRROR module
 */


#ifndef __IFCS_SAI_MIRROR_UTIL_H__
#define __IFCS_SAI_MIRROR_UTIL_H__

#include "util/ifcs_sai_mirror_util_dep.h"

sai_status_t
isai_im_mirror_get_mirror_ingress(sai_object_id_t port_id,
                                  sai_attribute_t *attr_p);

sai_status_t
isai_im_mirror_get_mirror_egress(sai_object_id_t port_id,
                                 sai_attribute_t *attr_p);

sai_status_t
isai_im_mirror_set_mirror_ingress(sai_object_id_t port_id,
                                  sai_uint32_t    sample_rate,
                                  sai_attribute_t *attr_p);
sai_status_t
isai_im_mirror_set_mirror_egress(sai_object_id_t port_id,
                                 sai_uint32_t    sample_rate,
                                 sai_attribute_t *attr_p);

sai_status_t
isai_im_mirror_get_sample_rate(ifcs_node_id_t  node_id,
                               sai_object_id_t mirror_oid,
                               uint32_t        *sample_rate_p);

/*
 * @brief Get collector_handle to configure mirror sessions in ingress of acl
 * @param [in] node_id - IFCS node ID
 * @param [in] acl_entry_oid - ACL entry object ID
 * @param [in] sai_attr_p - Attribute id with mirror_list
 * @param [out] ifcs_collector_set_handle - Collector set handle
 * @return sai_status_t
*/
sai_status_t
isai_im_mirror_acl_set_ingress(ifcs_node_id_t        node_id,
                               sai_object_id_t       acl_entry_oid,
                               const sai_attribute_t *sai_attr_p,
                               ifcs_handle_t         *ifcs_collector_set_handle);

/*
 * @brief Get collector_handle to configure mirror sessions in egress of acl
 * @param [in] node_id - IFCS node ID
 * @param [in] acl_entry_oid - ACL entry object ID
 * @param [in] sai_attr_p - Attribute id with mirror_list
 * @param [out] ifcs_collector_set_handle - Collector set handle
 * @return sai_status_t
*/
sai_status_t
isai_im_mirror_acl_set_egress(ifcs_node_id_t        node_id,
                               sai_object_id_t       acl_entry_oid,
                              const sai_attribute_t *sai_attr_p,
                              ifcs_handle_t         *ifcs_collector_set_handle);

/*
 * @brief Remove mirror_Session config for given acl_entry
 * @param [in] node_id - IFCS node ID
 * @param [in] acl_entry_oid - ACL entry object ID
 * @param [in] is_ingress - Ingress/Egress
 * @return sai_status_t
*/
sai_status_t
isai_im_mirror_acl_delete(ifcs_node_id_t    node_id,
                          sai_object_id_t   acl_entry_oid,
                          bool              is_ingress);

/*
 * @brief Free resouces allocated for given collector_set handle
 * @param [in] node_id - IFCS node ID
 * @param [in] cs_hdl - Collector set handle
 * @return sai_status_t
 */
sai_status_t
isai_im_mirror_acl_delete_cs(ifcs_node_id_t  node_id,
                            ifcs_handle_t   cs_hdl);
                            
sai_status_t
isai_im_mirror_acl_get_session(ifcs_node_id_t    node_id,
                               ifcs_handle_t     cs_id,
                               sai_object_list_t *mirror_list_p);

sai_status_t
isai_im_mirror_session_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_mirror_session_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_mirror_get_acl_table(ifcs_node_id_t node_id,
                             ifcs_handle_t  *acl_tbl_hdl_p);

sai_status_t
isai_im_mirror_get_monitor_ib(ifcs_node_id_t  node_id,
                              sai_object_id_t mirror_oid,
                              uint8_t         *ib_p);

/*
 * @brief Get Mirror Session object type resource availability.
 *
 * @param[in] switch_id SAI Switch object id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list List of attributes that to distinguish resource
 * @param[out] count Available objects left
 *
 * @return #SAI_STATUS_NOT_SUPPORTED if the given object type does not support resource accounting.
 * Otherwise, return #SAI_STATUS_SUCCESS.
 */
sai_status_t
isai_im_mirror_object_type_get_availability(sai_object_id_t       switch_id,
                                            uint32_t              attr_count,
                                            const sai_attribute_t *attr_list,
                                            uint64_t              *count_p);

/*
 * @brief Set forwarding mode on sysport with DCDP created on it
 *
 * @param [in] node_id   - IFCS node ID
 * @param [in] sysport   - IFCS sysport handle
 * @param [in] fwd_mode  - IFCS port forwarding mode
 * @return sai_status_t
 */
sai_status_t
isai_im_mirror_change_sysport_fwd_mode_with_dcdp(ifcs_node_id_t        node_id,
                                               ifcs_handle_t           sysport,
                                               ifcs_sysport_fwd_mode_t fwd_mode);

sai_status_t
isai_im_mirror_sample_get_collector_set(ifcs_node_id_t           node_id,
                                        sai_object_id_t port_oid,
                                        ifcs_traffic_monitor_direction_t direction,
                                        ifcs_handle_t      *ifcs_collector_set_handle_p);

/*
 * @brief Set mirror session bindpoint DS with given acl_entry oid
 * @param [in] node_id - IFCS node ID
 * @param [in] acl_entry_oid - ACL entry object ID
 * @param [in] mirror_list_p - Mirror session list
 * @param [in] is_ingress - Ingress/Egress
 * @return sai_status_t
 */
sai_status_t
isai_im_mirror_bp_ds_update(ifcs_node_id_t                   node_id,
                            sai_object_id_t                 acl_entry_oid,
                            sai_object_list_t               *mirror_list_p,
                            bool                            is_ingress);
#endif /* __IFCS_SAI_MIRROR_UTIL_H__ */
