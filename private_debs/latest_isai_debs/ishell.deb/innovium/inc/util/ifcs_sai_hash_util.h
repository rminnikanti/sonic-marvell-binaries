/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_hash_util.h
 * @brief ISAI Util Include file for HASH module
 */


#ifndef __IFCS_SAI_HASH_UTIL_H__
#define __IFCS_SAI_HASH_UTIL_H__

#include "util/ifcs_sai_hash_util_dep.h"


/*
 *  @brief Initializes hash module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_hash_init(
    sai_switch_init_info_t *sai_switch_init_info_p);


/*
 * @brief Un-initializes hash module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_hash_deinit(
    sai_switch_deinit_info_t *switch_deinit_info_p);


/*
 * @brief Get IFCS extended field list handles from HASH DS Entry
 *
 * @param [in] switch_id      - Switch object id
 * @param [in] hash_type      - Hash type
 * @param [in] hash_oid       - Hash object id
 * @param [in] ifcs_hdl_p     - Pointer to EFL IFCS handles
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_get_efl_from_ds_entry(sai_object_id_t switch_id,
                                   hash_type_t     hash_type,
                                   sai_object_id_t hash_oid, 
                                   ifcs_handle_t   *ifcs_hdl_p);


/*
 * @brief Set IFCS extended field list handles in HASH DS entry
 *
 * @param [in] switch_id      - Switch object id
 * @param [in] hash_type      - Hash type
 * @param [in] hash_oid       - Hash object id
 * @param [in] ifcs_handle_p  - Pointer to EFL IFCS handles
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_set_efl_in_ds_entry(sai_object_id_t switch_id,
                                 hash_type_t     hash_type,
                                 sai_object_id_t hash_oid, 
                                 ifcs_handle_t   *ifcs_hdl_p);



/*
 * @brief Create extended field list in IFCS from HASH DS entry
 *
 * @param [in] switch_id      - Switch object id
 * @param [in] hash_type      - Hash type
 * @param [in] hash_oid       - Hash object id
 * @param [out] ifcs_hdl_p    - Pointer to ifcs_handles
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_create_efl_from_ds_entry(sai_object_id_t switch_id,
                                      hash_type_t     hash_type,
                                      sai_object_id_t hash_oid, 
                                      ifcs_handle_t   *ifcs_hdl_p);

/**
 * @brief Delete extended field list from IFCS and update HASH DS Entry
 *
 * @param [in] switch_id      - Switch object id
 * @param [in] hash_type      - Hash type
 * @param [in] hash_oid       - Hash object id
 * @param [in] skip_ds_update - Skip DS update flag
 * @param [out] ifcs_hdl_p    - Pointer to ifcs_handles
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_delete_efl_from_ifcs(sai_object_id_t switch_id,
                                  hash_type_t     hash_type,
                                  sai_object_id_t hash_oid, 
                                  bool            skip_ds_update,
                                  ifcs_handle_t   *ifcs_hdl_p);


#endif /* __IFCS_SAI_HASH_UTIL_H__ */
